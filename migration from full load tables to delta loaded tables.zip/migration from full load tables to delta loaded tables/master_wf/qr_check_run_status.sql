select cast(TD_TIME_FORMAT(TD_TIME_ADD(last_load_ts, '30d'),'yyyyMMdd') as bigint) as start_date,
 cast(TD_TIME_FORMAT(cast(to_unixtime(CURRENT_TIMESTAMP) as bigint),'yyyyMMdd') as bigint) as end_date
from ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank from db_stg_bi_technical.delta_load_log_dce  where layer ='bi_paid' and entity_name= 'paid' and operation_mode = 'insert' and completion_flag=0 )
          where rank = 1 )