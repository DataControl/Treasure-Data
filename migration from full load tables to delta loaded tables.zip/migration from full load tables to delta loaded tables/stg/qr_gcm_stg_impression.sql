delete from db_stg_gcm_bi.impression where cast(TD_TIME_FORMAT(cast(to_unixtime(cast(date as timestamp)) as bigint),'yyyyMMdd')as bigint) between ${td.last_results.start_date} and ${td.last_results.end_date};
 
insert into db_stg_gcm_bi.impression ( 
createddate, 
createdby, 
lastmodifieddate, 
lastmodifiedby,    
impression_id,   
event_time,   
user_id,  
advertiser_id,   
campaign_id,   
ad_id,   
rendering_id,   
creative_version,   
placement_id,   
country_code, 
site_id, 
active_view_eligible_impressions ,
active_view_measurable_impressions ,
active_view_viewable_impressions ,
date ,
gcm_insert_date ,
time  
) 

select 
createddate, 
createdby, 
lastmodifieddate, 
lastmodifiedby,    
impression_id,   
event_time,   
user_id,  
advertiser_id,   
campaign_id,   
ad_id,   
rendering_id,   
creative_version,   
placement_id,   
country_code, 
site_id, 
active_view_eligible_impressions ,
active_view_measurable_impressions ,
active_view_viewable_impressions ,
date ,
gcm_insert_date ,
time  
from db_stg_gcm_bi.impression_il 
where cast(TD_TIME_FORMAT(cast(to_unixtime(cast(date as timestamp)) as bigint),'yyyyMMdd')as bigint) between ${td.last_results.start_date} and  ${td.last_results.end_date};