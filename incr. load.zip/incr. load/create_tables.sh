td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/activity.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/activity_categories.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/activity_types.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/ads.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/advertisers.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/campaigns_match.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/click.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/creatives_match.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/impression.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/placements_match.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/placement_cost.sql
td query -d db_l0_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l0_gcm_bi/sites_match.sql

td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/activity.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/activity_categories.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/activity_types.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/ads.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/advertisers.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/campaigns.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/click.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/creatives.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/impression.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/placements.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/placement_cost.sql
td query -d db_l1_bi_gcm -t presto -w -q ./paid_incremental/01_tables/ddl_db_l1_bi_gcm/sites.sql

td query -d db_l2_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l2_bi/activity.sql
td query -d db_l2_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l2_bi/campaigns.sql
td query -d db_l2_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l2_bi/click.sql
td query -d db_l2_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_l2_bi/impressions.sql

td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/activity.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/activity_categories.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/activity_types.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/ads.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/advertisers.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/campaigns.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/click.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/creatives.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/impression.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/placements.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/placement_cost.sql
td query -d db_stg_gcm_bi -t presto -w -q ./paid_incremental/01_tables/ddl_db_stg_gcm_bi/sites.sql

