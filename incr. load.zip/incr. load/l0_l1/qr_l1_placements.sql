delete from db_l1_bi_gcm.placements where time > 0;
insert into  db_l1_bi_gcm.placements ( 
record_id, 
createddate, 
createdby,
lastmodifieddate,
lastmodifiedby,
campaign_id,
site_id,
placement_id, 
site_keyname, 
placement, 
content_category, 
placement_strategy, 
placement_start_date, 
placement_end_date, 
placement_group_type, 
package_roadblock_id, 
placement_cost_structure, 
placement_cap_cost_option, 
activity_id, 
flighting_activated, 
gcm_insert_date, 
time 
)
    select distinct 
	a.record_id, 	
    a.createddate,
    a.createdby,
    a.lastmodifieddate,
    a.lastmodifiedby, 
    a.campaign_id,
    a.site_id,
    a.placement_id, 
    a.site_keyname, 
    a.placement, 
    a.content_category, 
    a.placement_strategy, 
    a.placement_start_date, 
    a.placement_end_date, 
    a.placement_group_type, 
    a.package_roadblock_id, 
    a.placement_cost_structure, 
    a.placement_cap_cost_option, 
    a.activity_id, 
    a.flighting_activated, 
    a.gcm_insert_date, 
    a.time 
    from ( 
    select distinct 
	rec_id.max_id + cast(row_number() over (order by l0.time) as bigint) record_id, 
    l0.createddate,
    l0.createdby,
    l0.lastmodifieddate,
    l0.lastmodifiedby, 
    l0.campaign_id,
    l0.site_id_dcm as site_id,
    l0.placement_id, 
    l0.site_keyname, 
    l0.placement, 
    l0.content_category, 
    l0.placement_strategy, 
    l0.placement_start_date, 
    l0.placement_end_date, 
    l0.placement_group_type, 
    l0.package_roadblock_id, 
    l0.placement_cost_structure, 
    l0.placement_cap_cost_option, 
    l0.activity_id, 
    l0.flighting_activated, 
    l0.gcm_insert_date, 
    l0.time 
from 
( SELECT 
  p3.Placement_ID,
  cast(TO_UNIXTIME(CAST(MAX(p3.createddate) AS TIMESTAMP)) AS BIGINT) as createddate, 
  MAX(p3.createdby) as createdby, 
  cast(TO_UNIXTIME(CAST(MAX(p3.lastmodifieddate) AS TIMESTAMP)) AS BIGINT) as lastmodifieddate, 
  MAX(p3.lastmodifiedby) as lastmodifiedby, 
  MAX(p3.campaign_id) as campaign_id,
  MAX(p3.site_id_dcm) as site_id_dcm,
  MAX(p3.site_keyname) as site_keyname, 
  MAX(p3.content_category) as content_category, 
  MAX(p3.placement_strategy) as placement_strategy, 
  MAX(p3.placement_start_date) as placement_start_date, 
  MAX(p3.placement_end_date) as placement_end_date, 
  MAX(p3.placement_group_type) as placement_group_type, 
  MAX(p3.package_roadblock_id) as package_roadblock_id, 
  MAX(p3.placement_cost_structure) as placement_cost_structure, 
  MAX(p3.placement_cap_cost_option) as placement_cap_cost_option, 
  MAX(p3.activity_id) as activity_id, 
  MAX(p3.flighting_activated) as flighting_activated, 
  MAX(p3.gcm_insert_date) as gcm_insert_date, 
  MAX(p3.time) as time,   
  MAX(p4.placement_name_selected) as placement

  FROM db_l0_gcm_bi.placements_match as p3  
  LEFT JOIN 
  (
  SELECT
  p2.Placement_ID,
  p2.Placement as placement_name_selected
  FROM db_l0_gcm_bi.placements_match as p2
  LEFT JOIN 
  (
  SELECT 
  p0.Placement_ID,
  MAX(length(Placement)) as max_name_length
  FROM db_l0_gcm_bi.placements_match p0
  Group by Placement_ID
  ) as p1 on p2.Placement_ID = p1.Placement_ID
  where length(Placement) = max_name_length
  Group by p2.Placement_ID, p2.Placement
  ) as p4 on p3.Placement_ID = p4.Placement_ID
  GROUP BY 1) as l0, 
(select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_gcm.placements) rec_id  ) a;  