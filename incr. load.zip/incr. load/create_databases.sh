td db:create db_l0_gcm_bi
td db:create db_l1_bi_gcm
td db:create db_l2_bi
td db:create db_stg_gcm_bi
