echo '-----------------------------------------------'
echo '----------------- Installation ----------------'
echo '-----------------------------------------------'
echo '--------------- Create databases --------------'
./paid_incremental/create_databases.sh
echo '--------------- Create tables -----------------'
./paid_incremental/create_tables.sh
echo '--------------- Create workflow ---------------'
./paid_incremental/create_workflows.sh
echo '--------------- Creating connectors -----------'
./paid_incremental/create_connectors.sh
