td table:delete db_l0_gcm_bi activity -f
td table:delete db_l0_gcm_bi activity_categories -f
td table:delete db_l0_gcm_bi activity_types -f
td table:delete db_l0_gcm_bi ads -f
td table:delete db_l0_gcm_bi advertisers -f
td table:delete db_l0_gcm_bi campaigns_match -f
td table:delete db_l0_gcm_bi click -f
td table:delete db_l0_gcm_bi creatives_match -f
td table:delete db_l0_gcm_bi impression -f
td table:delete db_l0_gcm_bi placements_match -f
td table:delete db_l0_gcm_bi placement_cost -f
td table:delete db_l0_gcm_bi sites_match -f

td table:delete db_l1_bi_gcm campaigns -f
td table:delete db_stg_gcm_bi campaigns -f