delete from db_stg_gcm_bi.placement_cost where time > 0; 

insert into db_stg_gcm_bi.placement_cost ( 
createddate, 
createdby, 
lastmodifieddate, 
lastmodifiedby, 
placement_id ,
placement_start_date ,
placement_end_date ,
placement_total_booked_units ,
placement_rate ,
placement_comments , 
gcm_insert_date, 
date, 
time  
)
          select 
          cast(TO_UNIXTIME(CAST(L0.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	      L0.createdby as createdby,
	      cast(TO_UNIXTIME(CAST(L0.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	      L0.lastmodifiedby as lastmodifiedby, 
		  L0.placement_id ,
		  L0.placement_start_date ,
		  L0.placement_end_date ,
		  L0.placement_total_booked_units ,
		  L0.placement_rate ,
		  L0.placement_comments , 
		  L0.gcm_insert_date, 
		  L0.date, 
		  L0.time 
from db_l0_gcm_bi.placement_cost L0;  