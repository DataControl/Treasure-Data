delete from db_stg_gcm_bi.activity_types where time > 0;
insert into db_stg_gcm_bi.activity_types ( 
createddate	, 
createdby	,
lastmodifieddate	,
lastmodifiedby	,
activity_group_id ,
activity_type ,
activity_group, 
date, 
gcm_insert_date, 
time 
 )
    select 
	  cast(TO_UNIXTIME(CAST(L0.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	    l0.createdby,
	    cast(TO_UNIXTIME(CAST(L0.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	    l0.lastmodifiedby, 
		l0.activity_group_id ,
		l0.activity_type ,
		l0.activity_group, 
		l0.date, 
		l0.gcm_insert_date, 
		l0.time 
from db_l0_gcm_bi.activity_types l0;