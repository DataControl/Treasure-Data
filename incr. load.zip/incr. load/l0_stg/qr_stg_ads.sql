delete from db_stg_gcm_bi.ads where time > 0;
insert into  db_stg_gcm_bi.ads ( 
createddate, 
createdby,
lastmodifieddate,
lastmodifiedby,
advertiser_id,
campaign_id,
ad_id,
ad,
ad_click_url,
ad_type,
ad_comments, 
gcm_insert_date, 
time               
)
    select 
    cast(TO_UNIXTIME(CAST(L0.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
    l0.createdby,
    cast(TO_UNIXTIME(CAST(L0.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
    l0.lastmodifiedby, 
    l0.advertiser_id ,
    l0.campaign_id ,
    l0.ad_id ,
    l0.ad ,
    l0.ad_click_url ,
    l0.ad_type ,
    l0.ad_comments, 
    l0.gcm_insert_date, 
	l0.time 
from db_l0_gcm_bi.ads l0;  