delete from db_stg_gcm_bi.campaigns where time > 0; 
insert into db_stg_gcm_bi.campaigns ( 
 createddate, 
createdby,
lastmodifieddate,
lastmodifiedby,
advertiser_id,
campaign_id,
campaign,
campaign_start_date ,
campaign_end_date, 
gcm_insert_date, 
time   	
) 
    select 
	  cast(TO_UNIXTIME(CAST(l0.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	    l0.createdby,
	    cast(TO_UNIXTIME(CAST(l0.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	    l0.lastmodifiedby, 
		l0.advertiser_id,
		l0.campaign_id,
		l0.campaign , 
		l0.campaign_start_date, 
		l0.campaign_end_date, 
		l0.gcm_insert_date, 
		l0.time 
FROM db_l0_gcm_bi.campaigns_match l0; 