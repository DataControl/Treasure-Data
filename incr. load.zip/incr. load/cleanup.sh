td connector:delete con_db_l0_gcm_bi_activity
td connector:delete con_db_l0_gcm_bi_activity_categories
td connector:delete con_db_l0_gcm_bi_activity_types
td connector:delete con_db_l0_gcm_bi_ads
td connector:delete con_db_l0_gcm_bi_advertisers
td connector:delete con_db_l0_gcm_bi_campaigns_match
td connector:delete con_db_l0_gcm_bi_click
td connector:delete con_db_l0_gcm_bi_creatives_match
td connector:delete con_db_l0_gcm_bi_impression
td connector:delete con_db_l0_gcm_bi_placements_match
td connector:delete con_db_l0_gcm_bi_placement_cost
td connector:delete con_db_l0_gcm_bi_sites_match

td table:delete db_l0_gcm_bi activity -f
td table:delete db_l0_gcm_bi activity_categories -f
td table:delete db_l0_gcm_bi activity_types -f
td table:delete db_l0_gcm_bi ads -f
td table:delete db_l0_gcm_bi advertisers -f
td table:delete db_l0_gcm_bi campaigns_match -f
td table:delete db_l0_gcm_bi click -f
td table:delete db_l0_gcm_bi creatives_match -f
td table:delete db_l0_gcm_bi impression -f
td table:delete db_l0_gcm_bi placements_match -f
td table:delete db_l0_gcm_bi placement_cost -f
td table:delete db_l0_gcm_bi sites_match -f
td table:delete db_l1_bi_gcm activity -f
td table:delete db_l1_bi_gcm activity_categories -f
td table:delete db_l1_bi_gcm activity_types -f
td table:delete db_l1_bi_gcm ads -f
td table:delete db_l1_bi_gcm advertisers -f
td table:delete db_l1_bi_gcm campaigns -f
td table:delete db_l1_bi_gcm click -f
td table:delete db_l1_bi_gcm creatives -f
td table:delete db_l1_bi_gcm impression -f
td table:delete db_l1_bi_gcm placements -f
td table:delete db_l1_bi_gcm placement_cost -f
td table:delete db_l1_bi_gcm sites -f
td table:delete db_l2_bi activity -f
td table:delete db_l2_bi campaigns -f
td table:delete db_l2_bi click -f
td table:delete db_l2_bi impressions -f
td table:delete db_stg_gcm_bi activity -f
td table:delete db_stg_gcm_bi activity_categories -f
td table:delete db_stg_gcm_bi activity_types -f
td table:delete db_stg_gcm_bi ads -f
td table:delete db_stg_gcm_bi advertisers -f
td table:delete db_stg_gcm_bi campaigns -f
td table:delete db_stg_gcm_bi click -f
td table:delete db_stg_gcm_bi creatives -f
td table:delete db_stg_gcm_bi impression -f
td table:delete db_stg_gcm_bi placements -f
td table:delete db_stg_gcm_bi placement_cost -f
td table:delete db_stg_gcm_bi sites -f

digdag delete pr_load_from_gcm -e ${jenkins-td-eu-endpoint_url} -X client.http.headers.authorization='TD1 ${jenkins-td-eu-api_key}' --force
