delete from db_l1_bi_gcm.advertisers where time > 0;
insert into  db_l1_bi_gcm.advertisers
(record_id ,
createddate      , 
createdby   ,
lastmodifieddate  ,
lastmodifiedby    ,
advertiser_id ,
advertiser ,
advertiser_group_id ,
advertiser_group, 
gcm_insert_date, 
time 
)
    select
     rec_id.max_id + cast(row_number() over (order by l0.time) as bigint) record_Id,
        cast(TO_UNIXTIME(CAST(L0.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
          l0.createdby,
          cast(TO_UNIXTIME(CAST(L0.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
          l0.lastmodifiedby, 
            l0.advertiser_id ,
            l0.advertiser ,
            l0.advertiser_group_id ,
            l0.advertiser_group, 
            cast(TO_UNIXTIME(CAST(L0.gcm_insert_date AS TIMESTAMP)) AS BIGINT) as gcm_insert_date,  l0.time 
from (
SELECT 
advertiser_id,
MAX(time) as time,
MAX(floodlight_configuration) as floodlight_configuration,
MAX(advertiser) as advertiser,
MAX(advertiser_group_id) as advertiser_group_id,
MAX(advertiser_group) as advertiser_group,
MAX(date) as date,
MAX(gcm_insert_date) as gcm_insert_date,
MAX(createddate) as createddate, 
MAX(createdby) as createdby,
MAX(lastmodifieddate) as lastmodifieddate,
MAX(lastmodifiedby) as lastmodifiedby
from db_l0_gcm_bi.advertisers
GROUP BY 1) l0,
(select  COALESCE (cast(max(record_id) as bigint),0) max_id from db_l1_bi_gcm.advertisers) rec_id
