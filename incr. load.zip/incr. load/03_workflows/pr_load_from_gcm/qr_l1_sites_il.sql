delete from db_l1_bi_gcm.sites_il where time > 0;
insert into  db_l1_bi_gcm.sites_il ( 
record_id, 
createddate	, 
createdby	,
lastmodifieddate	,
lastmodifiedby	,
site_id,
site,
site_id_site_directory, 
site_site_directory, 
gcm_insert_date, 
time )
    select distinct 
	a.record_id, 
	a.createddate	, 
	a.createdby	,
	a.lastmodifieddate	,
	a.lastmodifiedby	,
	a.site_id,
	a.site,
	a.site_id_site_directory, 
	a.site_site_directory, 
	a.gcm_insert_date,  
	a.time  
from (
	select distinct 
	  rec_id.max_id + cast(row_number() over (order by s.time) as bigint) record_id, 
	  cast(TO_UNIXTIME(CAST(s.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	    s.createdby,
	    cast(TO_UNIXTIME(CAST(s.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	    s.lastmodifiedby, 
		s.site_id,
		s.site,
		s.site_id_site_directory, 
		s.site_site_directory, 
		s.gcm_insert_date, 
		s.time 
from  ( 
SELECT DISTINCT site_id_dcm as site_id,
		MAX(l0.site_dcm) as site, 
		MAX(l0.createddate) as createddate, 
		MAX(l0.createdby) as createdby,
		MAX(l0.lastmodifieddate) as lastmodifieddate,
        MAX(l0.lastmodifiedby) as lastmodifiedby, 
		MAX(l0.site_id_site_directory) as site_id_site_directory, 
		MAX(l0.site_site_directory) as site_site_directory, 
		MAX(l0.gcm_insert_date) as gcm_insert_date, 
		MAX(l0.time) as time  
  FROM db_l0_gcm_bi.sites_match l0
  GROUP BY 1 order by 1)s, 
  (select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_gcm.sites_il) rec_id ) a; 