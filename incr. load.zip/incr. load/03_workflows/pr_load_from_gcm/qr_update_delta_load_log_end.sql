insert into db_stg_bi_technical.delta_load_log_dce
select layer, operation_mode, entity_name, last_load_ts, number_of_retries,  0 as completion_flag
from db_stg_bi_technical.delta_load_log_dce
where time = (
select max(time) from db_stg_bi_technical.delta_load_log_dce where layer = 'db_l0_gcm_bi' and entity_name= 'paid_gcm' and operation_mode = 'insert' and completion_flag = 1
) and layer = 'db_l0_gcm_bi' and entity_name= 'paid_gcm' and operation_mode = 'insert' and completion_flag = 1
and cast(TD_TIME_FORMAT(TD_TIME_ADD(last_load_ts, '5d'),'yyyyMMdd') as bigint) <=  cast(TD_TIME_FORMAT(cast(to_unixtime(CURRENT_TIMESTAMP) as bigint),'yyyyMMdd') as bigint)

 and 0  <> (select cast( count(*) as bigint) as cnt
from 
( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank
  from db_stg_bi_technical.delta_load_log_dce  where layer = 'db_l0_gcm_bi' and entity_name= 'paid_gcm' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ),
          ( select last_load_ts as end_date_initial from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank
  from db_stg_bi_technical.delta_load_log_dce  where layer = 'paid_gcm_intial'  and entity_name= 'paid_intial' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ) b
          where  cast(TD_TIME_FORMAT(TD_TIME_ADD(last_load_ts, '5d'),'yyyyMMdd') as bigint) <=  cast(TD_TIME_FORMAT(b.end_date_initial,'yyyyMMdd') as bigint));

delete
from db_stg_bi_technical.delta_load_log_dce
where time = (
select max(time) from db_stg_bi_technical.delta_load_log_dce where layer = 'db_l0_gcm_bi' and entity_name= 'paid_gcm' and operation_mode = 'insert' and completion_flag = 1
) and layer = 'db_l0_gcm_bi' and entity_name= 'paid_gcm' and operation_mode = 'insert' and completion_flag = 1
and 0  <> (select cast( count(*) as bigint) as cnt
from 
( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank
  from db_stg_bi_technical.delta_load_log_dce  where layer = 'db_l0_gcm_bi' and entity_name= 'paid_gcm' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ),
          ( select last_load_ts as end_date_initial  from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank
  from db_stg_bi_technical.delta_load_log_dce  where layer = 'paid_gcm_intial'  and entity_name= 'paid_intial' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ) b
          where  cast(TD_TIME_FORMAT(last_load_ts,'yyyyMMdd') as bigint) <=  cast(TD_TIME_FORMAT(b.end_date_initial,'yyyyMMdd') as bigint));