delete from db_l1_bi_gcm.campaigns where time > 0;
insert into  db_l1_bi_gcm.campaigns
 (record_id	,
 createddate	, 
createdby	,
lastmodifieddate	,
lastmodifiedby	,
advertiser_id ,
campaign_id ,
campaign ,
campaign_start_date ,
campaign_end_date, 
gcm_insert_date, 
time   	
) 
select 
a.record_id	,
a.createddate	, 
a.createdby	,
a.lastmodifieddate	,
a.lastmodifiedby	,
a.advertiser_id ,
a.campaign_id ,
a.campaign, 
a.campaign_start_date ,
a.campaign_end_date, 
a.gcm_insert_date, 
a.time  
from (
    select
     rec_id.max_id + cast(row_number() over (order by l0.time) as bigint) record_Id,
	  cast(TO_UNIXTIME(CAST(L0.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	    l0.createdby,
	    cast(TO_UNIXTIME(CAST(L0.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	    l0.lastmodifiedby, 
		l0.advertiser_id,
		l0.campaign_id,
		l0.campaign , 
		l0.campaign_start_date, 
		l0.campaign_end_date, 
		cast(TO_UNIXTIME(CAST(l0.gcm_insert_date AS TIMESTAMP)) AS BIGINT) as gcm_insert_date, 
		l0.time 
from 

(SELECT cm.campaign_id, 
MAX(cm.time) as time,
MAX(cm.createddate) as createddate,
MAX(cm.createdby) as createdby,
MAX(cm.lastmodifieddate) as lastmodifieddate,
MAX(cm.lastmodifiedby) as lastmodifiedby,
MAX(cm.advertiser_id) as advertiser_id,
MAX(cm.gcm_insert_date) as gcm_insert_date, 
MAX(cm2.campaign_name) as campaign,
MAX(cm.campaign_start_date) as campaign_start_date,
MAX(cm.campaign_end_date) as campaign_end_date,
MAX(cm.billing_invoice_code) as billing_invoice_code,
MAX(cm.date) as date 

FROM db_l0_gcm_bi.campaigns_match as cm 
LEFT JOIN
(
  SELECT campaign_id, 
  CASE WHEN cnt_date = 1 THEN max_campaign_name
       ELSE campaign
       END AS campaign_name
  FROM(
  SELECT cbase.campaign_id, cbase.campaign, cbase.campaign_end_date, cdate.max_date, cname.max_campaign_name, cdate.cnt_date
  FROM 
  (SELECT campaign_id, campaign, campaign_end_date FROM db_l0_gcm_bi.campaigns_match) as cbase
  LEFT JOIN 
  (SELECT campaign_id, campaign, COUNT(DISTINCT(campaign_end_date)) as cnt_date, MAX(campaign_end_date) as max_date
  FROM db_l0_gcm_bi.campaigns_match
  GROUP BY 1,2) as cdate on cdate.campaign_id = cbase.campaign_id
  LEFT JOIN 
  (SELECT campaign_id,
  MAX(campaign) as max_campaign_name
  FROM db_l0_gcm_bi.campaigns_match
  GROUP BY 1) as cname on cname.campaign_id = cbase.campaign_id
  WHERE campaign_end_date = max_date 
  GROUP BY 1,2,3,4,5,6
  )
  GROUP BY 1,2
) as cm2
on cm.campaign_id = cm2.campaign_id
GROUP By 1 
order by campaign_id ) l0, 
(select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_gcm.campaigns) rec_id )a  