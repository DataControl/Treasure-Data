delete from db_l1_bi_gcm.ga_data_set_gcm_extension where date_hour in 
(select distinct date_hour from db_l0_gcm_bi.ga_data_set_gcm_extension);

insert into  db_l1_bi_gcm.ga_data_set_gcm_extension (
	date_hour,  
   dcm_click_campaign_id,  
   dcm_click_advertiser_id,  
   dcm_click_site_id,  
   dcm_click_site_placement_id,  
   dcm_click_creative_id,  
   sessions,  
   bounces,  
   transaction_revenue , 
   view_id,  
   pageviews,  
   entrances,  
   dcm_click_rendering_id,  
   users 
)
    select
		L0.date_hour ,
		L0.dcm_click_campaign_id ,
		L0.dcm_click_advertiser_id ,
		L0.dcm_click_site_id ,
		L0.dcm_click_site_placement_id ,
		L0.dcm_click_creative_id ,
		L0.sessions ,
		L0.bounces ,
		L0.transaction_revenue ,
		L0.view_id ,
		L0.pageviews ,
		L0.entrances ,
		L0.dcm_click_rendering_id ,
		L0.users  
from  db_l0_gcm_bi.ga_data_set_gcm_extension L0