delete from db_stg_gcm_bi.ga_data_set_gcm_extension where date_hour in 
(select distinct date_hour  from db_l0_gcm_bi.ga_data_set_gcm_extension);

insert into  db_stg_gcm_bi.ga_data_set_gcm_extension ( 
	date_hour,  
   dcm_click_campaign_id,  
   dcm_click_advertiser_id,  
   dcm_click_site_id,  
   dcm_click_site_placement_id,  
   dcm_click_creative_id,  
   sessions,  
   bounces,  
   transaction_revenue , 
   view_id,  
   pageviews,  
   entrances,  
   dcm_click_rendering_id,  
   users 
)
              select 
              l0.date_hour ,
		l0.dcm_click_campaign_id ,
		l0.dcm_click_advertiser_id ,
		l0.dcm_click_site_id ,
		l0.dcm_click_site_placement_id ,
		l0.dcm_click_creative_id ,
		l0.sessions ,
		l0.bounces ,
		l0.transaction_revenue ,
		l0.view_id ,
		l0.pageviews ,
		l0.entrances ,
		l0.dcm_click_rendering_id ,
		l0.users 

from   db_l0_gcm_bi.ga_data_set_gcm_extension L0