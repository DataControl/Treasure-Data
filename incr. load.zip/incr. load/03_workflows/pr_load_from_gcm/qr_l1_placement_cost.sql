delete from db_l1_bi_gcm.placement_cost where time > 0;

insert into db_l1_bi_gcm.placement_cost ( 
record_id, 
createddate, 
createdby, 
lastmodifieddate, 
lastmodifiedby, 
placement_id ,
placement_start_date ,
placement_end_date ,
placement_total_booked_units ,
placement_rate ,
placement_comments , 
date, 
gcm_insert_date, 
time )   
select  
	s.record_id, 
    s.createddate,
	s.createdby as createdby,
	s.lastmodifieddate,
	s.lastmodifiedby as lastmodifiedby, 
	s.placement_id ,
	s.placement_start_date ,
	s.placement_end_date ,
	s.placement_total_booked_units ,
	s.placement_rate ,
	s.placement_comments , 
	s.date, 
	s.gcm_insert_date, 
	s.time 
from ( 
    select distinct  
		  rec_id.max_id + cast(row_number() over (order by a.time) as bigint) record_id, 
          cast(TO_UNIXTIME(CAST(a.createddate AS TIMESTAMP)) AS BIGINT) as createddate, 
	      a.createdby as createdby,
	      cast(TO_UNIXTIME(CAST(a.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	      a.lastmodifiedby as lastmodifiedby, 
		  a.placement_id ,
		  a.placement_start_date ,
		  a.placement_end_date ,
		  a.placement_total_booked_units ,
		  a.placement_rate ,
		  a.placement_comments , 
		  a.date, 
		  a.gcm_insert_date, 
		  a.time 
from  
 (SELECT DISTINCT l0.placement_id, 
    l0.date as partitioned_date,
		MAX(l0.createddate) as createddate,
		MAX(l0.createdby) as createdby,  
		MAX(l0.lastmodifieddate) as lastmodifieddate, 
		MAX(l0.lastmodifiedby)as lastmodifiedby, 
		MAX(l0.placement_start_date) as placement_start_date, 
		MAX(l0.placement_end_date) as placement_end_date, 
    MAX(l0.placement_total_booked_units) as placement_total_booked_units,
		MAX(l0.placement_rate)/1000000000 as placement_rate, 
    MAX(l0.placement_comments) as placement_comments,  
	MAX(l0.date) as date, 
		MAX(l0.gcm_insert_date) as gcm_insert_date, 
		MAX(l0.time) as time 
FROM db_l0_gcm_bi.placement_cost l0 
LEFT JOIN (SELECT placement_id, MAX(date) as max_date FROM db_l0_gcm_bi.placement_cost GROUP by 1) as md on l0.placement_id = md.placement_id
WHERE date = md.max_date
GROUP BY 1,2) as a,   
(select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_gcm.placement_cost) rec_id ) s;  