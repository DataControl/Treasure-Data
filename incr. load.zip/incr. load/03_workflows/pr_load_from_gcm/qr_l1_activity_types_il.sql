delete from db_l1_bi_gcm.activity_types_il where time > 0;
insert into  db_l1_bi_gcm.activity_types_il  
 (record_id	,
 createddate	, 
createdby	,
lastmodifieddate	,
lastmodifiedby	,
activity_group_id ,
activity_type ,
activity_group, 
date, 
gcm_insert_date, 
time 
 )
    select
     rec_id.max_id + cast(row_number() over (order by s.time) as bigint) record_Id,
	  cast(TO_UNIXTIME(CAST(s.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	    s.createdby,
	    cast(TO_UNIXTIME(CAST(s.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	    s.lastmodifiedby, 
		s.activity_group_id ,
		s.activity_type ,
		s.activity_group, 
		s.date, 
		s.gcm_insert_date, 
		s.time 
from   
(SELECT DISTINCT activity_group_id, 
		MAX(l0.createddate) as createddate,
		MAX(l0.createdby) as createdby,  
		MAX(l0.lastmodifieddate) as lastmodifieddate, 
		MAX(l0.lastmodifiedby)as lastmodifiedby, 
		MAX(l0.activity_type) as activity_type, 
        MAX(l0.activity_group) as activity_group,   
		MAX(l0.date) as date, 
		MAX(l0.gcm_insert_date) as gcm_insert_date, 
		MAX(l0.time) as time  
		from db_l0_gcm_bi.activity_types l0 GROUP BY 1) as s, 
(select  COALESCE (cast(max(record_id) as bigint),0) max_id from db_l1_bi_gcm.activity_types_il) rec_id ;