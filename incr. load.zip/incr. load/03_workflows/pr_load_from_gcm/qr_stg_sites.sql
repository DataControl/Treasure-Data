delete from db_stg_gcm_bi.sites where time > 0;
insert into  db_stg_gcm_bi.sites ( 
createddate	, 
createdby	,
lastmodifieddate	,
lastmodifiedby	,
site_id,
site,
site_id_site_directory, 
site_site_directory, 
gcm_insert_date, 
time ) 
	select  
	  cast(TO_UNIXTIME(CAST(s.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	    s.createdby,
	    cast(TO_UNIXTIME(CAST(s.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	    s.lastmodifiedby, 
		s.site_id_dcm as site_id, 
		s.site_dcm as site, 
		s.site_id_site_directory, 
		s.site_site_directory, 
		cast(TO_UNIXTIME(CAST(s.gcm_insert_date AS TIMESTAMP)) AS BIGINT) as gcm_insert_date, 
		s.time 
  FROM db_l0_gcm_bi.sites_match s; 