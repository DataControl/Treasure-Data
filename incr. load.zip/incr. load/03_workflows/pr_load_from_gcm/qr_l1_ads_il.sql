delete from db_l1_bi_gcm.ads_il where time > 0;
insert into  db_l1_bi_gcm.ads_il  
 (record_id          ,
createddate      , 
createdby           ,
lastmodifieddate             ,
lastmodifiedby  ,
advertiser_id ,
campaign_id ,
ad_id ,
ad ,
ad_click_url ,
ad_type ,
ad_comments, 
gcm_insert_date              
)
    select
     rec_id.max_id + cast(row_number() over (order by l0.time) as bigint) record_Id,
                  cast(TO_UNIXTIME(CAST(L0.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
                    l0.createdby,
                    cast(TO_UNIXTIME(CAST(L0.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
                    l0.lastmodifiedby, 
                                l0.advertiser_id ,
                                l0.campaign_id ,
                                l0.ad_id ,
                                l0.ad ,
                                l0.ad_click_url ,
                                l0.ad_type ,
                                l0.ad_comments, 
                                l0.gcm_insert_date  
from  (
SELECT 
ad_id,
MAX(time) as time,
MAX(advertiser_id) as advertiser_id,
MAX(campaign_id) as campaign_id,
MAX(ad) as ad,
MAX(ad_click_url) as ad_click_url,
MAX(ad_type) as ad_type,
MAX(creative_pixel_size) as creative_pixel_size,
MAX(ad_comments) as ad_comments,
MAX(date) as date,
MAX(gcm_insert_date) as gcm_insert_date,
MAX(createddate) as createddate,
MAX(createdby) as createdby,
MAX(lastmodifieddate) as lastmodifieddate,
MAX(lastmodifiedby) as lastmodifiedby 
from db_l0_gcm_bi.ads
GROUP BY 1
) l0, 
(select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_gcm.ads_il) rec_id;