delete from db_l2_bi.campaigns where time > 0; 

insert into  db_l2_bi.campaigns ( 
record_id, 
createddate, 
createdby, 
lastmodifieddate, 
lastmodifiedby, 
campaign_id, 
advertiser_id, 
campaign, 
campaign_start_date, 
campaign_end_date, 
gcm_insert_date )

select
    i.record_id, 
	i.createddate, 
	i.createdby, 
	i.lastmodifieddate, 
	i.lastmodifiedby, 
	i.campaign_id, 
	i.advertiser_id, 
	i.campaign, 
	i.campaign_start_date, 
	i.campaign_end_date, 
	i.gcm_insert_date    
from db_l1_bi_gcm.campaigns i; 