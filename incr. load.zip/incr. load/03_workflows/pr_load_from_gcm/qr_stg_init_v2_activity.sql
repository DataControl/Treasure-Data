delete from db_stg_gcm_bi.activity_il where event_time in 
(select distinct event_timestamp from db_l0_gcm_bi.activity_il);

insert into  db_stg_gcm_bi.activity_il ( 
createddate, 
createdby, 
lastmodifieddate, 
lastmodifiedby,    
activity_id, 
event_time, 
user_id, 
advertiser_id, 
campaign_id, 
ad_id, 
rendering_id, 
creative_version, 
placement_id, 
interaction_time, 
conversion_id, 
country_code, 
event_type, 
event_sub_type, 
segment_value,  
date, 
gcm_insert_date 
)
              select 
              cast(TO_UNIXTIME(CAST(L0.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	      L0.createdby as createdby,
	      cast(TO_UNIXTIME(CAST(L0.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	      L0.lastmodifiedby as lastmodifiedby,   
  		  L0.activity_id, 
		  L0.event_timestamp as event_time, 
		  L0.user_id, 
		  L0.advertiser_id, 
		  L0.campaign_id, 
		  L0.ad_id, 
		  L0.rendering_id, 
		  L0.creative_version, 
		  L0.placement_id, 
		  L0.interaction_time, 
		  L0.conversion_id, 
		  L0.country_code, 
		  L0.event_type, 
		  L0.event_sub_type, 
		  L0.segment_value_1 as segment_value, 
		  L0.date, 
      L0.gcm_insert_date 
from  db_l0_gcm_bi.activity_il L0; 