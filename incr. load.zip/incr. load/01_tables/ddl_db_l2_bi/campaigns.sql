CREATE TABLE "td-presto".db_l2_bi.campaigns(
record_id bigint,
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
campaign_id varchar,
advertiser_id varchar,
campaign varchar,
campaign_start_date varchar,
campaign_end_date varchar,
gcm_insert_date bigint
)
