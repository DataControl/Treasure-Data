CREATE TABLE "td-presto".db_l0_gcm_bi.sites_match (
   site_id_dcm varchar,
   site_dcm varchar,
   site_id_site_directory varchar,
   site_site_directory varchar,
   date varchar,
   gcm_insert_date varchar,
   createddate varchar,
   createdby varchar,
   lastmodifieddate varchar,
   lastmodifiedby varchar 
);