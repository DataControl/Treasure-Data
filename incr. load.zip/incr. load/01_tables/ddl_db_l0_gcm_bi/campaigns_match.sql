CREATE TABLE "td-presto".db_l0_gcm_bi.campaigns_match (
   advertiser_id varchar,
   campaign_id varchar,
   campaign varchar,
   campaign_start_date varchar,
   campaign_end_date varchar,
   billing_invoice_code varchar, 
   date varchar, 
   gcm_insert_date varchar,
   createddate varchar,
   createdby varchar,
   lastmodifieddate varchar,
   lastmodifiedby varchar 
); 