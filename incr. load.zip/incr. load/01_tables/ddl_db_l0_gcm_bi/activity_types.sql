CREATE TABLE "td-presto".db_l0_gcm_bi.activity_types (
   activity_group_id varchar,
   activity_type varchar,
   activity_group varchar,
   date varchar,
   gcm_insert_date varchar,
   createddate varchar,
   createdby varchar,
   lastmodifieddate varchar,
   lastmodifiedby varchar 
);