CREATE TABLE "td-presto".db_l0_gcm_bi.ads (
   advertiser_id varchar,
   campaign_id varchar,
   ad_id varchar,
   ad varchar,
   ad_click_url varchar,
   ad_type varchar,
   ad_comments varchar,
   creative_pixel_size varchar,
   date varchar,
   gcm_insert_date varchar,
   createddate varchar,
   createdby varchar,
   lastmodifieddate varchar,
   lastmodifiedby varchar 
);