CREATE TABLE "td-presto".db_l0_gcm_bi.creatives_match (
   advertiser_id varchar,
   rendering_id varchar,
   creative_id varchar,
   creative varchar,
   creative_last_modified_date varchar,
   creative_type varchar,
   creative_pixel_size varchar,
   creative_image_url varchar,
   creative_version bigint,
   date varchar,
   gcm_insert_date varchar,
   createddate varchar,
   createdby varchar,
   lastmodifieddate varchar,
   lastmodifiedby varchar 
);