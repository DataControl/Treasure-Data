CREATE TABLE "td-presto".db_l0_gcm_bi.advertisers (
   advertiser_id varchar,
   advertiser varchar,
   advertiser_group_id varchar,
   advertiser_group varchar,
   floodlight_configuration varchar,
   date varchar,
   gcm_insert_date varchar,
   createddate varchar,
   createdby varchar,
   lastmodifieddate varchar,
   lastmodifiedby varchar 
);