CREATE TABLE "td-presto".db_l1_bi_gcm.advertisers(
record_id bigint,
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
advertiser_id varchar,
advertiser varchar,
advertiser_group_id varchar,
advertiser_group varchar,
gcm_insert_date bigint
)
