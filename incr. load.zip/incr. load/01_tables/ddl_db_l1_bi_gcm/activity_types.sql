CREATE TABLE "td-presto".db_l1_bi_gcm.activity_types(
record_id bigint,
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
activity_group_id varchar,
activity_type varchar,
activity_group varchar,
date varchar,
gcm_insert_date bigint
)
