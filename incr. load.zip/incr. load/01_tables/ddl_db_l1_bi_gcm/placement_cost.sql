CREATE TABLE "td-presto".db_l1_bi_gcm.placement_cost(
record_id bigint,
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
placement_id varchar,
placement_start_date varchar,
placement_end_date varchar,
placement_total_booked_units bigint,
placement_rate double,
placement_comments varchar,
date varchar,
gcm_insert_date varchar
)
