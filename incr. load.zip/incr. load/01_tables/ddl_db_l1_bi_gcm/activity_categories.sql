CREATE TABLE "td-presto".db_l1_bi_gcm.activity_categories(
record_id bigint,
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
activity_group_id varchar,
activity_type varchar,
activity_id varchar,
activity_sub_type varchar,
activity varchar,
tag_counting_method_id bigint,
date varchar,
gcm_insert_date bigint
)
