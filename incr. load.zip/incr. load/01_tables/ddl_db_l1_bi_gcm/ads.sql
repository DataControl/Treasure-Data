CREATE TABLE "td-presto".db_l1_bi_gcm.ads(
record_id bigint,
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
advertiser_id varchar,
campaign_id varchar,
ad_id varchar,
ad varchar,
ad_click_url varchar,
ad_type varchar,
ad_comments varchar,
gcm_insert_date bigint
)
