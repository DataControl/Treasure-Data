CREATE TABLE "td-presto".db_stg_gcm_bi.activity_categories(
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
activity_group_id varchar,
activity_type varchar,
activity_id varchar,
activity_sub_type varchar,
activity varchar,
tag_counting_method_id bigint,
date varchar,
gcm_insert_date bigint
)
