CREATE TABLE "td-presto".db_stg_gcm_bi.activity_types(
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
activity_group_id varchar,
activity_type varchar,
activity_group varchar,
date varchar,
gcm_insert_date bigint
)
