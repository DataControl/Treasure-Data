CREATE TABLE "td-presto".db_stg_gcm_bi.ads(
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
advertiser_id varchar,
campaign_id varchar,
ad_id varchar,
ad varchar,
ad_click_url varchar,
ad_type varchar,
ad_comments varchar,
gcm_insert_date bigint
)
