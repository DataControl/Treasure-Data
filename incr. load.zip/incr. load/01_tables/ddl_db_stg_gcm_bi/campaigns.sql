CREATE TABLE "td-presto".db_stg_gcm_bi.campaigns(
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
advertiser_id varchar,
campaign_id varchar,
campaign varchar,
campaign_start_date varchar,
campaign_end_date varchar,
gcm_insert_date bigint
)
