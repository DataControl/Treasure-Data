CREATE TABLE "td-presto".db_stg_gcm_bi.creatives(
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
advertiser_id varchar,
rendering_id varchar,
creative_id varchar,
creative varchar,
creative_last_modified_date varchar,
creative_type varchar,
creative_pixel_size varchar,
creative_image_url varchar,
creative_version bigint,
gcm_insert_date bigint
)
