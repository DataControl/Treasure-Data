CREATE TABLE "td-presto".db_stg_gcm_bi.advertisers(
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
advertiser_id varchar,
advertiser varchar,
advertiser_group_id varchar,
advertiser_group varchar,
gcm_insert_date bigint
)
