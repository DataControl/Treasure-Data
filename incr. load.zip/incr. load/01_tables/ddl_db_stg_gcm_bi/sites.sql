CREATE TABLE "td-presto".db_stg_gcm_bi.sites(
createddate bigint,
createdby varchar,
lastmodifieddate bigint,
lastmodifiedby varchar,
site_id varchar,
site varchar,
site_id_site_directory varchar,
site_site_directory varchar,
gcm_insert_date bigint
)
