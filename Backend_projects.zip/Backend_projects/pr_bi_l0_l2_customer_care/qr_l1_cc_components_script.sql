delete from db_l1_bi_csc_legacy.components where createdby <> 'dce2' and
  time >
                ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 );


insert into db_l1_bi_csc_legacy.components
					(   record_id,
						createddate,
						createdby,
						lastmodifieddate,
						lastmodifiedby,	
						componentid,
						componentcode,
						componentdescription
						
					) 
						select  --distinct rec_id.max_id + cast(row_number() over (order by b.time) as bigint) as 	record_Id,
						100004 as record_Id,
								a.createddate,
								a.createdby,
								a.lastmodifieddate,
								a.lastmodifiedby,
								a.componentid,
								a.componentcode,
								a.componentdescription
									from db_stg_bi.components  a
                             left outer join 
                              (
                                           select 
												b.createddate,
												b.createdby,
												b.lastmodifieddate,
												b.lastmodifiedby,												
												b.componentid,
												b.componentcode,
												b.componentdescription,
												b.time
												from  db_l1_bi_csc_legacy.components  a,
											 db_stg_bi.components  b ,
											(select ROW_NUMBER() over (PARTITION by componentid order by time desc) rank,componentid,time from db_l1_bi_csc_legacy.components) r
											where
																						
												coalesce(a.componentid,'na') = coalesce( b.componentid,'na')  and
												coalesce(a.componentcode,'na') = coalesce( b.componentcode,'na')  and
											    coalesce(a.componentdescription,'na') = coalesce( b.componentdescription,'na')	and
												a.componentid = r.componentid
												and a.time=r.time
												and r.rank=1 )b
												on a.componentid = b.componentid /*,
												 (select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_csc_legacy.components) rec_id*/
												where b.componentid  is null