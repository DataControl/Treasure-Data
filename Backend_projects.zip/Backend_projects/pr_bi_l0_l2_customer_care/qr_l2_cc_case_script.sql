insert into db_l2_bi.cases
					(   record_id,
						createddate,
						createdby,
						lastmodifieddate,
						lastmodifiedby,
						case_identifier,
						create_date,
						closing_date,
						time_to_resolution ,
						first_response_time						
						
					) 
						select   record_id,
						createddate,
								createdby,
								lastmodifieddate,
								lastmodifiedby,
								case_identifier,
								cast(from_unixtime(create_date) as varchar),
									cast(from_unixtime(closing_date) as varchar),
								time_to_resolution ,
								first_response_time 
								from 
								(
						
						select 
						   record_id,
						createddate,
								createdby,
								lastmodifieddate,
								lastmodifiedby,
								case_identifier,
								create_date,
								closing_date,
								time_to_resolution ,
								first_response_time,
							 row_number() over (partition by case_identifier order by  time desc) as rank
						  from db_l1_bi_csc_legacy.cases)
												  where rank=1;
                            