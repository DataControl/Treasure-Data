delete from db_stg_bi.devices_lifecycle where time >0;
insert into db_stg_bi.devices_lifecycle
			(
				createddate,
				createdby,
				lastmodifieddate,
				lastmodifiedby,	
				id,
				parentid,
				codentifyid,
				replacedby,
				replaces,
				devicestatus,
				lastactivity,
				lastdeviceupdate,
				isfortrial 	,
				lender	 ,
				replacementchannel	,
				replacementdate 	,
				replacementexternalreference	 ,
				replacementreason	,
				spiceid	 ,
				trialexternalreference	,
				numberofconsumers 	,
				replacementsystemdate	 ,
				exportidautonumber	,
				replacementdoneby	,
				eligigibilityduedate	,
				eligibleforreplacement	,
				subscriptionid	,
				replacementchannelnew	,
				replacementcountry	,
				purchasechannel	,
				careplusdisenrolled	,
				careplusduedate	,
				careplusrequested	,
				careplusstatus	
				)
select distinct 
	createddate,
	createdby,
	lastmodifieddate,
	lastmodifiedby,	
	id,
	parentid,
	codentifyid,
	replacedby,
	replaces,
	devicestatus,
	lastactivity,
	lastdeviceupdate,
	isfortrial 	,
	lender	 ,
	replacementchannel	,
	replacementdate 	,
	replacementexternalreference	 ,
	replacementreason	,
	spiceid	 ,
	trialexternalreference	,
	numberofconsumers 	,
	replacementsystemdate	 ,
	exportidautonumber	,
	replacementdoneby	,
	eligigibilityduedate	,
	eligibleforreplacement	,
	subscriptionid	,
	replacementchannelnew	,
	replacementcountry	,
	purchasechannel	,
	careplusdisenrolled	,
	careplusduedate	,
	careplusrequested	,
	careplusstatus	
from (
select 
delta_dce.created_date as createddate,
delta_dce.created_by as createdby,
delta_dce.last_modified_date  as lastmodifieddate,
delta_dce.last_modified_by as  lastmodifiedby,
'DCE_' || COALESCE(delta_dce.ccr_purchasecountry__c,'') || '_' || COALESCE(delta_dce.id,'') as id,	
delta_dce.parentid as parentid,
delta_dce.ccr_codentifyid__c  as codentifyid,
delta_dce.ccr_replacedby__c as replacedby,
delta_dce.ccr_replaces__c as replaces,
delta_dce.status as devicestatus,
null  as lastactivity,
delta_dce.ccr_isfortrial__c	as	isfortrial ,
delta_dce.ccr_lender__c	as	lender ,
delta_dce.ccr_replacementchannel__c	as	replacementchannel ,
delta_dce.ccr_replacementdate__c	as	replacementdate ,
delta_dce.ccr_replacementexternalreference__c	as	replacementexternalreference ,
delta_dce.ccr_replacementreason__c	as	replacementreason ,
delta_dce.ccr_spiceid__c	as	spiceid ,
delta_dce.ccr_trialexternalreference__c	as	trialexternalreference ,
delta_dce.ccr_numberofconsumers__c	as	numberofconsumers ,
delta_dce.ccr_replacementsystemdate__c	as	replacementsystemdate ,
delta_dce.ccr_exportidautonumber__c	as	exportidautonumber ,
delta_dce.ccr_replacementdoneby__c	as	replacementdoneby ,
delta_dce.ccr_eligibilityduedate__c	as	eligigibilityduedate ,
delta_dce.ccr_eligibleforreplacement__c	as	eligibleforreplacement ,
delta_dce.ccr_subscriptionid__c	as	subscriptionid ,
delta_dce.ccr_replacementchannelnew__c	as	replacementchannelnew ,
delta_dce.ccr_replacementcountry__c	as	replacementcountry ,
delta_dce.ccr_purchasechannel__c	as	purchasechannel ,
delta_dce.ccr_careplusdisenrolled__c	as	careplusdisenrolled ,
delta_dce.ccr_careplusduedate__c	as	careplusduedate ,
delta_dce.ccr_careplusrequested__c	as	careplusrequested ,
delta_dce.ccr_careplusstatus__c	as	careplusstatus	,
cast (to_unixtime(cast(delta_dce.lastmodifieddate as timestamp)) as bigint) as lastdeviceupdate,
row_number() over (partition by 
delta_dce.ccr_codentifyid__c,
delta_dce.ccr_replacedby__c,
delta_dce.ccr_replaces__c,
delta_dce.status,
delta_dce.ccr_isfortrial__c	,
delta_dce.ccr_lender__c	,
delta_dce.ccr_replacementchannel__c	,
delta_dce.ccr_replacementdate__c	,
delta_dce.ccr_replacementexternalreference__c	,
delta_dce.ccr_replacementreason__c	,
delta_dce.ccr_spiceid__c	,
delta_dce.ccr_trialexternalreference__c	,
delta_dce.ccr_numberofconsumers__c	,
delta_dce.ccr_replacementsystemdate__c	,
delta_dce.ccr_exportidautonumber__c	,
delta_dce.ccr_replacementdoneby__c	,
delta_dce.ccr_eligibilityduedate__c	,
delta_dce.ccr_eligibleforreplacement__c	,
delta_dce.ccr_subscriptionid__c	,
delta_dce.ccr_replacementchannelnew__c	,
delta_dce.ccr_replacementcountry__c	,
delta_dce.ccr_purchasechannel__c	,
delta_dce.ccr_careplusdisenrolled__c	,
delta_dce.ccr_careplusduedate__c	,
delta_dce.ccr_careplusrequested__c	,
delta_dce.ccr_careplusstatus__c	
order by cast (to_unixtime(cast(delta_dce.lastmodifieddate as timestamp)) as bigint)) as rank
   from db_stg_current_record_dce_bi.device_sfdc delta_dce
   
    where delta_dce.time > 
	     ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )
					) where rank=1
		
		union
		
select distinct 
createddate,
createdby,
lastmodifieddate,
lastmodifiedby,	
id,
parentid,
codentifyid,
replacedby,
replaces,
devicestatus,
lastactivity,
lastdeviceupdate,
-1  as  isfortrial 	,
	'N/A'  as  lender	 ,
	'N/A'  as  replacementchannel	,
	'N/A'  as  replacementdate 	,
	'N/A'  as  replacementexternalreference	 ,
	'N/A'  as  replacementreason	,
	'N/A'  as  spiceid	 ,
	'N/A'  as  trialexternalreference	,
	-1  as  numberofconsumers 	,
	'N/A'  as  replacementsystemdate	 ,
	'N/A'  as  exportidautonumber	,
	'N/A'  as  replacementdoneby	,
	'N/A'  as  eligigibilityduedate	,
	-1  as  eligibleforreplacement	,
	'N/A'  as  subscriptionid	,
	'N/A'  as  replacementchannelnew	,
	'N/A'  as  replacementcountry	,
	'N/A'  as  purchasechannel	,
	-1  as  careplusdisenrolled	,
	'N/A'  as  careplusduedate	,
	-1  as  careplusrequested	,
	'N/A'  as  careplusstatus
from (
select
created_date as createddate,
created_by as createdby,
last_modified_date as lastmodifieddate,
last_modified_by as lastmodifiedby,
'DCS_' || COALESCE(country,'') || '_' || COALESCE(id,'') as id,
parentid,
codentifyid,
replacedby,
replaces,
devicestatus,
lastactivity,
lastdeviceupdate,

ROW_NUMBER() over (PARTITION by 
codentifyid,
replacedby,
replaces,
devicestatus,	
lastactivity order by lastdeviceupdate,time desc) rank
 from db_stg_current_record_dcs_bi.devices 
 where time > 
	     ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )
 
 ) where rank=1;