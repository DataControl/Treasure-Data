delete from db_stg_bi_technical.reference_data_mapping_delta_tmp where time >0;
insert into db_stg_bi_technical.reference_data_mapping_delta_tmp 
select src.source,
src.ref_data_country,
src.field_name,
src.legacy_code,
src.legacy_description,
src.target_code,
src.target_description from (select * from 
(

select source,ref_data_country,field_name,legacy_code,legacy_description,target_code,target_description ,
 ROW_NUMBER() over  (partition by COALESCE(source,'na'),COALESCE(ref_data_country,'na'),COALESCE(field_name,'na'),COALESCE(legacy_code,'na')  order by time desc) as rank 
from db_stg_technical.reference_data_mapping) where rank=1 )
src
left outer join 
 db_stg_bi_technical.reference_data_mapping tgt 
 on 	 COALESCE(src.source,'na') = COALESCE(tgt.source,'na') and
		 COALESCE(src.ref_data_country,'na') =COALESCE(tgt.ref_data_country,'na') and
		 COALESCE(src.field_name,'na') =COALESCE(tgt.field_name,'na') and
		 COALESCE(src.legacy_code,'na')=COALESCE(tgt.legacy_code,'na') and
		 COALESCE(src.legacy_description,'na')=COALESCE(tgt.legacy_description,'na') and
		 COALESCE(src.target_code,'na')=COALESCE(tgt.target_code,'na') and
		 COALESCE(src.target_description,'na') =COALESCE(tgt.target_description,'na')
		
	where tgt.source is null and tgt.ref_data_country is null and tgt.field_name is null
	
	
	union

select src.source,
src.ref_data_country,
src.field_name,
src.legacy_code,
src.legacy_description,
src.target_code,
src.target_description from (select * from 
(

select source,ref_data_country,field_name,legacy_code,legacy_description,target_code,target_description ,
 ROW_NUMBER() over  (partition by COALESCE(source,'na'),COALESCE(ref_data_country,'na'),COALESCE(field_name,'na'),COALESCE(legacy_code,'na')   order by time desc) as rank 
from db_stg_bi_technical.reference_data_mapping_tmp) where rank=1 )
src
left outer join 
 db_stg_bi_technical.reference_data_mapping tgt 
 on 	COALESCE(src.source,'na') = COALESCE(tgt.source,'na') and
		 COALESCE(src.ref_data_country,'na') =COALESCE(tgt.ref_data_country,'na') and
		 COALESCE(src.field_name,'na') =COALESCE(tgt.field_name,'na') and
		 COALESCE(src.legacy_code,'na')=COALESCE(tgt.legacy_code,'na') and
		 COALESCE(src.legacy_description,'na')=COALESCE(tgt.legacy_description,'na') and
		 COALESCE(src.target_code,'na')=COALESCE(tgt.target_code,'na') and
		 COALESCE(src.target_description,'na') =COALESCE(tgt.target_description,'na')
		
	where tgt.source is null and tgt.ref_data_country is null and tgt.field_name is null ;
	



delete  from  db_stg_bi_technical.reference_data_mapping 
where concat(source,'-',ref_data_country,'-',field_name,'-',legacy_code)
in 
(
select concat(source,'-',ref_data_country,'-',field_name,'-',legacy_code) as ref_pk
from db_stg_bi_technical.reference_data_mapping_delta_tmp   );

insert into db_stg_bi_technical.reference_data_mapping
select * from db_stg_bi_technical.reference_data_mapping_delta_tmp ;
