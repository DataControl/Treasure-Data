delete from db_l1_bi_organic.cases where createdby='dce2' and
 time > 
 ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_customer_care_dce2'
												   and entity_name= 'customer_care_dce2_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					);


insert into db_l1_bi_organic.cases
(
record_id,
CreatedDate		,
CreatedBy		,
LastModifiedDate		,
LastModifiedBy		,
case_identifier	,
identity_identifier	,
closing_date	,
case_channel	,
create_date	,
case_country	,
case_source	,
case_type	,
case_description	,
status 	,
subject_code	,
latest_update_date	,
escalation_flag	,
time_to_resolution	,
time_to_resolution_hr	,
closed_on_creation_flag	,
agent_id	,
resolution_code,
case_record_type	,
case_product_generation_description	,
subject_code_description	,
anonymized	,
anonymous_case_indicator	,
appointment_id	,
asset_id	,
brand_differentiator	,
brand_family	,
callback_time	,
case_handling_start_time	,
case_handling_time	,
consumable_complaint_reason	,
consumable_codentify	,
currency_isocode	,
device_codentify	,
escalation_date	,
incoming_system	,
interaction_id	,
isclosed	,
isclosed_on_create	,
isdeleted	,
isescalated	,
last_modified_by_id	,
order_id	,
origin	,
owner_id	,
pack_codentify	,
parent_id	,
product_description	,
product_family	,
product_line	,
reason	,
source_id	,
transaction_id
) 
	select-- rec_id.max_id + cast(row_number() over (order by b.time) as bigint) as 	record_Id,
	   100005 as record_Id,
		a.CreatedDate	,
		a.CreatedBy	,
		a.LastModifiedDate	,
		a.LastModifiedBy	,
		a.case_identifier	,
		a.identity_identifier	,
		a.closing_date	,
		a.case_channel	,
		a.create_date	,
		a.case_country	,
		a.case_source	,
		a.case_type	,
		a.case_description	,
		a.status 	,
		a.subject_code	,
		a.latest_update_date	,
		a.escalation_flag	,
		a.time_to_resolution	,
		a.time_to_resolution_hr	,
		a.closed_on_creation_flag	,
		a.agent_id	,
		a.resolution_code,	
		a.case_record_type	,
		a.case_product_generation_description	,
		a.subject_code_description	,
		a.anonymized	,
		a.anonymous_case_indicator	,
		a.appointment_id	,
		a.asset_id	,
		a.brand_differentiator	,
		a.brand_family	,
		a.callback_time	,
		a.case_handling_start_time	,
		a.case_handling_time	,
		a.consumable_complaint_reason	,
		a.consumable_codentify	,
		a.currency_isocode	,
		a.device_codentify	,
		a.escalation_date	,
		a.incoming_system	,
		a.interaction_id	,
		a.isclosed	,
		a.isclosed_on_create	,
		a.isdeleted	,
		a.isescalated	,
		a.last_modified_by_id	,
		a.order_id	,
		a.origin	,
		a.owner_id	,
		a.pack_codentify	,
		a.parent_id	,
		a.product_description	,
		a.product_family	,
		a.product_line	,
		a.reason	,
		a.source_id	,
		a.transaction_id
	  from db_stg_bi.cases_organic a
         left outer join 
    (     select 					   
			b.CreatedDate	,
			b.CreatedBy	,
			b.LastModifiedDate	,
			b.LastModifiedBy	,
			b.case_identifier	,
			b.identity_identifier	,
			b.closing_date	,
			b.case_channel	,
			b.create_date	,
			b.case_country	,
			b.case_source	,
			b.case_type	,
			b.case_description	,
			b.status 	,
			b.subject_code	,
			b.latest_update_date	,
			b.escalation_flag	,
			b.time_to_resolution	,
			b.time_to_resolution_hr	,
			b.closed_on_creation_flag	,
			b.agent_id	,
			b.resolution_code,	
			b.case_record_type	,
			b.case_product_generation_description	,
			b.subject_code_description	,
			b.anonymized	,
			b.anonymous_case_indicator	,
			b.appointment_id	,
			b.asset_id	,
			b.brand_differentiator	,
			b.brand_family	,
			b.callback_time	,
			b.case_handling_start_time	,
			b.case_handling_time	,
			b.consumable_complaint_reason	,
			b.consumable_codentify	,
			b.currency_isocode	,
			b.device_codentify	,
			b.escalation_date	,
			b.incoming_system	,
			b.interaction_id	,
			b.isclosed	,
			b.isclosed_on_create	,
			b.isdeleted	,
			b.isescalated	,
			b.last_modified_by_id	,
			b.order_id	,
			b.origin	,
			b.owner_id	,
			b.pack_codentify	,
			b.parent_id	,
			b.product_description	,
			b.product_family	,
			b.product_line	,
			b.reason	,
			b.source_id	,
			b.transaction_id	,
			b.time
			from  db_l1_bi_organic.cases a,
					db_stg_bi.cases_organic b ,
					(select ROW_NUMBER() over (PARTITION by case_identifier order by latest_update_date,time desc) rank,                                     case_identifier,time from db_l1_bi_organic.cases) r
			where										
	coalesce(a.case_identifier,'na')	=	coalesce(b.case_identifier,'na') and 
coalesce(a.identity_identifier,'na')	=	coalesce(b.identity_identifier,'na') and 
coalesce(a.closing_date,'na')	=	coalesce(b.closing_date,'na') and 
coalesce(a.case_channel,'na')	=	coalesce(b.case_channel,'na') and 
coalesce(a.create_date,'na')	=	coalesce(b.create_date,'na') and 
coalesce(a.case_country,'na')	=	coalesce(b.case_country,'na') and 
coalesce(a.case_source,'na')	=	coalesce(b.case_source,'na') and 
coalesce(a.case_type,'na')	=	coalesce(b.case_type,'na') and 
coalesce(a.case_description,'na')	=	coalesce(b.case_description,'na') and 
coalesce(a.status ,'na')	=	coalesce(b.status ,'na') and 
coalesce(a.subject_code,'na')	=	coalesce(b.subject_code,'na') and 
coalesce(a.escalation_flag,'na')	=	coalesce(b.escalation_flag,'na') and 
coalesce(a.time_to_resolution,0)	=	coalesce(b.time_to_resolution,0) and 
coalesce(a.time_to_resolution_hr,0)	=	coalesce(b.time_to_resolution_hr,0) and 
coalesce(a.closed_on_creation_flag,0)	=	coalesce(b.closed_on_creation_flag,0) and 
coalesce(a.agent_id,'na')	=	coalesce(b.agent_id,'na') and 
coalesce(a.resolution_code,'na')	=	coalesce(b.resolution_code,'na') and 
coalesce(a.case_record_type,'na')	=	coalesce(b.case_record_type,'na') and 
coalesce(a.case_product_generation_description,'na')	=	coalesce(b.case_product_generation_description,'na') and 
coalesce(a.subject_code_description,'na')	=	coalesce(b.subject_code_description,'na') and 
coalesce(a.anonymized,'na')	=	coalesce(b.anonymized,'na') and 
coalesce(a.anonymous_case_indicator,'na')	=	coalesce(b.anonymous_case_indicator,'na') and 
coalesce(a.appointment_id,'na')	=	coalesce(b.appointment_id,'na') and 
coalesce(a.asset_id,'na')	=	coalesce(b.asset_id,'na') and 
coalesce(a.brand_differentiator,'na')	=	coalesce(b.brand_differentiator,'na') and 
coalesce(a.brand_family,'na')	=	coalesce(b.brand_family,'na') and 
coalesce(a.callback_time,'na')	=	coalesce(b.callback_time,'na') and 
coalesce(a.case_handling_start_time,'na')	=	coalesce(b.case_handling_start_time,'na') and 
coalesce(a.case_handling_time,'na')	=	coalesce(b.case_handling_time,'na') and 
coalesce(a.consumable_complaint_reason,'na')	=	coalesce(b.consumable_complaint_reason,'na') and 
coalesce(a.consumable_codentify,'na')	=	coalesce(b.consumable_codentify,'na') and 
coalesce(a.currency_isocode,'na')	=	coalesce(b.currency_isocode,'na') and 
coalesce(a.device_codentify,'na')	=	coalesce(b.device_codentify,'na') and 
coalesce(a.escalation_date,'na')	=	coalesce(b.escalation_date,'na') and 
coalesce(a.incoming_system,'na')	=	coalesce(b.incoming_system,'na') and 
coalesce(a.interaction_id,'na')	=	coalesce(b.interaction_id,'na') and 
coalesce(a.isclosed,'na')	=	coalesce(b.isclosed,'na') and 
coalesce(a.isclosed_on_create,'na')	=	coalesce(b.isclosed_on_create,'na') and 
coalesce(a.isdeleted,'na')	=	coalesce(b.isdeleted,'na') and 
coalesce(a.isescalated,'na')	=	coalesce(b.isescalated,'na') and 
coalesce(a.last_modified_by_id,'na')	=	coalesce(b.last_modified_by_id,'na') and 
coalesce(a.order_id,'na')	=	coalesce(b.order_id,'na') and 
coalesce(a.origin,'na')	=	coalesce(b.origin,'na') and 
coalesce(a.owner_id,'na')	=	coalesce(b.owner_id,'na') and 
coalesce(a.pack_codentify,'na')	=	coalesce(b.pack_codentify,'na') and 
coalesce(a.parent_id,'na')	=	coalesce(b.parent_id,'na') and 
coalesce(a.product_description,'na')	=	coalesce(b.product_description,'na') and 
coalesce(a.product_family,'na')	=	coalesce(b.product_family,'na') and 
coalesce(a.product_line,'na')	=	coalesce(b.product_line,'na') and 
coalesce(a.reason,'na')	=	coalesce(b.reason,'na') and 
coalesce(a.source_id,'na')	=	coalesce(b.source_id,'na') and 
coalesce(a.transaction_id,'na')	=	coalesce(b.transaction_id,'na')
	and	a.case_identifier = r.case_identifier
	and a.time=r.time
	and r.rank=1 
	)b
	on 	coalesce(a.case_identifier,'na') = COALESCE(b.case_identifier,'na') /*,
	(select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_organic.cases) rec_id*/
    where b.case_identifier is null 
;