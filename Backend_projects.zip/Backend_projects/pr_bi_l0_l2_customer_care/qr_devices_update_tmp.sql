
delete from db_stg_current_record_dcs_bi.devices_update_tmp where time >0;
insert into db_stg_current_record_dcs_bi.devices_update_tmp
select
distinct
	src.id,
	src.codentifyid,
	src.ownerid,
	src.parentid,
	src.retailerid,
	src.callcenterid,
	src.registeredbusiness, --date
	src.purchasedbusiness, --date
	src.warrantyend, --date
	src.replacedby,
	src.replaces,
	src.devicetype,
	src.devicestatus,
	src.lastactivity,
	src.registeredsystem, --date
	src.lastdeviceupdate, --date
	src.componentid,
	src.componentcode,
	src.componentdescription,
	src.touchpointid,
	src.staffid,
	src.sessionid,
	src.purchasedatevalidation,
	src.itrackmetadataid,
	src.country,
	'dcs' as created_by,
	TD_TIME_PARSE(cast(CURRENT_TIMESTAMP as varchar), 'UTC') as created_date,
	'dcs' as last_modified_by,
	TD_TIME_PARSE(cast(CURRENT_TIMESTAMP as varchar), 'UTC') as last_modified_date,
	0 as deletion_flag,
	0 as incomplete_ts,
	0 as incomplete_flag,
	'${session_uuid}' as session_uuid,
	'${session_id}' as session_id,
	'0' as session_uuid_from,
	'0' as session_id_from
from
(
	select
		a.id,
		a.codentifyid,
		cast(a.ownerid as varchar) as ownerid,
		a.parentid,
		a.retailerid,
		cast(a.callcenterid as varchar) as callcenterid,
		TD_TIME_PARSE(cast(to_iso8601(parse_datetime(nullif(a.registeredbusiness,''), 'dd/MM/YYYY HH:mm:ss')) as varchar), 'UTC') as registeredbusiness, --date
		TD_TIME_PARSE(cast(to_iso8601(parse_datetime(nullif(a.purchasedbusiness,''), 'dd/MM/YYYY HH:mm:ss')) as varchar), 'UTC') as purchasedbusiness, --date
		TD_TIME_PARSE(cast(to_iso8601(parse_datetime(nullif(a.warrantyend,''), 'dd/MM/YYYY HH:mm:ss')) as varchar), 'UTC') as warrantyend, --date
		a.replacedby,
		a.replaces,
		a.devicetype,
		a.devicestatus,
		a.lastactivity,
		TD_TIME_PARSE(cast(to_iso8601(parse_datetime(nullif(a.registeredsystem,''), 'dd/MM/YYYY HH:mm:ss')) as varchar), 'UTC') as registeredsystem, --date
		TD_TIME_PARSE(cast(to_iso8601(parse_datetime(nullif(a.lastdeviceupdate,''), 'dd/MM/YYYY HH:mm:ss')) as varchar), 'UTC') as lastdeviceupdate, --date
		a.componentid,
		a.componentcode,
		a.componentdescription,
		a.touchpointid,
		a.staffid,
		a.sessionid,
		a.purchasedatevalidation,
		a.itrackmetadataid,
		a.country,
		a.time,
		rank () over (partition by a.id,
	a.codentifyid,
	a.ownerid,
	--a.parentid,
	a.retailerid,
	--a.callcenterid,
	a.registeredbusiness, 
	a.purchasedbusiness, 
	a.warrantyend, 
	a.replacedby,
	a.replaces,
	a.devicetype,
	a.devicestatus,
	a.lastactivity,
	--a.registeredsystem,  
	a.componentid,
	a.componentcode,
	a.componentdescription,
	--a.touchpointid,
	--a.staffid,
	--a.sessionid,
	a.purchasedatevalidation,
	--a.itrackmetadataid,
	a.country order by a.lastdeviceupdate ,a.time desc) rank_time
	from db_l0_odatadcs.devices a
	where
		time > 
		( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )
		  
) src

where 

	src.rank_time = 1