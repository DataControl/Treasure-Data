delete from  db_l1_bi_organic.cases where concat(case_identifier,'-',latest_update_date) in (
select concat(case_identifier,'-',latest_update_date) from db_stg_bi.cases_tmp_organic);