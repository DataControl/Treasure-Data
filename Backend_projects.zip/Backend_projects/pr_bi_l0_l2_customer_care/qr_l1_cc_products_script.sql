
delete from db_l1_bi_csc_legacy.products where createdby <> 'dce2' and
  time >
                ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 );

insert into db_l1_bi_csc_legacy.products
					(   record_id,
						createddate,
						createdby,
						lastmodifieddate,
						lastmodifiedby,	
						device_codetify ,
					    product_id ,
					    market ,
					    product_description ,
					    product_generation ,
					    product_family ,
					    system_last_updateded_date 
						
					) 
						select  --distinct rec_id.max_id + cast(row_number() over (order by b.time) as bigint) as 	record_Id,
						100003 as record_Id,
								a.createddate,
								a.createdby,
								a.lastmodifieddate,
								a.lastmodifiedby,
								a.device_codetify ,
								a.product_id ,
								a.market ,
								a.product_description ,
								a.product_generation ,
								a.product_family ,
								a.system_last_updateded_date 
						from db_stg_bi.products  a
                             left outer join 
                              (
                                           select 
												b.createddate,
												b.createdby,
												b.lastmodifieddate,
												b.lastmodifiedby,												
												b.device_codetify ,
												b.product_id ,
												b.market ,
												b.product_description ,
												b.product_generation ,
												b.product_family ,
												b.system_last_updateded_date ,
												b.time
											from  db_l1_bi_csc_legacy.products  a,
												  db_stg_bi.products  b ,
												 (select ROW_NUMBER() over (PARTITION by device_codetify order by time desc) rank,device_codetify,time from db_l1_bi_csc_legacy.products) r
											where
																						
												coalesce(a.device_codetify,'na') = coalesce( b.device_codetify,'na')  and
												coalesce(a.product_id,'na') = coalesce( b.product_id,'na')  and
											    coalesce(a.market,'na') = coalesce( b.market,'na')	and
												coalesce(a.product_description,'na') = coalesce( b.product_description,'na')  and
												coalesce(a.product_generation,'na') = coalesce( b.product_generation,'na')  and
											    coalesce(a.product_family,'na') = coalesce( b.product_family,'na')	and
												a.device_codetify = r.device_codetify
												and a.time=r.time
												and r.rank=1 )b
												on a.device_codetify = b.device_codetify /*,
												 (select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_csc_legacy.products) rec_id*/
												where b.device_codetify  is null /*and 
	 a.time >
                ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )*/
