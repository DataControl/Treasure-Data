delete from  db_stg_bi.devices where time > 0;
insert into db_stg_bi.devices

(
   createddate ,
   createdby ,
   lastmodifieddate ,
   lastmodifiedby ,
   id ,
   codentifyid ,
   ownerid ,
   retailerid ,
   registeredbusiness ,
   purchasedbusiness ,
   warrantyend ,
   devicetype ,
   devicestatus ,
   lastactivity ,
   lastdeviceupdate ,
   componentid ,
   purchasedatevalidation ,
   country ,
   product_id,
   return_status ,
   product_variant,
   productdescription,
	 productcode ,
   productfamily ,
  serialnumber ,
  materialdescription ,
  originadesignmarket ,
  originalbox ,
  version ,
  factorycode 
  

)


select 
    distinct 
    src.created_date createddate,
	src.created_by  as created_by,
	src.last_modified_date lastmodifieddate,
    src.last_modified_by as lastmodifiedby,  
   'DCE_' || COALESCE(country_mapping.legacy_code,src.country,'') || '_' || COALESCE(src.id,'') as id,	
    src.codentifyid ,
   src.ownerid ,
   src.retailerid ,
   src.registeredbusiness ,
   src.purchasedbusiness ,
   src.warrantyend ,
   COALESCE(device_type_mapping.legacy_code,src.devicetype ) as devicetype,
   COALESCE(status_mapping.legacy_code, src.devicestatus) as devicestatus,
   src.lastactivity ,
   src.lastdeviceupdate ,
   src.componentid ,
   src.purchasedatevalidation ,
   COALESCE(country_mapping.legacy_code,src.country ) as country, 
   src.product_id  ,
    -1 as return_status,
	src.product_variant,
	src.productdescription,
	 src.productcode ,
   src.productfamily ,
  src.serialnumber ,
  src.materialdescription ,
  src.originadesignmarket ,
  src.originalbox ,
  src.version ,
  src.factorycode 
   
    
    from 
   (select
  created_by,
    created_date,
    last_modified_by,
    last_modified_date,
	id ,
   codentifyid,
   ownerid ,
    retailerid ,
  registeredbusiness ,
     purchasedbusiness ,
    warrantyend ,
   devicetype ,
    devicestatus  ,
    lastactivity ,
   lastdeviceupdate ,
   componentid ,
    purchasedatevalidation ,
   country,
    data_ref_country_tmp,
    product_id,
   product_variant,
   productdescription,
   productcode ,
  productfamily ,
  serialnumber ,
 materialdescription ,
   originadesignmarket ,
  originalbox ,
   version ,
   factorycode 
  


from

  (
select 
   created_by,
    created_date,
    last_modified_by,
    last_modified_date,
	id ,
   ccr_codentifyid__c  as codentifyid,
   ownerid ,
   null as retailerid ,
  TD_TIME_PARSE(createddate,'UTC') as registeredbusiness ,
    TD_TIME_PARSE( purchasedate,'UTC')  as purchasedbusiness ,
   TD_TIME_PARSE( ccr_warrantyduedate__c,'UTC') as warrantyend ,
   ccr_materialgroupdescription__c as devicetype ,
   status  as devicestatus  ,
   null as lastactivity ,
   TD_TIME_PARSE(lastmodifieddate,'UTC') as lastdeviceupdate ,
   ccr_deviceproductcode__c as componentid ,
   null as purchasedatevalidation ,
   ccr_purchasecountry__c as country,
   ccr_purchasecountry__c  as data_ref_country_tmp,
   product2id as product_id,
   'N/A' as product_variant,
   productdescription,
   productcode ,
  productfamily ,
  serialnumber ,
 ccr_materialdescription__c as materialdescription ,
  ccr_originadesignmarket__c as originadesignmarket ,
  ccr_originalbox__c as originalbox ,
  ccr_version__c as version ,
  ccr_factorycode__c as factorycode ,
   row_number() over (partition by
   ccr_codentifyid__c,
   ownerid ,   
  createddate,
     purchasedate ,
   ccr_warrantyduedate__c ,
   ccr_materialgroupdescription__c  ,
   status    ,   
lastmodifieddate,
   ccr_deviceproductcode__c  ,  
   ccr_purchasecountry__c ,
   ccr_purchasecountry__c ,
   product2id ,   
   productdescription,
   productcode ,
  productfamily ,
  serialnumber ,
 ccr_materialdescription__c ,
  ccr_originadesignmarket__c ,
  ccr_originalbox__c  ,
  ccr_version__c  ,
  ccr_factorycode__c order by lastmodifieddate ) as rank,
   time
        from db_stg_current_record_dce_bi.device_sfdc 
		
        where time > 
		( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )) where rank=1) src
					
			
					
					left outer join db_stg_bi_technical.reference_data_mapping device_type_mapping
	on device_type_mapping.field_name = 'device_type' and trim(upper(src.devicetype)) = trim(upper(device_type_mapping.legacy_code)) and (src.created_by in ('sfdc','dce') and device_type_mapping.source = 'dce') and src.data_ref_country_tmp = device_type_mapping.ref_data_country  

	left outer join db_stg_bi_technical.reference_data_mapping status_mapping
	on status_mapping.field_name = 'status' and trim(upper(src.devicestatus)) = trim(upper(status_mapping.legacy_code)) and (src.created_by in ('sfdc','dce') and status_mapping.source = 'dce') and src.data_ref_country_tmp = status_mapping.ref_data_country  

	left outer join db_stg_bi_technical.reference_data_mapping country_mapping
	on country_mapping.field_name = 'country_2l' and trim(upper(src.country)) = trim(upper(country_mapping.legacy_code)) and ( src.created_by in ('sfdc','dce') and country_mapping.source = 'dce') 

UNION 

select 
  distinct
  src.created_date,
  src.created_by,
  src.last_modified_date,
    src.last_modified_by,
  'DCS_' || COALESCE(country_mapping.legacy_code,src.country,'') || '_' || COALESCE(src.id,'') as id,
      
   src.codentifyid ,
   src.ownerid ,
   src.retailerid ,
   src.registeredbusiness ,
   src.purchasedbusiness ,
   src.warrantyend ,
   COALESCE(device_type_mapping.legacy_code,src.devicetype ) as devicetype,
   COALESCE(status_mapping.legacy_code, src.devicestatus) as devicestatus,
   src.lastactivity ,
   src.lastdeviceupdate ,
   src.componentid ,
   src.purchasedatevalidation ,
   COALESCE(country_mapping.legacy_code,src.country ) as country,
   'N/A' as product_id,
    case when r.returnedcodentifyid is not null then 1 else 0 end  as return_status,
	src.componentcode as product_variant,
	 src.componentdescription as productdescription,
	'N/A'  productcode ,
  'N/A' as productfamily ,
  'N/A' as serialnumber ,
  'N/A' as materialdescription ,
  'N/A' as originadesignmarket ,
  'N/A' as originalbox ,
  'N/A' as version ,
  'N/A' as  factorycode 
    
    from 
    (
select 
        
    delta_dcs.created_by,
    delta_dcs.created_date,
    delta_dcs.last_modified_by,
    delta_dcs.last_modified_date,
      delta_dcs.id ,
   delta_dcs.codentifyid ,
   delta_dcs.ownerid ,
   delta_dcs.retailerid ,
   delta_dcs.registeredbusiness ,
   delta_dcs.purchasedbusiness ,
   delta_dcs.warrantyend ,
   delta_dcs.devicetype ,
   delta_dcs.devicestatus  ,
   delta_dcs.lastactivity ,
   delta_dcs.lastdeviceupdate ,
   delta_dcs.componentid ,
   delta_dcs.purchasedatevalidation ,
   delta_dcs.country ,
   delta_dcs.country  as data_ref_country_tmp,
   delta_dcs.componentcode,
   delta_dcs.componentdescription
  
        from db_stg_current_record_dcs_bi.devices delta_dcs
        where delta_dcs.time > 
		( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )) src
					
					left outer join (select distinct returnedcodentifyid from db_l0_odatadcs.devicereturns) r
			 on src.codentifyid=r.returnedcodentifyid
					
						left outer join db_stg_bi_technical.reference_data_mapping device_type_mapping
	on device_type_mapping.field_name = 'device_type' and trim(upper(src.devicetype)) = trim(upper(device_type_mapping.legacy_code)) and (src.created_by = 'dcs' and device_type_mapping.source = 'dcs') and src.data_ref_country_tmp = device_type_mapping.ref_data_country  

	left outer join db_stg_bi_technical.reference_data_mapping status_mapping
	on status_mapping.field_name = 'status' and trim(upper(src.devicestatus)) = trim(upper(status_mapping.legacy_code)) and (src.created_by = 'dcs' and status_mapping.source = 'dcs')  and src.data_ref_country_tmp = status_mapping.ref_data_country  

left outer join db_stg_bi_technical.reference_data_mapping country_mapping
	on country_mapping.field_name = 'country_2l' and trim(upper(src.country)) = trim(upper(country_mapping.legacy_code)) and (src.created_by = 'dcs' and country_mapping.source = 'dcs') 
