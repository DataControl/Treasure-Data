
delete from db_l1_bi_csc_legacy.devices_lifecycle where createdby <> 'dce2' and
  time >
                ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 );

insert into db_l1_bi_csc_legacy.devices_lifecycle
 (  record_id,
	createddate,
	createdby,
	lastmodifieddate,
	lastmodifiedby,	
	id,
	parentid,
	codentifyid,
	replacedby,
	replaces,
	devicestatus,
	lastactivity,
	lastdeviceupdate,
	isfortrial 	,
	lender	 ,
	replacementchannel	,
	replacementdate 	,
	replacementexternalreference	 ,
	replacementreason	,
	spiceid	 ,
	trialexternalreference	,
	numberofconsumers 	,
	replacementsystemdate	 ,
	exportidautonumber	,
	replacementdoneby	,
	eligigibilityduedate	,
	eligibleforreplacement	,
	subscriptionid	,
	replacementchannelnew	,
	replacementcountry	,
	purchasechannel	,
	careplusdisenrolled	,
	careplusduedate	,
	careplusrequested	,
	careplusstatus	
						
  ) 
  select  --distinct rec_id.max_id + cast(row_number() over (order by b.time) as bigint) as record_Id,
		100002 as record_id,
		a.createddate,
		a.createdby,
		a.lastmodifieddate,
		a.lastmodifiedby,
		a.id,
		a.parentid,
		a.codentifyid,
		a.replacedby,
		a.replaces,
		a.devicestatus,
		a.lastactivity,
		a.lastdeviceupdate,
		 a.isfortrial,
		a.lender ,
		a.replacementchannel,
		a.replacementdate ,
		a.replacementexternalreference ,
		a.replacementreason,
		a.spiceid ,
		a.trialexternalreference,
		a.numberofconsumers ,
		a.replacementsystemdate ,
		a.exportidautonumber,
		a.replacementdoneby,
		a.eligigibilityduedate,
		a.eligibleforreplacement,
		a.subscriptionid,
		a.replacementchannelnew,
		a.replacementcountry,
		a.purchasechannel,
		a.careplusdisenrolled,
		a.careplusduedate,
		a.careplusrequested,
		a.careplusstatus
	from db_stg_bi.devices_lifecycle  a
         left outer join 
           (
        select 
			b.createddate,
			b.createdby,
			b.lastmodifieddate,
			b.lastmodifiedby,												
			b.id,
			b.parentid,
			b.codentifyid,
			b.replacedby,
			b.replaces,
			b.devicestatus,
			b.lastactivity,
			b.lastdeviceupdate,
			b.isfortrial ,
			b.lender ,
			b.replacementchannel,
			b.replacementdate ,
			b.replacementexternalreference ,
			b.replacementreason,
			b.spiceid ,
			b.trialexternalreference,
			b.numberofconsumers,
			b.replacementsystemdate ,
			b.exportidautonumber,
			b.replacementdoneby,
			b.eligigibilityduedate,
			b.eligibleforreplacement,
			b.subscriptionid,
			b.replacementchannelnew,
			b.replacementcountry,
			b.purchasechannel,
			b.careplusdisenrolled,
			b.careplusduedate,
			b.careplusrequested,
			b.careplusstatus,
			b.time
	from  db_l1_bi_csc_legacy.devices_lifecycle  a,
		 db_stg_bi.devices_lifecycle  b ,
       (select ROW_NUMBER() over (PARTITION by 	id,
														
								codentifyid,
								replacedby,
								replaces,
								devicestatus,
								lastactivity
								order by lastdeviceupdate desc) rank,
								id,
								codentifyid,
								lastdeviceupdate ,
								time 
       from db_l1_bi_csc_legacy.devices_lifecycle) r
	  where																						
		coalesce(a.id,'na') = coalesce( b.id,'na')  and
		coalesce(a.parentid,'na') = coalesce( b.parentid,'na')  and
		coalesce(a.codentifyid,'na') = coalesce( b.codentifyid,'na')  and
		coalesce(a.replacedby,'na') = coalesce( b.replacedby,'na')	and
		coalesce(a.devicestatus,'na') = coalesce( b.devicestatus,'na')	and
		coalesce(a.lastactivity,'na') = coalesce( b.lastactivity,'na')	and
		coalesce(a.replacedby,'na') = coalesce( b.replacedby,'na')	and
		coalesce(a.isfortrial ,0)	=	coalesce(b.isfortrial ,	0) and 
		coalesce(a.lender ,'na')	=	coalesce(b.lender ,'na') and 
		coalesce(a.replacementchannel,'na')	=	coalesce(b.replacementchannel,'na') and 
		coalesce(a.replacementdate ,'na')	=	coalesce(b.replacementdate ,'na') and 
		coalesce(a.replacementexternalreference ,'na')	=	coalesce(b.replacementexternalreference ,'na') and 
		coalesce(a.replacementreason,'na')	=	coalesce(b.replacementreason,'na') and 
		coalesce(a.spiceid ,'na')	=	coalesce(b.spiceid ,'na') and 
		coalesce(a.trialexternalreference,'na')	=	coalesce(b.trialexternalreference,'na') and 
		coalesce(a.numberofconsumers ,0)	=	coalesce(b.numberofconsumers ,	0) and 
		coalesce(a.replacementsystemdate ,'na')	=	coalesce(b.replacementsystemdate ,'na') and 
		coalesce(a.exportidautonumber,'na')	=	coalesce(b.exportidautonumber,'na') and 
		coalesce(a.replacementdoneby,'na')	=	coalesce(b.replacementdoneby,'na') and 
		coalesce(a.eligigibilityduedate,'na')	=	coalesce(b.eligigibilityduedate,'na') and 
		coalesce(a.eligibleforreplacement,0)	=	coalesce(b.eligibleforreplacement,	0) and 
		coalesce(a.subscriptionid,'na')	=	coalesce(b.subscriptionid,'na') and 
		coalesce(a.replacementchannelnew,'na')	=	coalesce(b.replacementchannelnew,'na') and 
		coalesce(a.replacementcountry,'na')	=	coalesce(b.replacementcountry,'na') and 
		coalesce(a.purchasechannel,'na')	=	coalesce(b.purchasechannel,'na') and 
		coalesce(a.careplusdisenrolled,0)	=	coalesce(b.careplusdisenrolled,	0) and 
		coalesce(a.careplusduedate,'na')	=	coalesce(b.careplusduedate,'na') and 
		coalesce(a.careplusrequested,0)	=	coalesce(b.careplusrequested,	0) and 
		coalesce(a.careplusstatus,'na')	=	coalesce(b.careplusstatus,	'na') and 
		a.id=r.id and
		a.codentifyid=r.codentifyid 								
		and a.time=r.time
        and a.lastdeviceupdate =r.lastdeviceupdate 
		and r.rank=1 )b
			on a.id=b.id and a.codentifyid=b.codentifyid /* ,
	 (select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_csc_legacy.devices_lifecycle) rec_id*/ where b.id  is null 