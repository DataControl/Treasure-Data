delete from db_stg_bi.components  where time >0;
insert into db_stg_bi.components 
(
					 createddate,
						createdby,
						lastmodifieddate,
						lastmodifiedby,	
						componentid,
						componentcode,
						componentdescription
	)

select distinct 
            createddate,
			createdby,
			lastmodifieddate,
			lastmodifiedby,	
			componentid,
			componentcode,
			componentdescription
			from
(
select 
distinct
delta_dce.created_date as createddate,
delta_dce.created_by as createdby,
delta_dce.last_modified_date  as lastmodifieddate,
delta_dce.last_modified_by as  lastmodifiedby,	
delta_dce.ccr_deviceproductcode__c as componentid,
null as componentcode,
delta_dce.ccr_materialdescription__c as componentdescription,
row_number() over (partition by delta_dce.ccr_deviceproductcode__c ,
delta_dce.ccr_materialdescription__c order by delta_dce.time) as rank
   from db_stg_current_record_dce_bi.device_sfdc delta_dce
    where delta_dce.time > 
	     ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )
					) where rank=1
		

union

select distinct 
            createddate,
						createdby,
						lastmodifieddate,
						lastmodifiedby,	
						componentid,
						componentcode,
						componentdescription
						
						from 
(
select 
delta_dcs.created_date as createddate,
delta_dcs.created_by as createdby,
delta_dcs.last_modified_date as lastmodifieddate,
delta_dcs.last_modified_by as lastmodifiedby,
delta_dcs.componentid as componentid,
delta_dcs.componentcode as componentcode,
delta_dcs.componentdescription as componentdescription,
row_number() over (partition by delta_dcs.componentid,
delta_dcs.componentcode,
delta_dcs.componentdescription order by delta_dcs.time) as rank

 from db_stg_current_record_dcs_bi.devices delta_dcs
        where delta_dcs.time > 
	     ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 ) 
)where rank=1
