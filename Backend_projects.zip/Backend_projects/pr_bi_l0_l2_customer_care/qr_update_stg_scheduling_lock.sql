delete from db_stg_bi_technical.stg_scheduling where dependencies = 'wf_l0_l1_bi_customer_care';
insert into db_stg_bi_technical.stg_scheduling select 'wf_db_l3_bi_data_marts_csc' as object, 'wf_l0_l1_bi_customer_care' as dependencies, 1 as load_flag;
