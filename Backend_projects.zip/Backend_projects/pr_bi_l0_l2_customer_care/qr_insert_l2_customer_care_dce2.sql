delete from db_l2_bi.cases_attributes where createdby='dce2' and
 time > 
 ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_customer_care_dce2'
												   and entity_name= 'customer_care_dce2_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					);


insert into db_l2_bi.cases_attributes
(record_id,
CreatedDate	,
CreatedBy	,
LastModifiedDate	,
LastModifiedBy	,
case_identifier	,
persona_identifier 	,
identity_identifier	,
closing_date	,
case_channel	,
create_date	,
case_source	,
case_type	,
case_record_type	,
status	,
subject_code	,
subject_description	,
latest_update_date	,
home_country	,
escalation_flag	,
time_to_resolution	,
first_response_time	,
agent_id	,
device_issue_flag	,
resolution_code	,
device_codetify	,
device_product_generation	,
device_product_description	,
device_warranty_due_date_eligibility	,
return_status	,
delivery_date	,
l1_result	,
l1_subject_description	,
closed_on_creation 	,
time_to_resolution_hours 	,
case_country 	,
case_description	,
anonymized	,
anonymous_case_indicator	,
appointment_id	,
asset_id	,
brand_differentiator	,
brand_family	,
callback_time	,
case_handling_start_time	,
case_handling_time	,
consumable_complaint_reason	,
consumable_codentify	,
currency_isocode	,
escalation_date	,
incoming_system	,
interaction_id	,
isclosed	,
isclosed_on_create	,
isdeleted	,
isescalated	,
last_modified_by_id	,
order_id	,
origin	,
owner_id	,
pack_codentify	,
parent_id	,
product_family	,
product_line	,
reason	,
source_id	,
transaction_id	
)

select 
record_id as record_id,
CreatedDate	as	CreatedDate	,
CreatedBy	as	CreatedBy	,
LastModifiedDate	as	LastModifiedDate	,
LastModifiedBy	as	LastModifiedBy	,
case_identifier	as	case_identifier	,
'N/A' as		persona_identifier 	,
identity_identifier	as	identity_identifier	,
closing_date	as	closing_date	,
case_channel	as	case_channel	,
create_date	as	create_date	,
case_source	as	case_source	,
case_type	as	case_type	,
case_record_type	as	case_record_type	,
status 	as	status	,
subject_code	as	subject_code	,
subject_code_description	as	subject_description	,
latest_update_date	as	latest_update_date	,
case_country	as	home_country	,
escalation_flag	as	escalation_flag	,
time_to_resolution	as	time_to_resolution	,
'N/A'	as	first_response_time	,
agent_id	as	agent_id	,
null	as	device_issue_flag	,
resolution_code	as	resolution_code	,
device_codentify	as	device_codetify	,
case_product_generation_description	as	device_product_generation	,
product_description	as	device_product_description	,
'N/A'	as	device_warranty_due_date_eligibility	,
'N/A'	as	return_status	,
'N/A'	as	delivery_date	,
'N/A'	as	l1_result	,
'N/A'	as	l1_subject_description	,
closed_on_creation_flag	as	closed_on_creation 	,
time_to_resolution_hr	as	time_to_resolution_hours 	,
case_country as		case_country 	,
case_description	as	case_description	,
anonymized	as	anonymized	,
anonymous_case_indicator	as	anonymous_case_indicator	,
appointment_id	as	appointment_id	,
asset_id	as	asset_id	,
brand_differentiator	as	brand_differentiator	,
brand_family	as	brand_family	,
callback_time	as	callback_time	,
case_handling_start_time	as	case_handling_start_time	,
case_handling_time	as	case_handling_time	,
consumable_complaint_reason	as	consumable_complaint_reason	,
consumable_codentify	as	consumable_codentify	,
currency_isocode	as	currency_isocode	,
escalation_date	as	escalation_date	,
incoming_system	as	incoming_system	,
interaction_id	as	interaction_id	,
isclosed	as	isclosed	,
isclosed_on_create	as	isclosed_on_create	,
isdeleted	as	isdeleted	,
isescalated	as	isescalated	,
last_modified_by_id	as	last_modified_by_id	,
order_id	as	order_id	,
origin	as	origin	,
owner_id	as	owner_id	,
pack_codentify	as	pack_codentify	,
parent_id	as	parent_id	,
product_family	as	product_family	,
product_line	as	product_line	,
reason	as	reason	,
source_id	as	source_id	,
transaction_id	as	transaction_id	
from db_l1_bi_organic.cases
where time > 
 ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_customer_care_dce2'
												   and entity_name= 'customer_care_dce2_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					);

