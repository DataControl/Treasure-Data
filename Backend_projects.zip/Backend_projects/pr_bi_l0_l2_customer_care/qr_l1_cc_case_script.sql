insert into db_l1_bi_csc_legacy.cases
					(   record_id,
						createddate,
						createdby,
						lastmodifieddate,
						lastmodifiedby,
						case_identifier,
						persona_identifier,
						identity_identifier,
						closing_date,
						case_channel,
						create_date,
						case_source,
						case_type,
						case_subtype,
						status,
						subject_code,
						--subject_description,
						latest_update_date,
						home_country,
						escalation_flag ,
						time_to_resolution ,
						first_response_time,
						agent_id ,
						device_issue_flag,
						resolution_code,
						--device_codetify,
						--device_product_generation,
						--device_product_description,
						device_warranty_due_date_eligibility,
						return_status,
						delivery_date,
						l1_result,
						l1_subject_description	,
						closed_on_creation,
						time_to_resolution_hours,
						case_country,
						l1_result_description,
						--replacedby,
						case_channel_harmonization_flag ,
						case_source_harmonization_flag ,
						case_type_harmonization_flag ,
						case_subtype_harmonization_flag ,
						status_harmonization_flag ,
						subject_code_harmonization_flag ,
						subject_description_harmonization_flag ,
						home_country_harmonization_flag  ,  
						time
					) 
						select  --distinct rec_id.max_id + cast(row_number() over (order by b.time) as bigint) as 	record_Id,
						100000 as record_Id,
								a.created_date,
								a.created_by,
								a.last_modified_date,
								a.last_modified_by,
								a.case_identifier,
								a.persona_identifier,
								a.identity_identifier,
								a.closing_date,
								a.case_channel,
								a.create_date,
								a.case_source,
								a.case_type,
								a.case_subtype,
								a.status,
								a.subject_code,
								--a.subject_description,
								a.latest_update_date,
								a.home_country,
								a.escalation_flag ,
						        a.time_to_resolution ,
								a.first_response_time,
								a.agent_id ,
								a.device_issue_flag,
								a.resolution_code,
								--a.device_codetify,
								--a.device_product_generation,
								--a.device_product_description,
								a.device_warranty_due_date_eligibilit,
								a.return_status,
								a.delivery_date,
								a.l1_result,
								a.l1_subject_description	,
								a.closed_on_creation,
								a.time_to_resolution_hours,
								a.case_country,
								a.l1_result_description,
								--a.replacedby,
								a.case_channel_harmonization_flag ,
								a.case_source_harmonization_flag ,
								a.case_type_harmonization_flag ,
								a.case_subtype_harmonization_flag ,
								a.status_harmonization_flag ,
								a.subject_code_harmonization_flag ,
								a.subject_description_harmonization_flag ,
								a.home_country_harmonization_flag  ,  
								a.time
						  from db_stg_bi.cases  a
                             left outer join 
                              (
                                           select 
												b.created_date,
												b.created_by,
												b.last_modified_date,
												b.last_modified_by,
												b.case_identifier,
												b.persona_identifier,
												b.identity_identifier,
												b.closing_date,
												b.case_channel,
												b.create_date,
												b.case_source,
												b.case_type,
												b.case_subtype,
												b.status,
												b.subject_code,
												--b.subject_description,
												b.latest_update_date,
												b.home_country,
												b.escalation_flag ,
												b.time_to_resolution ,
												b.first_response_time,
												b.agent_id ,
												b.device_issue_flag,
												b.resolution_code,
												--b.device_codetify,
												--b.device_product_generation,
												--b.device_product_description,
												b.device_warranty_due_date_eligibilit,
												b.return_status,
												b.delivery_date,
												b.l1_result,
												b.l1_subject_description,
												b.closed_on_creation,
												b.time_to_resolution_hours,
												b.case_country,
												b.l1_result_description,
												--b.replacedby,
												b.case_channel_harmonization_flag ,
												b.case_source_harmonization_flag ,
												b.case_type_harmonization_flag ,
												b.case_subtype_harmonization_flag ,
												b.status_harmonization_flag ,
												b.subject_code_harmonization_flag ,
												b.subject_description_harmonization_flag ,
												b.home_country_harmonization_flag  ,  
												b.time
											from  db_l1_bi_csc_legacy.cases  a,
											db_stg_bi.cases  b ,
											(select ROW_NUMBER() over (PARTITION by case_identifier order by time desc) rank,case_identifier,time from db_l1_bi_csc_legacy.cases) r
											where
																						
												coalesce(a.case_identifier,'na') = coalesce( b.case_identifier,'na')  and 
												coalesce(a.persona_identifier,'na') = coalesce(b.persona_identifier,'na')  and
												coalesce(a.identity_identifier,'na') = coalesce( b.identity_identifier,'na')  and
												coalesce(a.closing_date,0) = coalesce( b.closing_date,0)  and
												coalesce(a.case_channel,'na') = coalesce( b.case_channel,'na')  and
												coalesce(a.create_date,0) = coalesce( b.create_date,0)  and
												coalesce(a.case_source,'na') = coalesce( b.case_source,'na')  and
												coalesce(a.case_type,'na') = coalesce( b.case_type,'na')  and
												coalesce(a.case_subtype,'na') = coalesce( b.case_subtype,'na')  and
												coalesce(a.status,'na') = coalesce( b.status,'na')  and
												coalesce(a.subject_code,'na') = coalesce( b.subject_code,'na')  and
												--coalesce(a.subject_description,'na') = coalesce( b.subject_description,'na')  and
											    coalesce(a.home_country,'na') = coalesce( b.home_country,'na')	and
												coalesce(a.escalation_flag ,0) =coalesce(b.escalation_flag ,0)   and
												coalesce(a.time_to_resolution ,0)= coalesce(a.time_to_resolution ,0) and
												coalesce(a.first_response_time,'na')=coalesce(b.first_response_time,'na') and
												coalesce(a.agent_id ,'na')= coalesce(b.agent_id ,'na') and
												coalesce(a.device_issue_flag,0)	=	coalesce(b.device_issue_flag,0)	and
												coalesce(a.resolution_code,'na')	=	coalesce(b.resolution_code,'na')	and
												--coalesce(a.device_codetify,'na')	=	coalesce(b.device_codetify,'na')	and
												--coalesce(a.device_product_generation,'na')	=	coalesce(b.device_product_generation,'na')	and
												--coalesce(a.device_product_description,'na')	=	coalesce(b.device_product_description,'na')	and
												coalesce(a.device_warranty_due_date_eligibility,'na')	=	coalesce(b.device_warranty_due_date_eligibilit,'na')	and
												coalesce(a.return_status,'na')	=	coalesce(b.return_status,'na')	and
												coalesce(a.delivery_date,0)	=	coalesce(b.delivery_date,0)	and
												coalesce(a.l1_result,'na')	=	coalesce(b.l1_result,'na')	and
												coalesce(a.l1_subject_description,'na')	=	coalesce(b.l1_subject_description,'na')	and
												coalesce(a.closed_on_creation,0)	=	coalesce(b.closed_on_creation,0)	and
												coalesce(a.time_to_resolution_hours,0)	=	coalesce(b.time_to_resolution_hours,0)	and
												coalesce(a.case_country,'na')	=	coalesce(b.case_country,'na')	and
												coalesce(a.l1_result_description,'na')	=	coalesce(b.l1_result_description,'na')	and
												--coalesce(a.replacedby,'na')	=	coalesce(b.replacedby,'na')	and
													a.case_identifier = r.case_identifier
												and a.time=r.time
												and r.rank=1 )b
												on a.case_identifier = b.case_identifier 
												
												where b.case_identifier  is null
	 