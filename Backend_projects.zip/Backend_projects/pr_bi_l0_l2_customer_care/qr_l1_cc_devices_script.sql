insert into db_l1_bi_csc_legacy.devices
					(   
						   record_id ,
						   createddate ,
						   createdby ,
						   lastmodifieddate ,
						   lastmodifiedby ,
						   id ,
						   codentifyid ,
						   ownerid ,
						   retailerid ,
						   registeredbusiness ,
						   purchasedbusiness ,
						   warrantyend ,
						   devicetype ,
						   devicestatus ,
						   lastactivity ,
						   lastdeviceupdate ,
						   componentid ,
						   purchasedatevalidation ,
						   country ,
						   product_id,
						   return_status , 
               product_variant ,
			   productdescription,
               productcode ,
               productfamily ,
               serialnumber ,
               materialdescription ,
               originadesignmarket ,
               originalbox ,
               version ,
               factorycode 
						
					) 
select  distinct 
		--rec_id.max_id + cast(row_number() over (order by b.time) as bigint) as record_Id,
		 100001 as record_Id,
	    a.createddate ,
	   a.createdby ,
	   a.lastmodifieddate ,
	   a.lastmodifiedby ,
	   a.id ,
	   a.codentifyid ,
	   a.ownerid ,
	   a.retailerid ,
	   a.registeredbusiness ,
	   a.purchasedbusiness ,
	   a.warrantyend ,
	   a.devicetype ,
	   a.devicestatus ,
	   a.lastactivity ,
	   a.lastdeviceupdate ,
	   a.componentid ,
	   a.purchasedatevalidation ,
	   a.country ,
	   a.product_id,
	   a.return_status ,
	   a.product_variant,
	   a.productdescription,
	   a.productcode,
	   a.productfamily ,
     a.serialnumber ,
     a.materialdescription ,
     a.originadesignmarket ,
     a.originalbox ,
     a.version ,
     a.factorycode 
from db_stg_bi.devices  a
         left outer join 
      (
   select 
	    b.createddate ,
	   b.createdby ,
	   b.lastmodifieddate ,
	   b.lastmodifiedby ,
	   b.id ,
	   b.codentifyid ,
	   b.ownerid ,
	   b.retailerid ,
	   b.registeredbusiness ,
	   b.purchasedbusiness ,
	   b.warrantyend ,
	   b.devicetype ,
	   b.devicestatus ,
	   b.lastactivity ,
	   b.lastdeviceupdate ,
	   b.componentid ,
	   b.purchasedatevalidation ,
	   b.country ,
	   b.product_id,
	   b.return_status ,
	   b.product_variant,
	   b.productdescription,
	   b.productcode,
	   b.productfamily ,
     b.serialnumber ,
     b.materialdescription ,
     b.originadesignmarket ,
     b.originalbox ,
     b.version ,
     b.factorycode ,
	   b.time
	from    db_l1_bi_csc_legacy.devices  a,
		    db_stg_bi.devices  b ,
				(select ROW_NUMBER() over (PARTITION by 														codentifyid																			order by lastdeviceupdate,time desc) rank,
				codentifyid,
				id,
				time 
				from db_l1_bi_csc_legacy.devices) r
				where
				
					coalesce(a.id,'na') = coalesce( b.id,'na')  and
					coalesce(a.createdby ,'na') = coalesce( b.createdby ,'na')  and
					coalesce(a.lastmodifiedby ,'na') = coalesce( b.lastmodifiedby ,'na')	and
					coalesce(a.codentifyid ,'na') = coalesce( b.codentifyid ,'na')	and
					coalesce(a.ownerid ,'na') = coalesce( b.ownerid ,'na')	and
					coalesce(a.retailerid ,'na') = coalesce( b.retailerid ,'na')	and
					coalesce(a.registeredbusiness ,0) = coalesce( b.registeredbusiness ,0)  and
					coalesce(a.purchasedbusiness ,0) = coalesce( b.purchasedbusiness ,0)  and
					coalesce(a.warrantyend ,0) = coalesce( b.warrantyend ,0)	and
					coalesce(a.devicetype ,'na') = coalesce( b.devicetype ,'na')	and
					coalesce(a.devicestatus ,'na') = coalesce( b.devicestatus ,'na')	and
					coalesce(a.lastactivity ,'na') = coalesce( b.lastactivity ,'na')	and
					coalesce(a.componentid ,'na') = coalesce( b.componentid ,'na')  and
					coalesce(a.purchasedatevalidation ,'na') = coalesce( b.purchasedatevalidation ,'na')  and
					coalesce(a.country ,'na') = coalesce( b.country ,'na')	and
					coalesce(a.product_id ,'na') = coalesce( b.product_id ,'na')	and
					coalesce(a.return_status ,0) = coalesce( b.return_status ,0)	and
					coalesce(a.product_variant,'na')=coalesce(b.product_variant,'na') and
					coalesce(a.productdescription,'na')=coalesce(b.productdescription,'na') and
					coalesce(a.productcode,'na')=coalesce(b.productcode,'na') and
					coalesce(a.productfamily ,'na')=coalesce(b.productfamily ,'na') and
					coalesce(a.serialnumber ,'na')=coalesce(b.serialnumber ,'na') and
					coalesce(a.materialdescription ,'na')=coalesce(b.materialdescription ,'na') and
					coalesce(a.originadesignmarket ,'na')=coalesce(b.originadesignmarket ,'na') and
					coalesce(a.originalbox ,'na')=coalesce(b.originalbox ,'na') and
					coalesce(a.version ,'na')=coalesce(b.version ,'na') and
					coalesce(a.factorycode ,'na')=coalesce(b.factorycode ,'na') and
					coalesce(a.codentifyid ,'na') = coalesce( r.codentifyid ,'na')	and		
					coalesce(a.id,'na') = coalesce( r.id,'na') and														
					a.time=r.time
					and r.rank=1 )b
					on coalesce(a.codentifyid ,'na') = coalesce( b.codentifyid ,'na') and 	coalesce(a.id,'na') = coalesce( b.id,'na') 
												where b.codentifyid  is null and b.id is null 
