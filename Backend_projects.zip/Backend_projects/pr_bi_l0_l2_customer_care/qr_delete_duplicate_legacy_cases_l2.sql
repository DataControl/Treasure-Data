delete from  db_l2_bi.cases_attributes where 
 concat(case_identifier,'-',latest_update_date) in (
 select concat(case_identifier,'-',cast(from_unixtime(latest_update_date) as varchar))
from db_stg_bi.cases_l2  )