delete from db_stg_current_record_dcs_bi.devices where time > 0;

insert into db_stg_current_record_dcs_bi.devices
select
distinct
id,
codentifyid,
ownerid,
parentid,
retailerid,
callcenterid,
registeredbusiness, --date
purchasedbusiness, --date
warrantyend, --date
replacedby,
replaces,
devicetype,
devicestatus,
lastactivity,
registeredsystem, --date
lastdeviceupdate, --date
componentid,
componentcode,
componentdescription,
touchpointid,
staffid,
sessionid,
purchasedatevalidation,
itrackmetadataid,
country,
created_by,
created_date,
last_modified_by,
last_modified_date,
1 as deletion_flag,
incomplete_ts,
incomplete_flag,
1 as anonymization_flag,
TD_TIME_PARSE(cast(CURRENT_TIMESTAMP as varchar), 'UTC') anonymization_ts,
session_uuid,
session_id,
session_uuid_from,
session_id_from
from db_stg_current_record_dcs_bi.devices_update_tmp;