delete from db_stg_bi.products where time > 0;

insert into db_stg_bi.products
select 
 createddate ,
    createdby ,
	 lastmodifieddate ,
	 lastmodifiedby ,
	  device_codetify ,
	 product_id ,
     market ,
	 product_description ,
    product_generation ,
	 product_family ,
	 system_last_updateded_date
      from ( 
select distinct 
	created_date  as createddate ,
    created_by as  createdby ,
	last_modified_date as lastmodifieddate ,
	last_modified_by as  lastmodifiedby ,
	device_codetify  device_codetify ,
	product_id  product_id ,
    device_country as market ,
	device_product_description as  product_description ,
   device_product_generation as product_generation ,
	product_family as  product_family ,
	latest_update_date as system_last_updateded_date,
row_number() over (partition by device_codetify   ,
	product_id   ,
    device_country  ,
	device_product_description  ,
   device_product_generation  ,
	product_family order by latest_update_date, time) as rank
from  db_stg_bi.cases_dcs_dce_union

where (product_id is not null and (created_by='sfdc' or created_by='dce' ))

and time >  ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 ))
					where rank=1