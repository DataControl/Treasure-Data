
insert into db_bi_monitoring.workflow_error select 'wf_l0_stg_current_bi_record_dce_sfdc' as workflow_name, 'pr_l0_l1_bi_customer_care' as project_name, '${session_uuid}' as session_uuid, '${session_id}' as session_id, '${session_time}' as session_time, '${session_date}' as session_date, 'task failure' as error_message;

