	delete from db_stg_bi.cases_dcs_dce_union where time >0 ;


	insert into db_stg_bi.cases_dcs_dce_union (
	created_date,
	created_by,
	last_modified_date,
	last_modified_by,
	case_identifier,
	persona_identifier,
	identity_identifier,
	closing_date,
	case_channel, 
	create_date,
	case_source, 
	case_type,
	case_subtype,
	status, 
	subject_code,
	subject_description,
	latest_update_date,
	home_country,
	escalation_flag,
	time_to_resolution,
	first_response_time,
	agent_id,
	device_issue_flag,
	resolution_code,
	device_codetify,
	device_product_generation,
	device_product_description,
	device_warranty_due_date_eligibilit,
	return_status,
	delivery_date,
	l1_result,
	l1_subject_description,
	closed_on_creation,
	time_to_resolution_hours,
	case_country,
	l1_result_description,
	replacedby,
    case_channel_harmonization_flag ,
	case_source_harmonization_flag ,
	case_type_harmonization_flag ,
	case_subtype_harmonization_flag ,
	status_harmonization_flag ,
	subject_code_harmonization_flag ,
	subject_description_harmonization_flag ,
	home_country_harmonization_flag  ,  
	device_country,
	product_id,
	product_family,
	deletion_flag)

	select
	
	created_date,
	created_by,
	last_modified_date,
	last_modified_by,
	case_identifier,
	persona_identifier,
	identity_identifier,
	closing_date,
	case_channel, 
	create_date,
	case_source, 
	case_type,
	case_subtype,
	status, 
	subject_code,
	subject_description,
	latest_update_date,
	home_country,
	escalation_flag,
	time_to_resolution,
	first_response_time,
	agent_id,
	device_issue_flag,
	resolution_code,
	device_codetify,
	device_product_generation,
	device_product_description,
	device_warranty_due_date_eligibilit,
	return_status,
	delivery_date,
	l1_result,
	l1_subject_description,
	closed_on_creation,
	time_to_resolution_hours,
	case_country ,
	l1_result_description ,
	replacedby,
    case_channel_harmonization_flag ,
	case_source_harmonization_flag ,
	case_type_harmonization_flag ,
	case_subtype_harmonization_flag ,
	status_harmonization_flag ,
	subject_code_harmonization_flag ,
	subject_description_harmonization_flag ,
	home_country_harmonization_flag  ,  
	device_country,
	product_id,
	product_family,
	deletion_flag

	from (

	select
	distinct
	dataset.created_date,
	dataset.created_by,
	dataset.last_modified_date,
	dataset.last_modified_by,
	dataset.case_identifier,
	dataset.persona_identifier,
	dataset.identity_identifier,
	dataset.closing_date,
	coalesce(case_channel_mapping.target_code,dataset.case_channel) as case_channel, 
	dataset.create_date,
	coalesce(case_source_mapping.target_code,dataset.case_source)  as case_source, 
	CASE 
	WHEN case_type_mapping.target_code LIKE '%_ML' THEN coalesce(case_type_mapping_multi.target_code,dataset.case_type) 
	ELSE  coalesce(case_type_mapping.target_code,dataset.case_type) 
	END AS case_type, -- multi level reference data mapping
	coalesce(case_subtype_mapping.target_code,dataset.case_subtype)   as case_subtype,
	coalesce(status_mapping.target_code,dataset.status)  as status, 
	coalesce(subject_code_mapping.target_code,dataset.subject_code) as subject_code,
	subject_code_mapping.target_description as subject_description,
	dataset.latest_update_date,
	coalesce(country_mapping.target_code,dataset.home_country)  as home_country,
	dataset.escalation_flag,
	dataset.time_to_resolution,
	dataset.first_response_time,
	dataset.agent_id,
	dataset.device_issue_flag,
	dataset.resolution_code,
	dataset.device_codetify,
	dataset.device_product_generation,
	dataset.device_product_description,
	dataset.device_warranty_due_date_eligibilit,
	dataset.return_status,
	dataset.delivery_date,
	dataset.l1_result,
	dataset.l1_subject_description,
	case when dataset.time_to_resolution=0 and coalesce(status_mapping.target_code,dataset.status)='COMPLETED' then 1 else 0 end  as closed_on_creation,
	case when ceiling(dataset.time_to_resolution/60)=0 then 1 else  ceiling(dataset.time_to_resolution/60)
    end 	as  time_to_resolution_hours,
	dataset.case_country as case_country ,
   l1_result_mapping.target_code as l1_result_description ,
   device_replacedby.ccr_replacedby__c as replacedby,
   case when case_channel_mapping.target_code is null then 0 else 1 end as   case_channel_harmonization_flag ,
   case when case_source_mapping.target_code is null then 0 else 1 end as case_source_harmonization_flag ,
   CASE 
	WHEN ( CASE WHEN case_type_mapping.target_code LIKE '%_ML' then case_type_mapping_multi.target_code 
	else  case_type_mapping.target_code end ) is null then 0 else 1 end
	 as  case_type_harmonization_flag ,
   case when case_subtype_mapping.target_code is null then 0 else 1 end as  case_subtype_harmonization_flag ,
   case when status_mapping.target_code is null then 0 else 1 end as  status_harmonization_flag ,
   case when subject_code_mapping.target_code is null then 0 else 1 end as  subject_code_harmonization_flag ,
   case when subject_code_mapping.target_description is null then 0 else 1 end as  subject_description_harmonization_flag ,
   case when country_mapping.target_code is null then 0 else 1 end as   home_country_harmonization_flag  ,  
   
   device_country.ccr_purchasecountry__c as device_country,
   dataset.product_id,
   dataset.product_family,
   
	dataset.deletion_flag

	from (

	  select 
	  a.created_date,
	  a.created_by,
	  a.last_modified_date,
	  a.last_modified_by,
	  a.case_identifier,
	  a.persona_identifier,
	  a.identity_identifier,
	  a.closing_date,
	  a.case_channel,
	  a.create_date,
	  a.case_source,
	  a.case_type,
	  a.case_subtype,
	  a.status,
	  a.subject_code,
	  a.latest_update_date,
	  a.home_country,
	  a.deletion_flag,
	  0 as anonymization_flag,
	  0 as anonymization_ts,
	  0 as incomplete_ts,
	  0 as incomplete_flag,
	  a.escalation_flag,
	  a.time_to_resolution,
	  a.first_response_time,
	  a.agent_id,  
	  a.device_issue_flag,
	  a.resolution_code,
	  a.device_codetify,
	  a.device_product_generation,
	  a.device_product_description,
	  a.device_warranty_due_date_eligibilit,
	  a.return_status,
	  a.delivery_date,
	  a.l1_result,
	  a.l1_subject_description,
	  a.case_country,
	  a.product_id,
	  a.product_family,
	  a.ccr_spiceid__c,
	  a.session_uuid,
	  a.session_id,
	  a.session_uuid_from,
	  a.session_id_from,
	  'dce' as data_ref_country_tmp
	  from 
	  (
		select 
		src.time,
		src.created_by,
		src.created_date,
		src.last_modified_by,
		src.last_modified_date,
		src.case_identifier,
		src.persona_identifier,
		src.identity_identifier,
		src.closing_date,
		src.case_channel,
		src.create_date,
		src.case_source,
		src.case_type, 
		src.case_subtype,
		src.status,
		src.subject_code,
		src.latest_update_date,
		src.home_country,
		src.deletion_flag,
		src.escalation_flag,
		src.time_to_resolution,
		src.first_response_time,
		src.agent_id, 
		src.device_issue_flag,
		src.resolution_code,
		src.device_codetify,
		src.device_product_generation,
		src.device_product_description,
		src.device_warranty_due_date_eligibilit,
		src.return_status,
		src.delivery_date,
		src.l1_result,
		src.l1_subject_description,	
		src.case_country,
		src.product_id,	
		src.product_family,	
		src.ccr_spiceid__c,
		src.session_uuid,
		src.session_id,
		src.session_uuid_from,
		src.session_id_from--,
	--	row_number() over (partition by src.case_identifier order by time) as rank_date
		from (
		  select 
		  src_sfdc_main.time,
		  src_sfdc_main.created_by,
		  src_sfdc_main.created_date,
		  src_sfdc_main.last_modified_by,
		  src_sfdc_main.last_modified_date,
		  'DCE_' || coalesce(src_sfdc_main.home_country,'XX') || '_' || src_sfdc_main.case_identifier as case_identifier, -- issue_id not present in DCE
		  src_2_dce.persona_identifier  as persona_identifier,
		  src_2_dce.identity_identifier  as identity_identifier, --cast(src_2_dce.person_application_login_login_id as VARCHAR) as identity_identifier,
		  src_sfdc_main.closing_date ,
		  src_sfdc_main.case_channel ,
		  src_sfdc_main.create_date ,
		  src_sfdc_main.case_source ,
		  src_sfdc_main.case_type ,
		  src_sfdc_main.case_subtype,
		  src_sfdc_main.status ,
		  src_sfdc_main.subject_code,
		  src_sfdc_main.latest_update_date ,
		  src_sfdc_main.home_country,
		  src_2_dce.deletion_flag as deletion_flag,
		  src_sfdc_main.escalation_flag,
		  src_sfdc_main.time_to_resolution,
		  src_sfdc_main.first_response_time,
		  'DCE_' || coalesce(src_sfdc_main.home_country,'XX') || '_' || src_sfdc_main.agent_id as agent_id,
		  src_sfdc_main.device_issue_flag,
		  src_sfdc_main.resolution_code,
		  src_sfdc_main.device_codetify,
		  src_sfdc_main.device_product_generation,
		  src_sfdc_main.device_product_description,
		  src_sfdc_main.device_warranty_due_date_eligibilit,
		  src_sfdc_main.return_status,
		  src_sfdc_main.delivery_date,
		  src_sfdc_main.l1_result,
		  src_sfdc_main.l1_subject_description,	
		  src_sfdc_main.ccr_spiceid__c	,	  
          src_sfdc_main.case_country,	
		  src_sfdc_main.product_id,	
		  src_sfdc_main.product_family,	
		  
		  src_sfdc_main.session_uuid,
		  src_sfdc_main.session_id,
		  src_sfdc_main.session_uuid_from,
		  src_sfdc_main.session_id_from
		  from (
			-- DCE
			select
			delta_dce.time,
			delta_dce.created_by,
			delta_dce.created_date,
			delta_dce.last_modified_by,
			delta_dce.last_modified_date,
			
			delta_dce.ccr_spiceid__c as ccr_spiceid__c, -- used to join only
			delta_dce.casenumber as case_identifier, 
			TD_TIME_PARSE(delta_dce.closeddate,'UTC')  as closing_date,
			delta_dce.ccr_contacttype__c as case_channel, 
			TD_TIME_PARSE(delta_dce.createddate,'UTC')  as create_date,
			delta_dce.ccr_typeinboundoutbound__c as case_source,
			delta_dce.type as case_type,
			delta_dce.ccr_subtype__c as case_subtype,
			delta_dce.status as status,
			coalesce(delta_dce.ccr_subjectcodenew__c,delta_dce.ccr_subjectcode__c) as subject_code,
			TD_TIME_PARSE(delta_dce.lastmodifieddate,'UTC') as latest_update_date,
			delta_dce.ccr_homecountry__c as home_country,
			delta_dce.isescalated as escalation_flag,
			 date_diff('MINUTE',cast(delta_dce.createddate as timestamp) ,cast(delta_dce.closeddate  as timestamp ) ) as time_to_resolution,
			'TBD' as first_response_time,
			delta_dce.ownerid as agent_id,  
			(case when upper(delta_dce.type) ='PRODUCT ISSUES' then 1 else 0 end )   as device_issue_flag,
			delta_dce.ccr_resolution__c as resolution_code,
			delta_dce.ccr_devicecodentify__c as device_codetify,
			delta_dce.ccr_productgeneration__c as device_product_generation,
			delta_dce.ccr_productdescription__c as device_product_description,
			delta_dce.ccr_eligibilityresult__c as device_warranty_due_date_eligibilit,
			delta_dce.ccr_devicereturnstatus__c  as return_status,
			0 delivery_date,
			delta_dce.ccr_qaresultl1__c as l1_result,
			delta_dce.ccr_qasubjectdescription__c as l1_subject_description,
			delta_dce.ccr_country__c as case_country,
			delta_dce.ccr_productvariant__c as product_id,
			delta_dce.ccr_productfamily__c as product_family,
						'${session_uuid}' as session_uuid,
			'${session_id}' as session_id,
			delta_dce.session_uuid as session_uuid_from,
			delta_dce.session_id as session_id_from
		
			from db_stg_current_record_dce_bi.cases_sfdc delta_dce
			where
			delta_dce.time > 
			   ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_stg_customer_care' and entity_name= 'customer_care_load' and operation_mode = 'insert' and completion_flag=0 ) 
			  where rank = 1 ) 
			) src_sfdc_main
			
			left outer join 
			(
			
			select rtrim(LTRIM(a.persona_identifier)) as persona_identifier ,b.identity_identifier,
			a.home_country ,a.deletion_flag from  db_l1_harmonization.person a inner join 
			(
			select persona_identifier, identity_identifier,
			 ROW_NUMBER() over (PARTITION by persona_identifier order by time desc) rank
			
			
			from db_l1_harmonization.consolidated_id) b
			on a.persona_identifier=b.persona_identifier and b.rank=1
		   -- select table1.person_person_id as person_person_id, table1.person_home_country_2l, table1.person_primary_login_id, table1.deletion_flag -- table2.person_application_login_login_id, 
		   -- from db_stg_current_record_dce.person table1
			--inner join db_stg_current_record_dce.person_application_login table2 on table1.person_person_id = table2.person_application_login_person_id
			
			-- join to remove rejected parent person (rejected in l1 person table)
			--***
		 ---  inner join db_l1_harmonization.person l1_per on l1_per.persona_identifier = 'DCE_' || table1.person_home_country_2l || '_' || table1.person_person_id
		  
			) src_2_dce
			on
           'DCE_' || coalesce(src_sfdc_main.home_country,'XX') || '_' || src_sfdc_main.ccr_spiceid__c = src_2_dce.persona_identifier 
	        and  src_sfdc_main.created_by in ('dce','sfdc') 
	 
			--src_sfdc_main.ccr_spiceid__c = src_2_dce.person_person_id
		   -- where src_2_dce.person_person_id is not null -- opposite rule for incomplete records
		  ) src
	  ) a
	--  where a.rank_date = 1
	) dataset

	left outer join db_stg_bi_technical.reference_data_mapping case_channel_mapping
	on case_channel_mapping.field_name = 'case_channel' and trim(upper(dataset.case_channel)) = trim(upper(case_channel_mapping.legacy_code)) and (dataset.created_by in ('dce','sfdc') and  case_channel_mapping.source ='dce') and dataset.data_ref_country_tmp = case_channel_mapping.ref_data_country  

	left outer join db_stg_bi_technical.reference_data_mapping case_source_mapping
	on case_source_mapping.field_name = 'case_source' and trim(upper(dataset.case_source)) = trim(upper(case_source_mapping.legacy_code)) and (dataset.created_by in ('dce','sfdc') and  case_source_mapping.source ='dce') and dataset.data_ref_country_tmp = case_source_mapping.ref_data_country 

	left outer join db_stg_bi_technical.reference_data_mapping case_type_mapping
	on case_type_mapping.field_name = 'case_type' and trim(upper(dataset.case_type)) = trim(upper(case_type_mapping.legacy_code)) and (dataset.created_by in ('dce','sfdc') and  case_type_mapping.source ='dce') and dataset.data_ref_country_tmp = case_type_mapping.ref_data_country 

	left outer join db_stg_technical.reference_data_mapping_multilevels case_type_mapping_multi
	on case_type_mapping_multi.first_level_field_name = 'case_type' 
	and trim(upper(case_type_mapping.target_code)) = trim(upper(case_type_mapping_multi.first_level_code)) 
	and (dataset.created_by in ('dce','sfdc') and  case_type_mapping_multi.source ='dce')
	and case_type_mapping.ref_data_country = case_type_mapping_multi.ref_data_country
	and case_type_mapping_multi.second_level_field_name = 'case_subtype' 
	and trim(upper(dataset.case_subtype)) = trim(upper(case_type_mapping_multi.second_level_code))

	left outer join db_stg_bi_technical.reference_data_mapping case_subtype_mapping
	on case_subtype_mapping.field_name = 'case_subtype' and trim(upper(dataset.case_subtype)) = trim(upper(case_subtype_mapping.legacy_code)) and (dataset.created_by in ('dce','sfdc') and  case_subtype_mapping.source ='dce') and dataset.data_ref_country_tmp = case_subtype_mapping.ref_data_country 

	left outer join db_stg_bi_technical.reference_data_mapping status_mapping
	on status_mapping.field_name = 'case_status' and trim(upper(dataset.status)) = trim(upper(status_mapping.legacy_code)) and (dataset.created_by in ('dce','sfdc') and  status_mapping.source ='dce')  and dataset.data_ref_country_tmp = status_mapping.ref_data_country 

	left outer join db_stg_bi_technical.reference_data_mapping subject_code_mapping
	on subject_code_mapping.field_name = 'subject_code' and trim(upper(dataset.subject_code)) = trim(upper(subject_code_mapping.legacy_code)) and (dataset.created_by in ('dce','sfdc') and  subject_code_mapping.source ='dce') and dataset.data_ref_country_tmp = subject_code_mapping.ref_data_country 

	left outer join db_stg_bi_technical.reference_data_mapping country_mapping
	on country_mapping.field_name = 'country_2l' and trim(upper(dataset.home_country)) = trim(upper(country_mapping.legacy_code)) and (dataset.created_by in ('dce','sfdc') and  country_mapping.source ='dce') and dataset.data_ref_country_tmp = country_mapping.ref_data_country 

	left outer join db_stg_bi_technical.reference_data_mapping l1_result_mapping
	on l1_result_mapping.field_name = 'l1_result' and (dataset.created_by in ('dce','sfdc') and  l1_result_mapping.source ='dce') and substr(dataset.l1_result,1,1) = l1_result_mapping.legacy_code
	
	left outer join 
	(
	 select * from (
	select ccr_codentifyid__c, ccr_replacedby__c,ccr_spiceid__c, row_number() over (partition by ccr_codentifyid__c,ccr_spiceid__c 	order by lastmodifieddate desc, time desc) as rank
	from db_l0_sfdc.asset where ccr_replacedby__c is not null and ccr_spiceid__c is not null  ) where rank=1)  as device_replacedby
	on dataset.device_codetify =device_replacedby.ccr_codentifyid__c and dataset.ccr_spiceid__c=device_replacedby.ccr_spiceid__c
	left outer join 
	
	
	(
	select  ccr_codentifyid__c,ccr_spiceid__c,ccr_purchasecountry__c 
	from (select distinct ccr_codentifyid__c,ccr_spiceid__c,ccr_purchasecountry__c , ROW_NUMBER() over (PARTITION by  ccr_codentifyid__c,ccr_spiceid__c  order by lastmodifieddate,time desc) rank
	from db_l0_sfdc.asset where ccr_purchasecountry__c is not null) where rank=1 
	) as device_country
	on dataset.device_codetify =device_country.ccr_codentifyid__c and dataset.ccr_spiceid__c=device_country.ccr_spiceid__c
	union

	select
	dataset.created_date,
	dataset.created_by,
	dataset.last_modified_date,
	dataset.last_modified_by,
	dataset.case_identifier,
	dataset.persona_identifier,
	dataset.identity_identifier,
	dataset.closing_date,
	coalesce(case_channel_mapping.target_code,dataset.case_channel)  as case_channel, 
	dataset.create_date,
	coalesce(case_source_mapping.target_code,dataset.case_source)  as case_source, 
    coalesce(case_type_mapping.target_code,dataset.case_type) as case_type,
	dataset.case_subtype,
	coalesce(status_mapping.target_code,dataset.status) as status, 
	coalesce(subject_code_mapping.target_code,dataset.subject_code)  as subject_code,
	subject_code_mapping.target_description as subject_description,
	dataset.latest_update_date,
	coalesce(country_mapping.target_code,dataset.home_country) as home_country,
	dataset.escalation_flag,
	dataset.time_to_resolution,
	dataset.first_response_time,
	dataset.agent_id,
	(case when upper(coalesce(case_type_mapping.target_code,dataset.case_type)) ='PRODUCT ISSUES' then 1 else 0 end )   as device_issue_flag,
	dataset.resolution_code,
	dataset.device_codetify,
	dataset.device_product_generation,
	dataset.device_product_description,
	dataset.device_warranty_due_date_eligibilit,
	dataset.return_status,
	dataset.delivery_date,
	dataset.l1_result,
	dataset.l1_subject_description, 
	case when dataset.time_to_resolution=0 and coalesce(status_mapping.target_code,dataset.status)='COMPLETED' then 1 else 0 end  as closed_on_creation,
	case when ceiling(dataset.time_to_resolution/60)=0 then 1 else  ceiling(dataset.time_to_resolution/60)
    end 	as  time_to_resolution_hours,
	coalesce(country_mapping.target_code,dataset.home_country) as case_country ,
    l1_result_mapping.target_code as l1_result_description ,
	dataset.replacedby,
	case when case_channel_mapping.target_code is null then 0 else 1 end as   case_channel_harmonization_flag ,
    case when case_source_mapping.target_code is null then 0 else 1 end as case_source_harmonization_flag ,
    case when case_type_mapping.target_code is null then 0 else 1 end 	 as  case_type_harmonization_flag ,
    case when dataset.case_subtype is null then 0 else 1 end as  case_subtype_harmonization_flag ,
    case when status_mapping.target_code is null then 0 else 1 end as  status_harmonization_flag ,
    case when subject_code_mapping.target_code is null then 0 else 1 end as  subject_code_harmonization_flag ,  
    case when subject_code_mapping.target_description is null then 0 else 1 end as  subject_description_harmonization_flag ,
    case when country_mapping.target_code is null then 0 else 1 end as   home_country_harmonization_flag  ,   
	null as device_country,
	null as product_id,
	null as product_family,
	dataset.deletion_flag
	from (

	  select 
	  a.created_date,
	  a.created_by,
	  a.last_modified_date,
	  a.last_modified_by,
	  a.case_identifier,
	  a.persona_identifier,
	  a.identity_identifier,
	  a.closing_date,
	  a.case_channel,
	  a.create_date,
	  a.case_source,
	  a.case_type,
	  a.case_subtype,
	  a.status,
	  a.subject_code,
	  a.latest_update_date,
	  a.home_country,
	  a.deletion_flag,
	  a.anonymization_flag,
	  a.anonymization_ts,
	  0 as incomplete_ts,
	  0 as incomplete_flag,
		a.escalation_flag,
	  a.time_to_resolution,
	  a.first_response_time,
	  a.agent_id, 
	  a.device_issue_flag,
	  a.resolution_code,
	  a.device_codetify,
	  a.device_product_generation,
	  a.device_product_description,
	  a.device_warranty_due_date_eligibilit,
	  a.return_status,
	  a.delivery_date,
	  a.l1_result,
	  a.l1_subject_description,
	  a.replacedby	  ,
	  a.session_uuid,
	  a.session_id,
	  a.session_uuid_from,
	  a.session_id_from,
	  a.data_ref_country_tmp
	  from 
	  (
		select 
		src.time,
		src.created_by,
		src.created_date,
		src.last_modified_by,
		src.last_modified_date,
		src.case_identifier,
		src.persona_identifier,
		src.identity_identifier,
		src.closing_date,
		src.case_channel,
		src.create_date,
		src.case_source,
		src.case_type, 
		src.case_subtype,
		src.status,
		src.subject_code,
		src.latest_update_date,
		src.home_country,
		src.deletion_flag,
		src.escalation_flag,
		src.time_to_resolution,
		src.first_response_time,
		src.agent_id,  
		src.device_issue_flag,
		src.resolution_code,
		src.device_codetify,
		src.device_product_generation,
		src.device_product_description,
		src.device_warranty_due_date_eligibilit,
		src.return_status,
		src.delivery_date,
		src.l1_result,
		src.l1_subject_description,
		src.replacedby,
		src.anonymization_flag,
		src.anonymization_ts,
		src.session_uuid,
		src.session_id,
		src.session_uuid_from,
		src.session_id_from,
		src.data_ref_country_tmp--,
		--row_number() over (partition by src.case_identifier order by time) as rank_date
		from (
			select
			src_main_dcs.time,
			src_main_dcs.created_by,
			src_main_dcs.created_date,
			src_main_dcs.last_modified_by,
			src_main_dcs.last_modified_date,
			src_main_dcs.case_identifier,
			src_main_dcs.persona_identifier,
			src_2_dcs.identity_identifier as identity_identifier,
			src_main_dcs.closing_date,
			src_main_dcs.case_channel,
			src_main_dcs.create_date,
			src_main_dcs.case_source,
			src_main_dcs.case_type,
			src_main_dcs.case_subtype,
			src_main_dcs.status,
			src_main_dcs.subject_code,
			src_main_dcs.latest_update_date,
			src_main_dcs.home_country,
			src_2_dcs.deletion_flag,
			src_main_dcs.escalation_flag,
			src_main_dcs.time_to_resolution,
			src_main_dcs.first_response_time,
			src_main_dcs.agent_id,  
			src_main_dcs.device_issue_flag,
			src_main_dcs.resolution_code,
			src_main_dcs.device_codetify,
			src_main_dcs.device_product_generation,
			d.device_type as device_product_description,
			case when d.end_of_warranty_date > src_main_dcs.create_date then 'Eligible' else 'Not Eligible' end  as device_warranty_due_date_eligibilit,
			case when r.returnedcodentifyid is not null then '1' else '0' end  as return_status,
			0 delivery_date,
			src_main_dcs.l1_result,
			src_main_dcs.l1_subject_description,
			d.replacedby,
			1 as anonymization_flag,
			1 as anonymization_ts,
			src_main_dcs.session_uuid,
			src_main_dcs.session_id,
			src_main_dcs.session_uuid_from,
			src_main_dcs.session_id_from,
			src_main_dcs.home_country as data_ref_country_tmp
			from (
				select
				delta_main_dcs.time as time,
				delta_main_dcs.created_by,
				delta_main_dcs.created_date,
				delta_main_dcs.last_modified_by,
				delta_main_dcs.last_modified_date,
				'DCS_' ||  coalesce(delta_main_dcs.country,'XX') || '_' ||  delta_main_dcs.case_id || '_' || delta_main_dcs.issue_id as case_identifier, -- no coalesce required as it should always there
				delta_main_dcs.user_id as user_id, -- used to join only
				'DCS_' || delta_main_dcs.country || '_' || delta_main_dcs.user_id as persona_identifier,
				delta_main_dcs.close_date as closing_date,
				delta_main_dcs.contact_type as case_channel,
				delta_main_dcs.creation_date as create_date,
				delta_main_dcs.inbound_outbound as case_source,
				cast(null as varchar) as case_type,  -- data mapping
				cast(null as varchar) as case_subtype, -- data mapping
				delta_main_dcs.status as status,
				delta_main_dcs.subject_code as subject_code,
				delta_main_dcs.update_date as latest_update_date,
				delta_main_dcs.country as home_country,
				-1 as escalation_flag,
			 date_diff('MINUTE',cast(FROM_UNIXTIME(delta_main_dcs.creation_date) as timestamp) ,cast(
			 FROM_UNIXTIME(delta_main_dcs.close_date)  as timestamp ) ) as time_to_resolution,
			'TBD' as first_response_time,
			'DCS_' ||  coalesce(delta_main_dcs.country,'XX') || '_' ||  delta_main_dcs.owner_id || '_' || delta_main_dcs.issue_id as agent_id,  
			-1  as device_issue_flag,
			null as resolution_code,
			delta_main_dcs.codentify_code as device_codetify,
			null as device_product_generation,
			delta_main_dcs.result_l1 as l1_result,
			delta_main_dcs.qa_subject_descripton  as l1_subject_description,
			'${session_uuid}' as session_uuid,
				'${session_id}' as session_id,
				delta_main_dcs.session_uuid as session_uuid_from,
				delta_main_dcs.session_id as session_id_from
				from  db_stg_current_record_dcs_bi.cases delta_main_dcs
				where time >  ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_stg_customer_care' and entity_name= 'customer_care_load' and operation_mode = 'insert' and completion_flag=0 ) 
			  where rank = 1 )  -- join the delta transaction data with the full person profile
			) src_main_dcs
			left outer join 
			
 (select * from 
 (select device_codentify,device_type,warrantyend as end_of_warranty_date,replacedby,
row_number() over (partition by device_codentify order by lastdeviceupdate ,tm desc) as rank_date
from
(
select codentifyid as device_codentify,
devicetype as device_type,
TD_TIME_PARSE(cast(to_iso8601(parse_datetime(nullif(warrantyend,''), 'dd/MM/YYYY HH:mm:ss')) as varchar), 'UTC') as warrantyend,replacedby,
TD_TIME_PARSE(cast(to_iso8601(parse_datetime(nullif(lastdeviceupdate,''), 'dd/MM/YYYY HH:mm:ss')) as varchar), 'UTC') as lastdeviceupdate,
time as tm

from db_l0_odatadcs.devices
 ) )where rank_date=1) d
			on src_main_dcs.device_codetify=d.device_codentify
			left outer join (select distinct returnedcodentifyid from db_l0_odatadcs.devicereturns) r
			 on d.device_codentify=r.returnedcodentifyid
			left outer join
			--db_stg_current_record_dcs.users
			(select rtrim(LTRIM(a.persona_identifier)) as persona_identifier ,b.identity_identifier,
			a.home_country ,a.deletion_flag from  db_l1_harmonization.person a inner join 
			(
					select persona_identifier, identity_identifier,
					 ROW_NUMBER() over (PARTITION by persona_identifier order by time desc) rank
					from db_l1_harmonization.consolidated_id ) b
			on a.persona_identifier=b.persona_identifier and b.rank=1)	src_2_dcs	
			on src_main_dcs.persona_identifier = src_2_dcs.persona_identifier
			and src_main_dcs.created_by='dcs'
			--src_main_dcs.user_id = src_2_dcs.user_id 
			-- join to remove rejected parent person (rejected in l1 person table)
			--***
		  --inner join db_l1_harmonization.person l1_per on l1_per.persona_identifier = 'DCS_'  || src_2_dcs.country || '_' || src_2_dcs.user_id
		) src-- opposite rule for incomplete
	  ) a
	   --where  a.rank_date = 1
	  ) dataset

	left outer join db_stg_bi_technical.reference_data_mapping case_channel_mapping
	on case_channel_mapping.field_name = 'case_channel' and trim(upper(dataset.case_channel)) = trim(upper(case_channel_mapping.legacy_code)) and (dataset.created_by in ('dcs') and  case_channel_mapping.source ='dcs') and dataset.data_ref_country_tmp = case_channel_mapping.ref_data_country  

	left outer join db_stg_bi_technical.reference_data_mapping case_source_mapping
	on case_source_mapping.field_name = 'case_source' and trim(upper(dataset.case_source)) = trim(upper(case_source_mapping.legacy_code)) and (dataset.created_by in ('dcs') and  case_source_mapping.source ='dcs') and dataset.data_ref_country_tmp = case_source_mapping.ref_data_country 

	left outer join db_stg_bi_technical.reference_data_mapping status_mapping
	on status_mapping.field_name = 'case_status' and trim(upper(dataset.status)) = trim(upper(status_mapping.legacy_code)) and (dataset.created_by in ('dcs') and  status_mapping.source ='dcs') and dataset.data_ref_country_tmp = status_mapping.ref_data_country 

	left outer join db_stg_bi_technical.reference_data_mapping subject_code_mapping
	on subject_code_mapping.field_name = 'subject_code' and trim(upper(dataset.subject_code)) = trim(upper(subject_code_mapping.legacy_code)) and (dataset.created_by in ('dcs') and  subject_code_mapping.source ='dcs') and dataset.data_ref_country_tmp = subject_code_mapping.ref_data_country 

	left outer join db_stg_bi_technical.reference_data_mapping country_mapping
	on country_mapping.field_name = 'country_2l' and trim(upper(dataset.home_country)) = trim(upper(country_mapping.legacy_code)) and (dataset.created_by in ('dcs') and  country_mapping.source ='dcs') and dataset.data_ref_country_tmp = country_mapping.ref_data_country 
	
	left outer join   db_stg_bi_technical.reference_data_mapping  case_type_mapping
	on case_type_mapping.field_name  ='record_type' and    trim(upper(dataset.subject_code))=trim(upper(case_type_mapping.legacy_code))
	
	left outer join db_stg_bi_technical.reference_data_mapping l1_result_mapping
	on l1_result_mapping.field_name = 'l1_result' and (dataset.created_by in ('dcs' ) and  l1_result_mapping.source ='dcs') and substr(dataset.l1_result,1,1) = l1_result_mapping.legacy_code

	)

