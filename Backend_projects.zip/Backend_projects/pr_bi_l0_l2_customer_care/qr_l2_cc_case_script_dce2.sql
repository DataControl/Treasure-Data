insert into db_l2_bi.cases
					(   record_id,
						createddate,
						createdby,
						lastmodifieddate,
						lastmodifiedby,
						case_identifier,
						create_date,
						closing_date,
						time_to_resolution ,
						first_response_time						
						
					) 
						select   record_id,
						createddate,
								createdby,
								lastmodifieddate,
								lastmodifiedby,
								case_identifier,
								create_date,
								closing_date,
								time_to_resolution ,
								first_response_time 
								from 
								(
						
						select 
					   record_id,
						createddate as createddate,
								createdby as createdby,
								lastmodifieddate	 as lastmodifieddate,
								lastmodifiedby as lastmodifiedby,
								case_identifier,
								create_date,
								closing_date,
								time_to_resolution ,
								null as first_response_time,
							 row_number() over (partition by case_identifier order by  time desc) as rank
						  from db_l1_bi_organic.cases)
												  where rank=1