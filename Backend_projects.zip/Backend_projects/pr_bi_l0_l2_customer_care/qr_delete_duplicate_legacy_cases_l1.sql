delete from  db_l1_bi_csc_legacy.cases where 
concat(case_identifier,'-',cast(latest_update_date as varchar)) in (
 select concat(case_identifier,'-',cast(latest_update_date as varchar))
from db_stg_bi.cases  );