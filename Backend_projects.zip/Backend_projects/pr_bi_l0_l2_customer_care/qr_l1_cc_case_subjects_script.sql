delete from  db_l1_bi_csc_legacy.case_subjects where createdby <> 'dce2' and
  time >
                ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 );

insert into db_l1_bi_csc_legacy.case_subjects
					(   record_id,
						createddate,
						createdby,
						lastmodifieddate,
						lastmodifiedby,						
						subject_code,
					  subject_description,
						home_country	
						
					) 
						select  100006 as 	record_Id,
								a.createddate,
								a.createdby,
								a.lastmodifieddate,
								a.lastmodifiedby,
								a.subject_code,
								a.subject_description,
								a.home_country
														from(select distinct  
									created_date as createddate,
									created_by as createdby ,
									last_modified_date as lastmodifieddate,
									last_modified_by  as lastmodifiedby,
									subject_code as subject_code,
									subject_description as subject_description,
									home_country as home_country,
									ROW_NUMBER() over (PARTITION by subject_code,home_country order by  subject_description,time desc) rank,
									time as time
									from db_stg_bi.cases_dcs_dce_union where subject_code is not null )  a
                             left outer join 
                              (
                                           select 
												b.createddate,
												b.createdby,
												b.lastmodifieddate,
												b.lastmodifiedby,												
												b.subject_code,
												b.subject_description,
												b.home_country,
												b.time
												from  db_l1_bi_csc_legacy.case_subjects  a,
											(select distinct  
									created_date as createddate,
									created_by as createdby ,
									last_modified_date as lastmodifieddate,
									last_modified_by  as lastmodifiedby,
									subject_code as subject_code,
									subject_description as subject_description,
									home_country as home_country,
									ROW_NUMBER() over (PARTITION by subject_code,home_country order by  subject_description,time desc) rank,
									time 
									from db_stg_bi.cases_dcs_dce_union where subject_code is not null)  b ,
											(select ROW_NUMBER() over (PARTITION by subject_code order by time desc) rank,subject_code,time from db_l1_bi_csc_legacy.case_subjects) r
											where
																						
												coalesce(a.subject_code,'na') = coalesce( b.subject_code,'na')  and
												coalesce(a.subject_description,'na') = coalesce( b.subject_description,'na')  and
											    coalesce(a.home_country,'na') = coalesce( b.home_country,'na')	and
												a.subject_code = r.subject_code
												and a.time=r.time
												and r.rank=1 and b.rank=1)b
												on a.subject_code = b.subject_code 
												where b.subject_code  is null and a.rank=1 
