delete from  db_stg_bi.devices_l2 where time > 0;
insert into db_stg_bi.devices_l2

(
   createddate ,
   createdby ,
   lastmodifieddate ,
   lastmodifiedby ,
   id ,
   codentifyid ,
   ownerid ,
   retailerid ,
   registeredbusiness ,
   purchasedbusiness ,
   warrantyend ,
   devicetype ,
   devicestatus ,
   lastactivity ,
   lastdeviceupdate ,
   componentid ,
   componentcode,
   componentdescription,
   purchasedatevalidation ,
   country ,
   return_status ,
   replacedby,
replaces,
   time 

)


select 
  distinct
    src.created_date createddate,
	src.created_by  as created_by,
	src.last_modified_date lastmodifieddate,
    src.last_modified_by as lastmodifiedby,    
     'DCE_' || COALESCE(country_mapping.legacy_code,src.country,'') || '_' || COALESCE(src.id,'') as id,	
   src.codentifyid ,
   src.ownerid ,
   src.retailerid ,
   src.registeredbusiness ,
   src.purchasedbusiness ,
   src.warrantyend ,
   COALESCE(device_type_mapping.legacy_code,src.devicetype ) as devicetype,
   COALESCE(status_mapping.legacy_code, src.devicestatus) as devicestatus,
   src.lastactivity ,
   src.lastdeviceupdate ,
   src.componentid ,
   null as componentcode,
   null as componentdescription,
   src.purchasedatevalidation ,
   COALESCE(country_mapping.legacy_code,src.country ) as country,
   -1 as return_status,
   src.replacedby,
   src.replaces,
   src.time
    
    from 
    (
select 
        
    delta_dce.created_by,
    delta_dce.created_date,
    delta_dce.last_modified_by,
    delta_dce.last_modified_date,
      delta_dce.id ,
   delta_dce.ccr_codentifyid__c  as codentifyid,
   delta_dce.ownerid ,
   null as retailerid ,
  TD_TIME_PARSE(delta_dce.createddate,'UTC') as registeredbusiness ,
    TD_TIME_PARSE( delta_dce.purchasedate,'UTC')  as purchasedbusiness ,
   TD_TIME_PARSE( delta_dce.ccr_warrantyduedate__c,'UTC') as warrantyend ,
   delta_dce.ccr_materialgroupdescription__c as devicetype ,
   delta_dce.status  as devicestatus  ,
   null as lastactivity ,
   TD_TIME_PARSE(delta_dce.lastmodifieddate,'UTC') as lastdeviceupdate ,
   delta_dce.ccr_deviceproductcode__c as componentid ,
   null as purchasedatevalidation ,
   delta_dce.ccr_purchasecountry__c as country,
   delta_dce.ccr_purchasecountry__c  as data_ref_country_tmp,
   delta_dce.ccr_replacedby__c as replacedby,
   delta_dce.ccr_replaces__c as replaces,
   delta_dce.time
        from db_stg_current_record_dce_bi.device_sfdc delta_dce
        where delta_dce.time > 
		( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )) src
					
					left outer join db_stg_bi_technical.reference_data_mapping device_type_mapping
	on device_type_mapping.field_name = 'device_type' and trim(upper(src.devicetype)) = trim(upper(device_type_mapping.legacy_code)) and (src.created_by in ('sfdc','dce') and device_type_mapping.source = 'dce') and src.data_ref_country_tmp = device_type_mapping.ref_data_country  

	left outer join db_stg_bi_technical.reference_data_mapping status_mapping
	on status_mapping.field_name = 'status' and trim(upper(src.devicestatus)) = trim(upper(status_mapping.legacy_code)) and (src.created_by in ('sfdc','dce') and status_mapping.source = 'dce') and src.data_ref_country_tmp = status_mapping.ref_data_country  

	left outer join db_stg_bi_technical.reference_data_mapping country_mapping
	on country_mapping.field_name = 'country_2l' and trim(upper(src.country)) = trim(upper(country_mapping.legacy_code)) and ( src.created_by in ('sfdc','dce') and country_mapping.source = 'dce') 

UNION 

select 
 distinct
  src.created_date,
  src.created_by,
  src.last_modified_date,
  src.last_modified_by,
'DCS_' || COALESCE(country_mapping.legacy_code,src.country,'') || '_' || COALESCE(src.id,'') as id,
     
   src.codentifyid ,
   src.ownerid ,
   src.retailerid ,
   src.registeredbusiness ,
   src.purchasedbusiness ,
   src.warrantyend ,
   COALESCE(device_type_mapping.legacy_code,src.devicetype ) as devicetype,
   COALESCE(status_mapping.legacy_code, src.devicestatus) as devicestatus,
   src.lastactivity ,
   src.lastdeviceupdate ,
   src.componentid ,
   src.componentcode as componentcode,
   src.componentdescription as componentdescription,
   src.purchasedatevalidation ,
   COALESCE(country_mapping.legacy_code,src.country ) as country,
   case when r.returnedcodentifyid is not null then 1 else 0 end  as return_status,
     src.replacedby,
   src.replaces,
    src.time
    from 
    (
select 
        
    delta_dcs.created_by,
    delta_dcs.created_date,
    delta_dcs.last_modified_by,
    delta_dcs.last_modified_date,
      delta_dcs.id ,
   delta_dcs.codentifyid ,
   delta_dcs.ownerid ,
   delta_dcs.retailerid ,
   delta_dcs.registeredbusiness ,
   delta_dcs.purchasedbusiness ,
   delta_dcs.warrantyend ,
   delta_dcs.devicetype ,
   delta_dcs.devicestatus  ,
   delta_dcs.lastactivity ,
   delta_dcs.lastdeviceupdate ,
   delta_dcs.componentid ,
   delta_dcs.componentcode as componentcode,
   delta_dcs.componentdescription as componentdescription,
   delta_dcs.purchasedatevalidation ,
   delta_dcs.country ,
   delta_dcs.country  as data_ref_country_tmp,
   delta_dcs.replacedby,
   delta_dcs.replaces,
   delta_dcs.time
        from db_stg_current_record_dcs_bi.devices delta_dcs
        where delta_dcs.time > 
		( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_stg_customer_care'
												   and entity_name= 'customer_care_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )) src
					
						left outer join (select distinct returnedcodentifyid from db_l0_odatadcs.devicereturns) r
			 on src.codentifyid=r.returnedcodentifyid
					
						left outer join db_stg_bi_technical.reference_data_mapping device_type_mapping
	on device_type_mapping.field_name = 'device_type' and trim(upper(src.devicetype)) = trim(upper(device_type_mapping.legacy_code)) and (src.created_by = 'dcs' and device_type_mapping.source = 'dcs') and src.data_ref_country_tmp = device_type_mapping.ref_data_country  

	left outer join db_stg_bi_technical.reference_data_mapping status_mapping
	on status_mapping.field_name = 'status' and trim(upper(src.devicestatus)) = trim(upper(status_mapping.legacy_code)) and (src.created_by = 'dcs' and status_mapping.source = 'dcs')  and src.data_ref_country_tmp = status_mapping.ref_data_country  

left outer join db_stg_bi_technical.reference_data_mapping country_mapping
	on country_mapping.field_name = 'country_2l' and trim(upper(src.country)) = trim(upper(country_mapping.legacy_code)) and (src.created_by = 'dcs' and country_mapping.source = 'dcs') 
					