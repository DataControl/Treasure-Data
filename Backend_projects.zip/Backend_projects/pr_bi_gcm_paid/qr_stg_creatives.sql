delete from db_stg_gcm_bi.creatives where time > 0;
insert into  db_stg_gcm_bi.creatives
 ( createddate	, 
createdby	,
lastmodifieddate	,
lastmodifiedby	,
advertiser_id ,
rendering_id ,
creative_id ,
creative ,
creative_last_modified_date, 
creative_type, 
creative_pixel_size, 
creative_image_url, 
creative_version, 
gcm_insert_date, 
time   
) 
    select  
	  cast(TO_UNIXTIME(CAST(s.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	    s.createdby,
	    cast(TO_UNIXTIME(CAST(s.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	    s.lastmodifiedby, 
		  s.advertiser_id,
		  s.rendering_id,
		  s.creative_id, 
		  s.creative, 
		  s.creative_last_modified_date, 
		  s.creative_type, 
		  s.creative_pixel_size, 
		  s.creative_image_url, 
		  s.creative_version, 
		  cast(TO_UNIXTIME(CAST(s.gcm_insert_date AS TIMESTAMP)) AS BIGINT) as  gcm_insert_date, 
		  s.time 
FROM db_l0_gcm_bi.creatives_match s;