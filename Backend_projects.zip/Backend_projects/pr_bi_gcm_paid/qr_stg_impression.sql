delete from db_stg_gcm_bi.impression where date in 
(select distinct date from db_l0_gcm_bi.impression); 

insert into db_stg_gcm_bi.impression ( 
createddate, 
createdby, 
lastmodifieddate, 
lastmodifiedby,    
impression_id,   
event_time,   
user_id,  
advertiser_id,   
campaign_id,   
ad_id,   
rendering_id,   
creative_version,   
placement_id,   
country_code, 
site_id, 
active_view_eligible_impressions, 
active_view_measurable_impressions, 
active_view_viewable_impressions, 
date, 
gcm_insert_date, 
time  
) 
          select 
          cast(TO_UNIXTIME(CAST(L0.createddate AS TIMESTAMP)) AS BIGINT) as createddate,
	      L0.createdby as createdby,
	      cast(TO_UNIXTIME(CAST(L0.lastmodifieddate AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	      L0.lastmodifiedby as lastmodifiedby,   
  		  L0.impression_id,   
  		  L0.event_timestamp as event_time,   
  		  L0.user_id,   
  		  L0.advertiser_id,   
  		  L0.campaign_id,   
  		  L0.ad_id,  
  		  L0.rendering_id,   
  		  L0.creative_version,   
  		  L0.placement_id,  
  		  L0.country_code,  
		  L0.site_id_dcm, 
		  L0.active_view_eligible_impressions, 
		  L0.active_view_measurable_impressions,
		  L0.active_view_viewable_impressions, 
		  L0.date, 
      cast(TO_UNIXTIME(CAST(L0.gcm_insert_date AS TIMESTAMP)) AS BIGINT) as gcm_insert_date, 
		  L0.time 

from  db_l0_gcm_bi.impression L0; 