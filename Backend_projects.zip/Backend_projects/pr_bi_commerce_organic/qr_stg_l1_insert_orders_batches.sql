delete from db_l1_bi_organic.orders_batches  where unique_order_identifier
in (select unique_order_identifier from db_stg_bi.orders_batches); 
insert into db_l1_bi_organic.orders_batches
											(
												record_id,
												createddate ,
												createdby ,
												lastmodifieddate ,
												lastmodifiedby ,
												order_number ,
												unique_order_identifier ,
												correlation_id ,
												batchquantityunit ,
												batchitemno ,
												batchquantity ,
												batchid ,
												source_system 
											)
	select 
			rec_id.max_id + cast(row_number() over (order by time) as bigint) as 	record_Id,
			createddate ,
			createdby ,
			lastmodifieddate ,
			lastmodifiedby ,
			order_number ,
			unique_order_identifier ,
			correlation_id ,
			batchquantityunit ,
			batchitemno ,
			batchquantity ,
			batchid ,
			source_system 

	from 
		(
		select 
				distinct createddate ,
				createdby ,
				lastmodifieddate ,
				lastmodifiedby ,
				order_number ,
				unique_order_identifier ,
				correlation_id ,
				batchquantityunit ,
				batchitemno ,
				batchquantity ,
				batchid ,
				source_system ,
				time
		from db_stg_bi.orders_batches),
		(select  COALESCE (cast(max(record_Id) as bigint),0) max_id 
		from db_l1_bi_organic.orders_batches) rec_id;
