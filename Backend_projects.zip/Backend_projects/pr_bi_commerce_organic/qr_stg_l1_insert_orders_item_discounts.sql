delete from db_l1_bi_organic.orders_item_discounts  where unique_order_identifier
in (select unique_order_identifier from db_stg_bi.orders_item_discounts);
 
insert into db_l1_bi_organic.orders_item_discounts
												(
													record_id,
													CreatedDate		,
													CreatedBy		,
													LastModifiedDate		,
													LastModifiedBy		,
													orderno		,
													unique_order_identifier		,
													deliveryitemnumber		,
													identity_unique_identifier		,
													itemdiscountgross		,
													itemdiscountdescr		,
													itemdiscountcode		,
													itemdiscountno		,
													itemdiscountnet		,
													itemdiscounttype		,
													correlation_id		,
													Source_system 
												)
	select 
			rec_id.max_id + cast(row_number() over (order by time) as bigint) as 	record_Id,
			CreatedDate		,
			CreatedBy		,
			LastModifiedDate		,
			LastModifiedBy		,
			orderno		,
			unique_order_identifier		,
			deliveryitemnumber		,
			identity_unique_identifier		,
			itemdiscountgross		,
			itemdiscountdescr		,
			itemdiscountcode		,
			itemdiscountno		,
			itemdiscountnet		,
			itemdiscounttype		,
			correlation_id		,
			Source_system

	from 
		(
		select 
				distinct   CreatedDate		,
				CreatedBy		,
				LastModifiedDate		,
				LastModifiedBy		,
				orderno		,
				unique_order_identifier		,
				deliveryitemnumber		,
				identity_unique_identifier		,
				itemdiscountgross		,
				itemdiscountdescr		,
				itemdiscountcode		,
				itemdiscountno		,
				itemdiscountnet		,
				itemdiscounttype		,
				correlation_id		,
				Source_system,
				time
		from db_stg_bi.orders_item_discounts),
		(select  COALESCE (cast(max(record_Id) as bigint),0) max_id 
		from db_l1_bi_organic.orders_item_discounts) rec_id;
