--LOG ERROR IN db_monitoring.workflow_error
insert into db_bi_monitoring.workflow_error select ' wf_bi_l1_l2_commerce_organic_incr_sub'  as workflow_name, 'pr_bi_commerce_organic' as project_name, '${session_uuid}' as session_uuid, '${session_id}' as session_id, '${session_time}' as session_time, '${session_date}' as session_date, 'task failure' as error_mes
