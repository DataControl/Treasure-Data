insert into  db_l1_bi_organic.orders 
	( 
	record_id, 
    created_date, 
created_by, 
last_modified_date, 
last_modified_by,
unique_order_identifier	,
order_number	,
shipping_status	,
home_country	,
sales_channel	,
order_date	,
order_amount	,
shipping_method	,
shipping_method_description	,
coupon_code	,
promotional_code	,
promotional_description	,
order_type	,
order_type_description	,
order_status	,
order_reason	,
order_reason_description	,
order_channel	,
identity_identifier	,
shipping_date	,
shipment_address_city 	,
shipment_shipping_address_postal_code	,
cancellation_reason_code	,
payment_date	,
country	,
order_currency	,
order_placed_by	,
shipping_identifier	,
payment_status	,
payment_method	,
order_update_time	, 
paymentdetail_authorisationtime, 
salesprice_carriernet	,
salesprice_netoriginal	,
salesprice_subtotalgross	,
salesprice_carriervat	,
salesprice_gross	,
salesprice_grossoriginal	,
salesprice_salesvatrate	,
salesprice_net	,
salesprice_vatvalue	,
salesprice_carriergross	,
taxid	,
hardageverificationneeded	,
business	,
wbselement	,
deliverydescription	,
dispatchtype	,
shop_shopno	,
paymentdetail_authamount	,
customer_shippingandbillingequal	,
division	,
deliverymode	,
transno	,
orderrefno	,
basestore	, 
source_system,   
time  
	) 
select 
rec_id.max_id + cast(row_number() over (order by s.time) as bigint) as 	record_id, 
s.created_date ,
s.created_by ,
s.last_modified_date ,
s.last_modified_by,
s.unique_order_identifier,
s.order_number,
s.shipping_status,
s.home_country,
s.sales_channel,
s.order_date,
s.order_amount,
s.shipping_method,
s.shipping_method_description,
s.coupon_code,
s.promotional_code,
s.promotional_description,
s.order_type,
s.order_type_description,
s.order_status,
s.order_reason,
s.order_reason_description,
s.order_channel,
s.identity_identifier,
s.shipping_date,
s.shipment_address_city ,
s.shipment_shipping_address_postal_code,
s.cancellation_reason_code,
s.payment_date,
s.country,
s.order_currency,
s.order_placed_by,
s.shipping_identifier,
s.payment_status,
s.payment_method,
s.order_update_time,
s.paymentdetail_authorisationtime, 
s.salesprice_carriernet,
s.salesprice_netoriginal,
s.salesprice_subtotalgross,
s.salesprice_carriervat,
s.salesprice_gross,
s.salesprice_grossoriginal,
s.salesprice_salesvatrate,
s.salesprice_net,
s.salesprice_vatvalue,
s.salesprice_carriergross,
s.taxid,
s.hardageverificationneeded,
s.business,
s.wbselement,
s.deliverydescription,
s.dispatchtype,
s.shop_shopno,
s.paymentdetail_authamount,
s.customer_shippingandbillingequal,
s.division,
s.deliverymode,
s.transno,
s.orderrefno,
s.basestore, 
s.source_system,  
s.time  

from ( 
	select distinct 
-- rec_id.max_id + cast(row_number() over (order by a.time) as bigint) as 	record_id, 
a.created_date ,
a.created_by ,
a.last_modified_date ,
a.last_modified_by,
a.unique_order_identifier,
a.order_number,
a.shipping_status,
a.home_country,
a.sales_channel,
a.order_date,
a.order_amount,
a.shipping_method,
a.shipping_method_description,
a.coupon_code,
a.promotional_code,
a.promotional_description,
a.order_type,
a.order_type_description,
a.order_status,
a.order_reason,
a.order_reason_description,
a.order_channel,
a.identity_identifier,
a.shipping_date,
a.shipment_address_city ,
a.shipment_shipping_address_postal_code,
a.cancellation_reason_code,
a.payment_date,
a.country,
a.order_currency,
a.order_placed_by,
a.shipping_identifier,
a.payment_status,
a.payment_method,
a.order_update_time,
a.paymentdetail_authorisationtime, 
a.salesprice_carriernet,
a.salesprice_netoriginal,
a.salesprice_subtotalgross,
a.salesprice_carriervat,
a.salesprice_gross,
a.salesprice_grossoriginal,
a.salesprice_salesvatrate,
a.salesprice_net,
a.salesprice_vatvalue,
a.salesprice_carriergross,
a.taxid,
a.hardageverificationneeded,
a.business,
a.wbselement,
a.deliverydescription,
a.dispatchtype,
a.shop_shopno,
a.paymentdetail_authamount,
a.customer_shippingandbillingequal,
a.division,
a.deliverymode,
a.transno,
a.orderrefno,
a.basestore, 
a.source_system,   
a.time   
	from db_stg_bi.orders_organic  a
    left outer join 
    (
	select
   b.created_date ,
b.created_by ,
b.last_modified_date ,
b.last_modified_by,
b.unique_order_identifier,
b.order_number,
b.shipping_status,
b.home_country,
b.sales_channel,
b.order_date,
b.order_amount,
b.shipping_method,
b.shipping_method_description,
b.coupon_code,
b.promotional_code,
b.promotional_description,
b.order_type,
b.order_type_description,
b.order_status,
b.order_reason,
b.order_reason_description,
b.order_channel,
b.identity_identifier,
b.shipping_date,
b.shipment_address_city ,
b.shipment_shipping_address_postal_code,
b.cancellation_reason_code,
b.payment_date,
b.country,
b.order_currency,
b.order_placed_by,
b.shipping_identifier,
b.payment_status,
b.payment_method,
b.order_update_time,
b.paymentdetail_authorisationtime, 
b.salesprice_carriernet,
b.salesprice_netoriginal,
b.salesprice_subtotalgross,
b.salesprice_carriervat,
b.salesprice_gross,
b.salesprice_grossoriginal,
b.salesprice_salesvatrate,
b.salesprice_net,
b.salesprice_vatvalue,
b.salesprice_carriergross,
b.taxid,
b.hardageverificationneeded,
b.business,
b.wbselement,
b.deliverydescription,
b.dispatchtype,
b.shop_shopno,
b.paymentdetail_authamount,
b.customer_shippingandbillingequal,
b.division,
b.deliverymode,
b.transno,
b.orderrefno,
b.basestore, 
b.source_system, 
b.time
	from  db_l1_bi_organic.orders a, 
	 db_stg_bi.orders_organic b ,
	(select ROW_NUMBER() over (PARTITION by unique_order_identifier order by time desc) rank, unique_order_identifier, time from db_l1_bi_organic.orders) r
	where 
	coalesce(a.unique_order_identifier,'na') = coalesce(b.unique_order_identifier,'na')  and 
coalesce(a.order_number,'na') = coalesce(b.order_number,'na')  and 
coalesce(a.shipping_status,'na') = coalesce(b.shipping_status,'na')  and 
coalesce(a.home_country,'na') = coalesce(b.home_country,'na')  and 
coalesce(a.sales_channel,'na') = coalesce(b.sales_channel,'na')  and 
coalesce(a.order_date,'na') = coalesce(b.order_date,'na')  and 
coalesce(a.order_amount,'na') = coalesce(b.order_amount,'na')  and 
coalesce(a.shipping_method,'na') = coalesce(b.shipping_method,'na')  and 
coalesce(a.shipping_method_description,'na') = coalesce(b.shipping_method_description,'na')  and 
coalesce(a.coupon_code,'na') = coalesce(b.coupon_code,'na')  and 
coalesce(a.promotional_code,'na') = coalesce(b.promotional_code,'na')  and 
coalesce(a.promotional_description,'na') = coalesce(b.promotional_description,'na')  and 
coalesce(a.order_type,'na') = coalesce(b.order_type,'na')  and 
coalesce(a.order_type_description,'na') = coalesce(b.order_type_description,'na')  and 
coalesce(a.order_status,'na') = coalesce(b.order_status,'na')  and 
coalesce(a.order_reason,'na') = coalesce(b.order_reason,'na')  and 
coalesce(a.order_reason_description,'na') = coalesce(b.order_reason_description,'na')  and 
coalesce(a.order_channel,'na') = coalesce(b.order_channel,'na')  and 
coalesce(a.identity_identifier,'na') = coalesce(b.identity_identifier,'na')  and 
coalesce(a.shipping_date,'na') = coalesce(b.shipping_date,'na')  and 
coalesce(a.shipment_address_city ,'na') = coalesce(b.shipment_address_city ,'na')  and 
coalesce(a.shipment_shipping_address_postal_code,'na') = coalesce(b.shipment_shipping_address_postal_code,'na')  and 
coalesce(a.cancellation_reason_code,'na') = coalesce(b.cancellation_reason_code,'na')  and 
coalesce(a.payment_date,'na') = coalesce(b.payment_date,'na')  and 
coalesce(a.country,'na') = coalesce(b.country,'na')  and 
coalesce(a.order_currency,'na') = coalesce(b.order_currency,'na')  and 
coalesce(a.order_placed_by,'na') = coalesce(b.order_placed_by,'na')  and 
coalesce(a.shipping_identifier,'na') = coalesce(b.shipping_identifier,'na')  and 
coalesce(a.payment_status,'na') = coalesce(b.payment_status,'na')  and 
coalesce(a.payment_method,'na') = coalesce(b.payment_method,'na')  and 
coalesce(a.order_update_time,'na') = coalesce(b.order_update_time,'na')  and 
coalesce(a.paymentdetail_authorisationtime,'na') = coalesce(b.paymentdetail_authorisationtime,'na')  and 
coalesce(a.salesprice_carriernet,'na') = coalesce(b.salesprice_carriernet,'na')  and 
coalesce(a.salesprice_netoriginal,'na') = coalesce(b.salesprice_netoriginal,'na')  and 
coalesce(a.salesprice_subtotalgross,'na') = coalesce(b.salesprice_subtotalgross,'na')  and 
coalesce(a.salesprice_carriervat,'na') = coalesce(b.salesprice_carriervat,'na')  and 
coalesce(a.salesprice_gross,'na') = coalesce(b.salesprice_gross,'na')  and 
coalesce(a.salesprice_grossoriginal,'na') = coalesce(b.salesprice_grossoriginal,'na')  and 
coalesce(a.salesprice_salesvatrate,'na') = coalesce(b.salesprice_salesvatrate,'na')  and 
coalesce(a.salesprice_net,'na') = coalesce(b.salesprice_net,'na')  and 
coalesce(a.salesprice_vatvalue,'na') = coalesce(b.salesprice_vatvalue,'na')  and 
coalesce(a.salesprice_carriergross,'na') = coalesce(b.salesprice_carriergross,'na')  and 
coalesce(a.taxid,'na') = coalesce(b.taxid,'na')  and 
coalesce(a.hardageverificationneeded,'na') = coalesce(b.hardageverificationneeded,'na')  and 
coalesce(a.business,'na') = coalesce(b.business,'na')  and 
coalesce(a.wbselement,'na') = coalesce(b.wbselement,'na')  and 
coalesce(a.deliverydescription,'na') = coalesce(b.deliverydescription,'na')  and 
coalesce(a.dispatchtype,'na') = coalesce(b.dispatchtype,'na')  and 
coalesce(a.shop_shopno,'na') = coalesce(b.shop_shopno,'na')  and 
coalesce(a.paymentdetail_authamount,'na') = coalesce(b.paymentdetail_authamount,'na')  and 
coalesce(a.customer_shippingandbillingequal,'na') = coalesce(b.customer_shippingandbillingequal,'na')  and 
coalesce(a.division,'na') = coalesce(b.division,'na')  and 
coalesce(a.deliverymode,'na') = coalesce(b.deliverymode,'na')  and 
coalesce(a.transno,'na') = coalesce(b.transno,'na')  and 
coalesce(a.orderrefno,'na') = coalesce(b.orderrefno,'na')  and 
coalesce(a.basestore,'na') = coalesce(b.basestore,'na')  and 
coalesce(a.source_system,'na') = coalesce(b.source_system,'na')  and 
-- coalesce(a.td_c360_operation_time, 0) = coalesce(b.td_c360_operation_time, 0)  and 
	a.unique_order_identifier  	=	b.unique_order_identifier 
	and a.unique_order_identifier  	=	r.unique_order_identifier and 
	r.rank=1 and a.time = r.time) b
	on a.unique_order_identifier  	=	b.unique_order_identifier   										
--	(select  COALESCE (cast(max(record_id) as bigint),0) max_id from db_l1_bi_organic.orders) rec_id 
	where b.unique_order_identifier  is null 

	and a.time > ( select last_load_ts 
                                      from (
                                            select last_load_ts,   
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'bi_ecommerce'
												   and entity_name= 'ecommerce' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1)) s, 
(select  COALESCE (cast(max(record_id) as bigint),0) max_id from db_l1_bi_organic.orders) rec_id;