delete from db_stg_bi.orders_batches where time >0;
insert into db_stg_bi.orders_batches (
									   createddate ,
									   createdby ,
									   lastmodifieddate ,
									   lastmodifiedby ,
									   order_number ,
									   unique_order_identifier ,
									   correlation_id ,
									   batchquantityunit ,
									   batchitemno ,
									   batchquantity ,
									   batchid ,
									   source_system 
  
									)
	select 
		   createddate ,
		   createdby ,
		   lastmodifieddate ,
		   lastmodifiedby ,
		   order_number ,
		   unique_order_identifier ,
		   correlation_id ,
		   batchquantityunit ,
		   batchitemno ,
		   batchquantity ,
		   batchid ,
		   source_system 
   from 
		(
		select
			td_time_parse(cast(current_timestamp as varchar), 'utc')	as	CreatedDate	,
			'dce2'	as	CreatedBy	,
			td_time_parse(cast(current_timestamp as varchar), 'utc')	as	LastModifiedDate	,
			'dce2'	as	LastModifiedBy	,
			orderno	as	order_number	,
			concat(orderno,'_',batchid) as	unique_order_identifier	,
			correlation_id	as	correlation_id	,
			batchquantityunit	as	batchquantityunit	,
			batchitemno	as	batchitemno	,
			batchquantity	as	batchquantity	,
			batchid	as	batchid	,
			'DCE20' as source_system,
			ROW_NUMBER() over (partition by 
			concat(orderno,'_',batchid) order by cast(substr(cast( td_c360_operation_time as VARCHAR),1,10)as BIGINT) desc ) as rank
		from db_l0_organic.orders_batches_parsed where  orderno is not null and batchid is not null and cast(substr(cast( td_c360_operation_time as VARCHAR),1,10)as BIGINT) >
			
			 
			 	( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_ecommerce' and entity_name= 'ecommerce' and operation_mode = 'insert' and completion_flag= 0 ) 
          where rank = 1 ) 
		) 
	where rank=1
