delete from db_stg_bi.orders_discounts where time >0;
insert into db_stg_bi.orders_discounts (
										   createddate ,
										   createdby ,
										   lastmodifieddate ,
										   lastmodifiedby ,
										   order_number ,
										   unique_order_identifier ,
										   itemdiscountno ,
											itemdiscountcode ,
											itemdiscounttype ,
											itemdiscountgross ,
											itemdiscountnet ,
											itemdiscountdescr ,
											correlation_id ,
											source_system  
										) 
		select 
			   createddate ,
			   createdby ,
			   lastmodifieddate ,
			   lastmodifiedby ,
			   order_number ,
			   unique_order_identifier ,
			   itemdiscountno ,
			   itemdiscountcode ,
			   itemdiscounttype ,
			   itemdiscountgross ,
			   itemdiscountnet ,
			   itemdiscountdescr ,
			   correlation_id ,
			   source_system 
		from    
            ( 
			select
					td_time_parse(cast(current_timestamp as varchar), 'utc')	as	createddate	,
					'dce2'	as	createdby	,
					td_time_parse(cast(current_timestamp as varchar), 'utc')	as	lastmodifieddate	,
					'dce2'	as	lastmodifiedby	,
					o.orderno	as	order_number	,
					concat(o.orderno,'_', o.itemdiscountno) as	unique_order_identifier	,
					o.itemdiscountno	as	itemdiscountno	,
					o.itemdiscountcode	as	itemdiscountcode	,
					o.itemdiscounttype	as	itemdiscounttype	,
					o.itemdiscountgross	as	itemdiscountgross	,
					o.itemdiscountnet	as	itemdiscountnet	,
					o.itemdiscountdescr	as	itemdiscountdescr	,
					o.correlation_id	as	correlation_id	,
					'DCE2.0'	as	source_system	,
					ROW_NUMBER() over (partition by 
					concat(o.orderno,'_', o.itemdiscountno) order by cast(substr(cast(o.td_c360_operation_time as VARCHAR),1,10) as BIGINT) desc ) as rank 
			from db_l0_organic.orders_discount_parsed o where o.orderno is not null and o.itemdiscountno is not null and lower(COALESCE(o.correlation_id, 'NA')) not like 'mig-%' and 
			cast(substr(cast(o.td_c360_operation_time as VARCHAR),1,10) as BIGINT) >
			
			
			 	( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_ecommerce' and entity_name= 'ecommerce' and operation_mode = 'insert' and completion_flag= 0 ) 
          where rank = 1 ) 
					
			)
		where rank=1; 