delete from db_stg_bi.orders_item_discounts where time >0;
insert into  db_stg_bi.orders_item_discounts
											(
												CreatedDate		,
												CreatedBy		,
												LastModifiedDate		,
												LastModifiedBy		,
												orderno		,
												unique_order_identifier		,
												deliveryitemnumber		,
												identity_unique_identifier		,
												itemdiscountgross		,
												itemdiscountdescr		,
												itemdiscountcode		,
												itemdiscountno		,
												itemdiscountnet		,
												itemdiscounttype		,
												correlation_id		,
												Source_system		
											)
	select 
			CreatedDate		,
			CreatedBy		,
			LastModifiedDate		,
			LastModifiedBy		,
			orderno		,
			unique_order_identifier		,
			deliveryitemnumber		,
			identity_unique_identifier		,
			itemdiscountgross		,
			itemdiscountdescr		,
			itemdiscountcode		,
			itemdiscountno		,
			itemdiscountnet		,
			itemdiscounttype		,
			correlation_id		,
			Source_system
	from 
		(
		select
				td_time_parse(cast(current_timestamp as varchar), 'utc')	as	CreatedDate	,
				'dce2'	as	CreatedBy	,
				td_time_parse(cast(current_timestamp as varchar), 'utc')	as	LastModifiedDate	,
				'dce2'	as	LastModifiedBy	,
				orderno	as	orderno	,
				 concat(orderno,'_',deliveryitemnumber,'_',itemdiscountno) as	unique_order_identifier	,
				deliveryitemnumber	as	deliveryitemnumber	,
				identity_unique_identifier	as	identity_unique_identifier	,
				itemdiscountgross	as	itemdiscountgross	,
				itemdiscountdescr	as	itemdiscountdescr	,
				itemdiscountcode	as	itemdiscountcode	,
				itemdiscountno	as	itemdiscountno	,
				itemdiscountnet	as	itemdiscountnet	,
				itemdiscounttype	as	itemdiscounttype	,
				correlation_id	as	correlation_id	,
				'DCE2.0'	as	source_system	,
				ROW_NUMBER() over (partition by 
				concat(orderno,'_',deliveryitemnumber,'_',itemdiscountno) order by cast(substr(cast( td_c360_operation_time as VARCHAR),1,10) as BIGINT) desc ) as rank

		from db_l0_organic.orders_item_discount_parsed where orderno is not null and deliveryitemnumber is not null and  itemdiscountno is not null and lower(COALESCE(correlation_id, 'NA')) not like 'mig-%' and cast(substr(cast( td_c360_operation_time as VARCHAR),1,10) as BIGINT) >
			
			 	( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_ecommerce' and entity_name= 'ecommerce' and operation_mode = 'insert' and completion_flag= 0 ) 
          where rank = 1 ) 
		)
	where rank=1;