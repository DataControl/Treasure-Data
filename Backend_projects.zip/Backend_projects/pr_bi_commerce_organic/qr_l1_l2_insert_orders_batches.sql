   delete from db_l2_bi.commerce_orders_batches where 
    unique_order_identifier in (select  unique_order_identifier from 
   db_l1_bi_organic.orders_batches where 
   time > 
   ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_ecommerce' and entity_name= 'ecommerce' and operation_mode = 'insert' and completion_flag= 0 ) 
          where rank = 1 )) ;

insert into db_l2_bi.commerce_orders_batches 
  ( record_id ,
   createddate ,
   createdby ,
   lastmodifieddate ,
   lastmodifiedby ,
   order_number ,
   unique_order_identifier ,
   correlation_id ,
   batchquantityunit ,
   batchitemno ,
   batchquantity ,
   batchid ,
   source_system )

select 
   record_id ,
   createddate ,
   createdby ,
   lastmodifieddate ,
   lastmodifiedby ,
   order_number ,
   unique_order_identifier ,
   correlation_id ,
   batchquantityunit ,
   batchitemno ,
   batchquantity ,
   batchid ,
   source_system 
   from
   db_l1_bi_organic.orders_batches where time > 
   
   ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_ecommerce' and entity_name= 'ecommerce' and operation_mode = 'insert' and completion_flag= 0 ) 
          where rank = 1 ) ;