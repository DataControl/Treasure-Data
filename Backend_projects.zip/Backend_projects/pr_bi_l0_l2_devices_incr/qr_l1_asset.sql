delete  from  db_stg_bi.asset where time>0;

insert into db_stg_bi.asset
(
	record_id 					,
    createddate 				,
    createdby 					,
    lastmodifieddate 			,
    lastmodifiedby 			,
    id,
	system     					,
	device_codentify            ,
	pack_codentify              ,
	device_product_code         ,
	product_variant_code        ,
	device_material_group       ,
	device_material_description ,
	device_model                ,
	device_color                ,
	device_version              ,
	pack_product_category       ,
	internal_id                 ,
	packaging_date_time				
)

select

record_id 					,
createddate ,
createdby 	,
lastmodifieddate 	,
lastmodifiedby 	,
id,
system     	,
device_codentify            ,
pack_codentify              ,
device_product_code         ,
product_variant_code        ,
device_material_group       ,
device_material_description ,
device_model                ,
device_color                ,
device_version              ,
pack_product_category       ,
internal_id                 ,
packaging_date_time			

from 
(
	select 

		src.record_id 					,
		src.createddate 				,
		src.createdby 					,
		src.lastmodifieddate 			,
		src.lastmodifiedby 			,
		src.id,
		src.system     					,
		src.device_codentify            ,
		src.pack_codentify              ,
		src.device_product_code         ,
		src.product_variant_code        ,
		src.device_material_group       ,
		src.device_material_description ,
		src.device_model                ,
		src.device_color                ,
		src.device_version              ,
		src.pack_product_category       ,
		src.internal_id                 ,
		src.packaging_date_time			,
		row_number() over (partition by src.device_codentify  order by src.time desc) as rank	


	from 
	(
		select 

			rec_id.max_id + cast(row_number() over (order by at.time) as bigint) as	record_id, 
			cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as createddate,
			cast('Devices_Asset' as varchar) as createdby,
			cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
			cast('Devices_Asset' as varchar) as lastmodifiedby,
			concat (cast(at.device_codentify as varchar),'-',cast(at.td_c360_operation_time as varchar))	as id,
			at.system as  system     					,
			at.device_codentify            ,
			at.pack_codentify as  pack_codentify              ,
			at.device_product_code     as device_product_code    ,
			at.product_variant_code as   product_variant_code        ,
			at.device_material_group as device_material_group       ,
			at.device_material_description as device_material_description ,
			at.device_model as   device_model                ,
			at.device_color as device_color                ,
			at.device_version as device_version              ,
			at.pack_product_category as pack_product_category       ,
			at.internal_id as internal_id                 ,
			at.packaging_date_time as packaging_date_time	,
			at.time as time
			   
		  from db_l0_organic.bi_asset at, 
		(select  COALESCE(cast(max(record_id) as bigint),0) max_id from db_l1_bi_organic.asset) rec_id   
		where time >  ( select last_load_ts
											  from (
													select last_load_ts, 
														   ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
														   from db_stg_bi_technical.delta_load_log_dce 
														   where layer = 'db_l1_devices'
														   and entity_name= 'devices' 
														   and operation_mode = 'insert' 
														   and completion_flag = 0 order by time desc 
													) where rank = 1 )
													
	) src
)					
where rank=1;


insert into db_l1_bi_organic.asset
(
    record_id 					,
    createddate 				,
    createdby 					,
    lastmodifieddate 			,
    lastmodifiedby 			,
    id,
	system     					,
	device_codentify            ,
	pack_codentify              ,
	device_product_code         ,
	product_variant_code        ,
	device_material_group       ,
	device_material_description ,
	device_model                ,
	device_color                ,
	device_version              ,
	pack_product_category       ,
	internal_id                 ,
	packaging_date_time			
)

select 

    record_id 					,
    createddate 				,
    createdby 					,
    lastmodifieddate 			,
    lastmodifiedby 			,
    id,
	system     					,
	device_codentify            ,
	pack_codentify              ,
	device_product_code         ,
	product_variant_code        ,
	device_material_group       ,
	device_material_description ,
	device_model                ,
	device_color                ,
	device_version              ,
	pack_product_category       ,
	internal_id                 ,
	packaging_date_time			
	   
  from db_stg_bi.asset at