delete  from  db_stg_bi.asset_diagnostic_history where time>0;

insert into db_stg_bi.asset_diagnostic_history
(
    record_id 						,
    createddate 					,
    createdby 						,
    lastmodifieddate 				,
    lastmodifiedby 				,
	id								,
	qure_channel					,
	diagnostic_end_date				,
	diagnostic_start_date			,
	diagnostic_result				,
	device_codentify				,
	user_id			,
	td_c360_operation,
	td_c360_operation_time
)

select

    record_id 						,
    createddate 					,
    createdby 						,
    lastmodifieddate 				,
    lastmodifiedby 				,
	id								,
	qure_channel					,
	diagnostic_end_date				,
	diagnostic_start_date			,
	diagnostic_result				,
	device_codentify				,
	user_id			,
	td_c360_operation,
	td_c360_operation_time
from 
(
	select 

	src.record_id 						,
    src.createddate 					,
    src.createdby 						,
    src.lastmodifieddate 				,
    src.lastmodifiedby 				,
	src.id								,
	src.qure_channel					,
	src.diagnostic_end_date				,
	src.diagnostic_start_date			,
	src.diagnostic_result				,
	src.device_codentify				,
	src.user_id			,
	src.td_c360_operation,
	src.td_c360_operation_time,
	row_number() over (partition by src.id  order by src.time desc) as rank	


	from 
	(

		select 

			rec_id.max_id + cast(row_number() over (order by adh.time) as bigint) as	record_id,
			cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as createddate,
			cast('Devices_Asset_Diagnostic_History' as varchar) as createdby,
			cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
			cast('Devices_Asset_Diagnostic_History' as varchar) as lastmodifiedby,
			concat (cast(adh.device_codentify as varchar),'-',cast(adh.diagnostic_start_date as varchar))	as id,
			adh.qure_channel,
			adh.diagnostic_end_date,
			adh.diagnostic_start_date,
			adh.diagnostic_result,
			adh.device_codentify,
			adh.user_id,
			adh.td_c360_operation,
			adh.td_c360_operation_time,
			adh.time as time
			   
		  from db_l0_organic.cdp_diagnostichistory adh, 
		(select  COALESCE(cast(max(record_id) as bigint),0) max_id from db_l1_bi_organic.asset_diagnostic_history) rec_id   
		where time >  ( select last_load_ts
											  from (
													select last_load_ts, 
														   ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
														   from db_stg_bi_technical.delta_load_log_dce 
														   where layer = 'db_l1_devices'
														   and entity_name= 'devices' 
														   and operation_mode = 'insert' 
														   and completion_flag = 0 order by time desc 
													) where rank = 1 )
	) src
)					
where rank=1;						

insert into db_l1_bi_organic.asset_diagnostic_history
(
    record_id 						,
    createddate 					,
    createdby 						,
    lastmodifieddate 				,
    lastmodifiedby 				,
	id								,
	qure_channel					,
	diagnostic_end_date				,
	diagnostic_start_date			,
	diagnostic_result				,
	device_codentify				,
	user_id							,
	td_c360_operation,
	td_c360_operation_time
)

select 

    adh.record_id 						,
    adh.createddate 					,
    adh.createdby 						,
    adh.lastmodifieddate 				,
    adh.lastmodifiedby 				,
	adh.id								,
	adh.qure_channel					,
	adh.diagnostic_end_date				,
	adh.diagnostic_start_date			,
	adh.diagnostic_result				,
	adh.device_codentify				,
	adh.user_id,
	adh.td_c360_operation,
	adh.td_c360_operation_time					
	   
  from db_stg_bi.asset_diagnostic_history adh