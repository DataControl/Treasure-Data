delete  from  db_stg_bi.asset_action where time>0;

insert into db_stg_bi.asset_action
(
	record_id 		,
	createddate 	,
	createdby 		,
	lastmodifieddate,
	lastmodifiedby 	,
	id				,
	l0_created_date	,
	l0_created_by   ,
	l0_modified_date,
	l0_modified_by  ,
	system          ,
	asset_id        ,
	action_id       ,
	action_date     ,
	identity_id		
)

select

	record_id 		,
	createddate 	,
	createdby 		,
	lastmodifieddate,
	lastmodifiedby 	,
	id				,
	l0_created_date	,
	l0_created_by   ,
	l0_modified_date,
	l0_modified_by  ,
	system          ,
	asset_id        ,
	action_id       ,
	action_date     ,
	identity_id		

from 
(
	select 

		src.record_id 		,
		src.createddate 	,
		src.createdby 		,
		src.lastmodifieddate,
		src.lastmodifiedby 	,
		src.id				,
		src.l0_created_date	,
		src.l0_created_by   ,
		src.l0_modified_date,
		src.l0_modified_by  ,
		src.system          ,
		src.asset_id        ,
		src.action_id       ,
		src.action_date     ,
		src.identity_id		,
		row_number() over (partition by src.id  order by src.time desc) as rank	


	from 
	(
		select 

			rec_id.max_id + cast(row_number() over (order by ac.time) as bigint) as	record_id, 
			cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as createddate,
			cast('Devices_Asset' as varchar) as createdby,
			cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
			cast('Devices_Asset' as varchar) as lastmodifiedby,
			ac.id	as id,
			ac.created_date	as l0_created_date,
			ac.created_by   as l0_created_by,
			ac.modified_date as l0_modified_date,
			ac.modified_by  as l0_modified_by,
			ac.system          ,
			ac.asset_id        ,
			ac.action_id       ,
			ac.action_date     ,
			ac.identity_id		,
			ac.time as time
			   
		  from db_l0_organic.bi_asset_action ac, 
		(select  COALESCE(cast(max(record_id) as bigint),0) max_id from db_l1_bi_organic.asset_action) rec_id   
		where time >  ( select last_load_ts
											  from (
													select last_load_ts, 
														   ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
														   from db_stg_bi_technical.delta_load_log_dce 
														   where layer = 'db_l1_devices'
														   and entity_name= 'devices' 
														   and operation_mode = 'insert' 
														   and completion_flag = 0 order by time desc 
													) where rank = 1 )
													
	) src
)					
where rank=1;


insert into db_l1_bi_organic.asset_action
(
	record_id 		,
	createddate 	,
	createdby 		,
	lastmodifieddate,
	lastmodifiedby 	,
	id				,
	l0_created_date	,
	l0_created_by   ,
	l0_modified_date,
	l0_modified_by  ,
	system          ,
	asset_id        ,
	action_id       ,
	action_date     ,
	identity_id		
)

select 

	record_id 		,
	createddate 	,
	createdby 		,
	lastmodifieddate,
	lastmodifiedby 	,
	id				,
	l0_created_date	,
	l0_created_by   ,
	l0_modified_date,
	l0_modified_by  ,
	system          ,
	asset_id        ,
	action_id       ,
	action_date     ,
	identity_id		
	   
  from db_stg_bi.asset_action at