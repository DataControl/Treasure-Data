delete  from  db_stg_bi.asset_action_dictionary where time>0;

insert into db_stg_bi.asset_action_dictionary
(
    record_id 						,
    createddate 					,
    createdby 						,
    lastmodifieddate 				,
    lastmodifiedby 				,
	id							,
	domain						,
	code						,
	value						
)

select

    record_id 						,
    createddate 					,
    createdby 						,
    lastmodifieddate 				,
    lastmodifiedby 				,
	id							,
	domain						,
	code						,
	value						
from 
(
	select 

	src.record_id 						,
    src.createddate 					,
    src.createdby 						,
    src.lastmodifieddate 				,
    src.lastmodifiedby 				,
	id							,
	domain						,
	code						,
	value						,
	src.time,
	row_number() over (partition by src.id  order by src.time desc) as rank	


	from 
	(

		select 

			rec_id.max_id + cast(row_number() over (order by dic.time) as bigint) as	record_id,
			cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as createddate,
			cast('Devices_Asset_Diagnostic_History' as varchar) as createdby,
			cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
			cast('Devices_Asset_Diagnostic_History' as varchar) as lastmodifiedby,

			dic.id							,
			dic.domain						,
			dic.code						,
			dic.value						,
			dic.time as time
			   
		  from db_l0_organic.bi_dictionary dic, 
		(select  COALESCE(cast(max(record_id) as bigint),0) max_id from db_l1_bi_organic.asset_action_dictionary) rec_id   
		where time >  ( select last_load_ts
											  from (
													select last_load_ts, 
														   ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
														   from db_stg_bi_technical.delta_load_log_dce 
														   where layer = 'db_l1_devices'
														   and entity_name= 'devices' 
														   and operation_mode = 'insert' 
														   and completion_flag = 0 order by time desc 
													) where rank = 1 )
	) src
)					
where rank=1;						

insert into db_l1_bi_organic.asset_action_dictionary
(
    record_id 						,
    createddate 					,
    createdby 						,
    lastmodifieddate 				,
    lastmodifiedby 				,
	id							,
	domain						,
	code						,
	value	
)

select 

    adh.record_id 						,
    adh.createddate 					,
    adh.createdby 						,
    adh.lastmodifieddate 				,
    adh.lastmodifiedby 				,
	id							,
	domain						,
	code						,
	value			
	   
  from db_stg_bi.asset_action_dictionary adh