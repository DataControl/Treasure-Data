insert into db_stg_bi_technical.delta_load_log_dce
select 'db_l1_devices' as layer, 'insert' as operation_mode, 'devices' as entity_name, cast (TO_UNIXTIME(CURRENT_TIMESTAMP) as bigint) as last_load_ts, 1 as completion_flag
from 
( select  last_load_ts as last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'db_l1_devices' and entity_name= 'devices' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 )
