insert into db_l2_bi.devices_diagnostic
(
    record_id 					,
    createddate 				,
    createdby 					,
    lastmodifieddate 			,
    lastmodifiedby 			,
	id                          ,
	device_codentify			,
	pack_codentify              ,
	device_product_code         ,
	product_variant_code        ,
	device_material_group       ,
	device_material_description ,
	device_model                ,
	device_color                ,
	device_version              ,
	pack_product_category       ,
	internal_id                 ,
	packaging_date_time         ,
	qure_channel				,
	diagnostic_end_date			,
	diagnostic_start_date       ,
	diagnostic_result			,
	user_id						,
	td_c360_operation			,
	td_c360_operation_time		
)

select 
	
distinct 
at.record_id				  ,
cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as createddate,
cast('Devices_diagnostic' as varchar) as createdby,
cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
cast('Devices_diagnostic' as varchar) as lastmodifiedby,
concat (cast(at.id as varchar),'-',cast(adh.id as varchar)) as id,
at.device_codentify           ,
at.pack_codentify             ,
at.device_product_code        ,
at.product_variant_code       ,
at.device_material_group      ,
at.device_material_description,
at.device_model               ,
at.device_color               ,
at.device_version             ,
at.pack_product_category      ,
at.internal_id                ,
at.packaging_date_time        ,
adh.qure_channel			  ,
adh.diagnostic_end_date		  ,
adh.diagnostic_start_date     ,
adh.diagnostic_result		  ,
adh.user_id					  ,
adh.td_c360_operation		  ,
adh.td_c360_operation_time
	   
  from 
  
  db_l1_bi_organic.asset at
  left outer join
  db_l1_bi_organic.asset_diagnostic_history adh
  on 
  at.device_codentify=adh.device_codentify 
  where at.time >  ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_devices'
												   and entity_name= 'devices' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank = 1 );