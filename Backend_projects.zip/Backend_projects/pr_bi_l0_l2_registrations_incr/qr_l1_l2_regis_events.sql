delete from  db_stg_bi.registrations_history_tmp_mrkt where time >0;
insert into   db_stg_bi.registrations_history_tmp_mrkt select * from 
 (select                    a.record_id,
                                           a.createddate ,
                                           a.createdby ,
                                           a.lastmodifieddate ,
                                           a.lastmodifiedby ,                         a.last_update_date,
                                             a.marketing_opt_in    ,
                                           a.identity_identifier                                    ,
                                           a.persona_identifier , 
										   a.has_phone, 
										   a.phone_country_code_number, 
										   a.phone_number_first_digits, 
                                           a.source_system ,
                                           a.time,
                                          ROW_NUMBER() over (PARTITION by  
                                             a.marketing_opt_in   ,
                                           a.identity_identifier--,                                    
                                          -- a.persona_identifier 
										   order by  a.last_update_date desc) rank
from db_l1_bi_organic.registrations_history a


)  where rank=1 and marketing_opt_in is not null and identity_identifier is not null
and time >   ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					)
;



delete from  db_stg_bi.registrations_history_tmp_reg_channel  where time >0;
insert into   db_stg_bi.registrations_history_tmp_reg_channel select * from 
 (select                    a.record_id,
                                           a.createddate ,
                                           a.createdby ,
                                           a.lastmodifieddate ,
                                           a.lastmodifiedby ,                         a.last_update_date,
                                              a.registration_channel_code   ,
                                           a.identity_identifier                                    ,
                                          a.persona_identifier , 
										  a.has_phone, 
										   a.phone_country_code_number, 
										   a.phone_number_first_digits, 
                                           a.source_system , 
                                           a.time,
                                          ROW_NUMBER() over (PARTITION by  
                                             a.registration_channel_code   ,
                                           a.identity_identifier
                                           --,                                    
                                           --a.persona_identifier
                                           order by  a.last_update_date desc) rank
from db_l1_bi_organic.registrations_history a 


) where rank=1 and registration_channel_code is not null and identity_identifier is not null
and time >    ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					)
;



delete from  db_stg_bi.registrations_history_tmp_db_opt where time >0;
insert into   db_stg_bi.registrations_history_tmp_db_opt select * from 
 (select                    a.record_id,
                                           a.createddate ,
                                           a.createdby ,
                                           a.lastmodifieddate ,
                                           a.lastmodifiedby ,  
                                           a.last_update_date,
                                           a.database_opt_in    ,
                                           a.identity_identifier                                    ,
                                           a.persona_identifier , 
										   a.has_phone, 
										   a.phone_country_code_number, 
										   a.phone_number_first_digits, 
                                           a.source_system , 
                                           a.time,
                                          ROW_NUMBER() over (PARTITION by  
                                             a.database_opt_in   ,
                                           a.identity_identifier--,                                    
                                           --a.persona_identifier 
										   order by  a.last_update_date desc) rank
from db_l1_bi_organic.registrations_history a


)  where rank=1 and database_opt_in is not null and identity_identifier is not null
and time >    ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					)
;




delete from  db_stg_bi.registrations_history_tmp_gbl_opt where time >0;
insert into   db_stg_bi.registrations_history_tmp_gbl_opt  select * from 
 (select                    a.record_id,
                                           a.createddate ,
                                           a.createdby ,
                                           a.lastmodifieddate ,
                                           a.lastmodifiedby , 
                                           a.last_update_date,
                                             a.global_opt_in    ,
                                           a.identity_identifier                                    ,
                                           a.persona_identifier , 
										   a.has_phone, 
										   a.phone_country_code_number, 
										   a.phone_number_first_digits , 
                                           a.source_system , 
                                           a.time,
                                          ROW_NUMBER() over (PARTITION by  
                                             a.global_opt_in   ,
                                           a.identity_identifier--,                                    
                                           --a.persona_identifier 
										   order by  a.last_update_date desc) rank
from db_l1_bi_organic.registrations_history a


)  where rank=1 and global_opt_in is not null and identity_identifier is not null
and time >    ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					)
;



insert into  db_l2_bi.registration_events
(
	Record_ID   			,
	CreatedDate		 		,
	CreatedBy				,
	LastModifiedDate  		,
	LastModifiedBy			,
	registration_event_id 	,
	last_update_date		,
	event_type				,
	event_value				,
	identity_identifier		,
	persona_identifier		, 
	has_phone, 
	phone_country_code_number, 
	phone_number_first_digits, 
	source_system 
)

select 
      a.record_id,
			a.createddate ,
			a.createdby ,
			a.lastmodifieddate ,
			a.lastmodifiedby ,
			concat(coalesce(cast (a.identity_identifier as varchar),''),'-',cast ('MARKETING_OPT_IN_UPDATE' as varchar),'-',coalesce(cast (FROM_UNIXTIME(a.last_update_date) as varchar),''),
            '-',coalesce( cast (a.marketing_opt_in as varchar),'')) as registration_event_id,
			a.last_update_date,
			cast('MARKETING_OPT_IN_UPDATE' as varchar) as event_type,
			a.marketing_opt_in    as event_value,
			a.identity_identifier			,
			a.persona_identifier			, 
			a.has_phone, 
			a.phone_country_code_number, 
			a.phone_number_first_digits, 
			a.source_system	
	from db_stg_bi.registrations_history_tmp_mrkt  a
    left outer join 
    (
	select
	    b.record_id,
			b.createddate ,
			b.createdby ,
			b.lastmodifieddate ,
			b.lastmodifiedby ,
			concat(coalesce(cast (b.identity_identifier as varchar),''),'-',cast ('MARKETING_OPT_IN_UPDATE' as varchar),'-',coalesce(cast (FROM_UNIXTIME(b.last_update_date) as varchar),''),
            '-',coalesce( cast (b.marketing_opt_in as varchar),'')) as registration_event_id,
			b.last_update_date,
			cast('MARKETING_OPT_IN_UPDATE' as varchar) as event_type,
			b.marketing_opt_in as event_value  ,
			b.identity_identifier			,
			b.persona_identifier			, 
			b.has_phone, 
			b.phone_country_code_number, 
			b.phone_number_first_digits, 
			b.source_system	
			
	from  db_l2_bi.registration_events  a,
	 db_stg_bi.registrations_history_tmp_mrkt b ,
	(select ROW_NUMBER() over (PARTITION by persona_identifier,identity_identifier,event_value,event_type, has_phone, phone_country_code_number, phone_number_first_digits order by last_update_date desc) rank,registration_event_id,time from db_l2_bi.registration_events) r
	where 
	coalesce(a.event_value 	,'na') 	=	coalesce(b.marketing_opt_in 	,'na') 
	and coalesce(a.identity_identifier 	,'na') 	=	coalesce(b.identity_identifier 	,'na') 
	and coalesce(a.has_phone,'na') 	=	coalesce(b.has_phone,'na') 
	and coalesce(a.phone_country_code_number,'na') 	=	coalesce(b.phone_country_code_number,'na') 
	and coalesce(a.phone_number_first_digits,'na') 	=	coalesce(b.phone_number_first_digits,'na') 
	--and coalesce(a.persona_identifier 	,'na') 	=	coalesce(b.persona_identifier 	,'na')
	and a.event_type='MARKETING_OPT_IN_UPDATE'
	and r.registration_event_id=a.registration_event_id and r.time=a.time
	and r.rank=1 
	) b
	on 
	 --a.persona_identifier	=	b.persona_identifier 	and 
	 a.identity_identifier  	=	b.identity_identifier
	and a.marketing_opt_in=b.event_value 
	where b.event_value  is null 
	and a.time >    ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					)


union all --REGISTRATION_CHANNEL_UPDATE



select  a.record_id,
			a.createddate ,
			a.createdby ,
			a.lastmodifieddate ,
			a.lastmodifiedby 	,
			concat(coalesce(cast (a.identity_identifier as varchar),''),'-',cast ('REGISTRATION_CHANNEL_UPDATE' as varchar),'-',coalesce(cast (FROM_UNIXTIME(a.last_update_date) as varchar),''),
            '-',coalesce( cast (a.registration_channel_code as varchar),'')) as registration_event_id	,
			a.last_update_date,
			cast('REGISTRATION_CHANNEL_UPDATE' as varchar) as event_type,
			a.registration_channel_code    as event_value,
			a.identity_identifier			,
			a.persona_identifier			, 
			a.has_phone,  
			a.phone_country_code_number, 
			a.phone_number_first_digits, 
			a.source_system	
	from db_stg_bi.registrations_history_tmp_reg_channel  a
    left outer join 
    (
	select
	    b.record_id,
			b.createddate ,
			b.createdby ,
			b.lastmodifieddate ,
			b.lastmodifiedby ,
			concat(coalesce(cast (b.identity_identifier as varchar),''),'-',cast ('REGISTRATION_CHANNEL_UPDATE' as varchar),'-',coalesce(cast (FROM_UNIXTIME(b.last_update_date) as varchar),''),
            '-',coalesce( cast (b.registration_channel_code as varchar),'')) as registration_event_id	,
			b.last_update_date,
			cast('REGISTRATION_CHANNEL_UPDATE' as varchar) as event_type,
			b.registration_channel_code as event_value  ,
			b.identity_identifier			,
			b.persona_identifier			, 
			b.has_phone,  
			b.phone_country_code_number, 
			b.phone_number_first_digits, 
			b.source_system	
			
	from  db_l2_bi.registration_events  a,
	 db_stg_bi.registrations_history_tmp_reg_channel b ,
	(select ROW_NUMBER() over (PARTITION by persona_identifier,identity_identifier,event_value,event_type, has_phone, phone_country_code_number, phone_number_first_digits order by last_update_date desc) rank,registration_event_id,time from db_l2_bi.registration_events) r
	where 
	coalesce(a.event_value 	,'na') 	=	coalesce(b.registration_channel_code 	,'na') 
	and coalesce(a.identity_identifier 	,'na') 	=	coalesce(b.identity_identifier 	,'na') 
	and coalesce(a.has_phone,'na') 	=	coalesce(b.has_phone,'na') 
	and coalesce(a.phone_country_code_number,'na') 	=	coalesce(b.phone_country_code_number,'na') 
	and coalesce(a.phone_number_first_digits,'na') 	=	coalesce(b.phone_number_first_digits,'na') 
--	and coalesce(a.persona_identifier 	,'na') 	=	coalesce(b.persona_identifier 	,'na')
	and a.event_type='REGISTRATION_CHANNEL_UPDATE'
	and r.registration_event_id=a.registration_event_id and r.time=a.time
	and r.rank=1 
	) b
	on 
--	 a.persona_identifier	=	b.persona_identifier 	and 
	 a.identity_identifier  	=	b.identity_identifier
	and a.registration_channel_code = b.event_value 
	where b.event_value  is null 	and a.time >    ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					)
	
	

union all --GLOBAL_OPT_IN_UPDATE



select 
      a.record_id,
			a.createddate ,
			a.createdby ,
			a.lastmodifieddate ,
			a.lastmodifiedby ,
			concat(coalesce(cast (a.identity_identifier as varchar),''),'-',cast ('GLOBAL_OPT_IN_UPDATE' as varchar),'-',coalesce(cast (FROM_UNIXTIME(a.last_update_date) as varchar),''),
            '-',coalesce( cast (a.global_opt_in as varchar),'')) as registration_event_id ,
			a.last_update_date,
			cast('GLOBAL_OPT_IN_UPDATE' as varchar) as event_type,
			a.global_opt_in    as event_value,
			a.identity_identifier			,
			a.persona_identifier			, 
			a.has_phone,  
			a.phone_country_code_number, 
			a.phone_number_first_digits, 
			a.source_system	
	from db_stg_bi.registrations_history_tmp_gbl_opt a
    left outer join 
    (
	select
	    b.record_id,
			b.createddate ,
			b.createdby ,
			b.lastmodifieddate ,
			b.lastmodifiedby ,
			concat(coalesce(cast (b.identity_identifier as varchar),''),'-',cast ('GLOBAL_OPT_IN_UPDATE' as varchar),'-',coalesce(cast (FROM_UNIXTIME(b.last_update_date) as varchar),''),
            '-',coalesce( cast (b.global_opt_in as varchar),'')) as registration_event_id ,
			b.last_update_date,
			cast('GLOBAL_OPT_IN_UPDATE' as varchar) as event_type,
			b.global_opt_in as event_value  ,
			b.identity_identifier			,
			b.persona_identifier			, 
			b.has_phone,  
			b.phone_country_code_number, 
			b.phone_number_first_digits, 
			b.source_system	
			
	from  db_l2_bi.registration_events  a,
	db_stg_bi.registrations_history_tmp_gbl_opt b ,
	(select ROW_NUMBER() over (PARTITION by --persona_identifier,
	identity_identifier, event_value, has_phone, phone_country_code_number, phone_number_first_digits order by time,registration_event_id desc) rank,time ,registration_event_id from db_l2_bi.registration_events) r
	where
	coalesce(a.event_value 	,'na') 	=	coalesce(b.global_opt_in 	,'na') 
	and coalesce(a.identity_identifier 	,'na') 	=	coalesce(b.identity_identifier 	,'na') 
	and coalesce(a.has_phone,'na') 	=	coalesce(b.has_phone,'na') 
	and coalesce(a.phone_country_code_number,'na') 	=	coalesce(b.phone_country_code_number,'na')
	and coalesce(a.phone_number_first_digits,'na') 	=	coalesce(b.phone_number_first_digits,'na') 	
--	and coalesce(a.persona_identifier 	,'na') 	=	coalesce(b.persona_identifier 	,'na')
	
	and a.event_type='GLOBAL_OPT_IN_UPDATE'
	and r.registration_event_id = a.registration_event_id and r.time = a.time 
	and r.rank=1 
	) b
	on 
	 --a.persona_identifier	=	b.persona_identifier 	and 
	 a.identity_identifier  	=	b.identity_identifier
	and a.global_opt_in = b.event_value 

	where b.event_value  is null 	and a.time >    ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					)
	
	

union all --DATABASE_OPT_IN_UPDATE


 select a.record_id,
			a.createddate ,
			a.createdby ,
			a.lastmodifieddate ,
			a.lastmodifiedby ,
			concat(coalesce(cast (a.identity_identifier as varchar),''),'-',cast ('DATABASE_OPT_IN_UPDATE' as varchar),'-',coalesce(cast (FROM_UNIXTIME(a.last_update_date) as varchar),''),
            '-',coalesce( cast (a.database_opt_in as varchar),'')) as registration_event_id ,
			a.last_update_date,
			cast('DATABASE_OPT_IN_UPDATE' as varchar) as event_type,
			a.database_opt_in    as event_value,
			a.identity_identifier			,
			a.persona_identifier			, 
			a.has_phone,  
			a.phone_country_code_number, 
			a.phone_number_first_digits, 
			a.source_system	
	from db_stg_bi.registrations_history_tmp_db_opt a
    left outer join 
    (
	select
	    b.record_id,
			b.createddate ,
			b.createdby ,
			b.lastmodifieddate ,
			b.lastmodifiedby ,
			concat(coalesce(cast (b.identity_identifier as varchar),''),'-',cast ('DATABASE_OPT_IN_UPDATE' as varchar),'-',coalesce(cast (FROM_UNIXTIME(b.last_update_date) as varchar),''),
            '-',coalesce( cast (b.database_opt_in as varchar),'')) as registration_event_id ,
			b.last_update_date,
			cast('DATABASE_OPT_IN_UPDATE' as varchar) as event_type,
			b.database_opt_in as event_value  ,
			b.identity_identifier			,
			b.persona_identifier			, 
			b.has_phone,  
			b.phone_country_code_number, 
			b.phone_number_first_digits, 
			b.source_system	
			
	from  db_l2_bi.registration_events  a,
	 db_stg_bi.registrations_history_tmp_db_opt b ,
	(select ROW_NUMBER() over (PARTITION by --persona_identifier	, 
	identity_identifier, event_value, has_phone, phone_country_code_number, phone_number_first_digits order by time desc) rank,time,registration_event_id from db_l2_bi.registration_events) r
	where
	coalesce(a.event_value 	,'na') 	=	coalesce(b.database_opt_in 	,'na') 
	and coalesce(a.identity_identifier 	,'na') 	=	coalesce(b.identity_identifier 	,'na') 
	and coalesce(a.has_phone,'na') 	=	coalesce(b.has_phone,'na') 
	and coalesce(a.phone_country_code_number,'na') 	=	coalesce(b.phone_country_code_number,'na') 
	and coalesce(a.phone_number_first_digits,'na') 	=	coalesce(b.phone_number_first_digits,'na') 
	--and coalesce(a.persona_identifier 	,'na') 	=	coalesce(b.persona_identifier 	,'na')
	and a.event_type='DATABASE_OPT_IN_UPDATE'
	and r.registration_event_id=a.registration_event_id and r.time=a.time
	and r.rank=1 
	) b
	on 
	 --a.persona_identifier	=	b.persona_identifier	and 
	 a.identity_identifier  	=	b.identity_identifier
	and a.database_opt_in=b.event_value
	where b.event_value  is null 

and a.time >   ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1
					)
;