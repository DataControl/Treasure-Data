insert into  db_l1_bi_organic.registrations_history 
	(
	record_Id,
    createddate ,
    createdby ,
    lastmodifieddate ,
    lastmodifiedby ,
	registration_identity_key	,
	registration_id				,
	persona_identifier			,
	identity_identifier			,
	home_country_code			,
	registration_date			,
	registration_country_code	,
	registration_channel_code	,
	marketing_opt_in			,
	global_opt_in				,
	database_opt_in				,
	has_phone, 
	phone_country_code_number, 
	phone_number_first_digits , 
	last_update_date			,
	last_update_date_bi			,
	source_system				,
	time
	)
	
	select 
	rec_id.max_id + cast(row_number() over (order by b.time) as bigint) as 	record_Id,
	a.createddate ,
	a.createdby ,
    a.lastmodifieddate ,
    a.lastmodifiedby ,
	a.registration_identity_key	,
	a.registration_id				,
	a.persona_identifier			,
	a.identity_identifier			,
	a.home_country_code			,
	a.registration_date			,
	a.registration_country_code	,
	a.registration_channel_code	,
	a.marketing_opt_in			,
	a.global_opt_in				,
	a.database_opt_in				,
	a.has_phone, 
	a.phone_country_code_number, 
	a.phone_number_first_digits ,
	a.last_update_date			,
	a.last_update_date_bi			,
	a.source_system		,
	a.time
	from db_stg_bi.registrations_history  a
    left outer join 
    (
	select
    b.createddate ,
    b.createdby ,
    b.lastmodifieddate ,
    b.lastmodifiedby ,
	b.registration_identity_key	,
	b.registration_id				,
	b.persona_identifier			,
	b.identity_identifier			,
	b.home_country_code			,
	b.registration_date			,
	b.registration_country_code	,
	b.registration_channel_code	,
	b.marketing_opt_in			,
	b.global_opt_in				,
	b.database_opt_in				,
	b.has_phone, 
	b.phone_country_code_number, 
	b.phone_number_first_digits , 
	b.last_update_date			,
	b.last_update_date_bi			,
	b.source_system		,
	b.time
	from db_l1_bi_organic.registrations_history  a, 
	 db_stg_bi.registrations_history b ,
	(select ROW_NUMBER() over (PARTITION by registration_identity_key order by time desc) rank,registration_identity_key,time from db_l1_bi_organic.registrations_history) r
	where
	a.registration_identity_key  	=	b.registration_identity_key 
	and a.registration_identity_key  	=	r.registration_identity_key 
	and 
	r.rank=1 and a.time=r.time) b
	on a.registration_identity_key  	=	b.registration_identity_key,										
	(select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_organic.registrations_history) rec_id
	where b.registration_identity_key  is null 
	and a.time >    ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1); 