delete from db_stg_bi.registrations_history where time >0;

insert into  db_stg_bi.registrations_history 
	(
   
    createddate ,
    createdby ,
    lastmodifieddate ,
    lastmodifiedby ,
	registration_identity_key	,
	registration_id				,
	persona_identifier			,
	identity_identifier			,
	home_country_code			,
	registration_date			,
	registration_country_code	,
	registration_channel_code	,
	marketing_opt_in			,
--	global_opt_in				,
	database_opt_in				,
	has_phone, 
	phone_country_code_number , 
	phone_number_first_digits , 
	last_update_date			,
	last_update_date_bi			,
	source_system		
	)

select
	
   
   createddate ,
   createdby ,
   lastmodifieddate ,
   lastmodifiedby ,
	registration_identity_key	,
	registration_id				,
	persona_identifier			,
	identity_unique_identifier			,
	home_country_code			,
	registration_date			,
	registration_country_code	,
	registration_channel_code	,
	marketing_opt_in			,
	--global_opt_in				,
	database_opt_in				,
	has_phone, 
	phone_country_code_number , 
	phone_number_first_digits , 
	last_update_date			,
	last_update_date_bi			,
	source_system	
   
from (   
	
	select
	
   
    src.createddate ,
    src.createdby ,
    src.lastmodifieddate ,
    src.lastmodifiedby ,
	src.registration_identity_key	,
	src.registration_id				,
	src.persona_identifier			,
	src.identity_unique_identifier			,
	src.home_country_code			,
	src.registration_date			,
	src.registration_country_code	,
	src.registration_channel_code	,
	src.marketing_opt_in			,
--	src.global_opt_in				,
	src.database_opt_in				, 
	src.has_phone	, 
	src.phone_country_code_number , 
	src.phone_number_first_digits , 
	src.last_update_date			,
	src.last_update_date_bi			,
	src.source_system				,
	src.time
   ,row_number() over (partition by 
   src.registration_identity_key  order by src.time desc) as rank
   
	from (



	
select 
	
    cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as createddate,
	'DCE20'  as createdby,
	cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	'DCE20'  as lastmodifiedby,
	concat (coalesce(cast(l0.identity_unique_identifier as varchar), ''),
	'-',coalesce(cast(l0.registration_date as varchar), '') ,
	'-',coalesce(cast(l0.marketing_opt_in  as varchar), ''),
	--'-',coalesce(cast(l0.global_opt_in  as varchar), ''),
	'-',coalesce(cast(l0.database_opt_in  as varchar), ''),
	'-',coalesce(cast(l0.last_update_date  as varchar), '')) as  registration_identity_key	,
	l0.registration_id				,
	cast (NULL as varchar) as persona_identifier			,
	l0.identity_unique_identifier			,
	l0.home_country_code			,
	l0.registration_date			,
	l0.registration_country_code	,
	l0.registration_channel_code	,
	l0.marketing_opt_in			,
	--l0.global_opt_in				, 
	l0.database_opt_in				, 
	case when l0.phone_number is not null then 'Y' when l0.phone_number is null then 'N' end as has_phone, 
   case when l0.phone_number is not null then l0.phone_country_code_number when l0.phone_number is null then 'N/A' end as phone_country_code_number,  
   case when l0.phone_number is not null then substring(l0.phone_number, 1, 3) when l0.phone_number is null then 'N/A' end as phone_number_first_digits, 
	l0.last_update_date			,
	cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as  last_update_date_bi			,
	cast ('DCE20' as varchar) as source_system		,
	cast(substr(cast(l0.td_c360_operation_time as VARCHAR),1,10)as BIGINT) as time
    
			from   db_l0_organic.identities l0	
			
			where cast(substr(cast( td_c360_operation_time as VARCHAR),1,10)as BIGINT)  >     ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l1_registrations'
												   and entity_name= 'registrations' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) where rank=1)
			
	) src
	
	) 

where rank=1;