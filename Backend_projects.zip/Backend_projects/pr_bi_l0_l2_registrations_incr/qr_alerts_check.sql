select count(*) as result, (select 
    SUBSTR(email,5,3) as env
from db_bi_monitoring.workflow_alerts
    where email like 'env%') as env, SPLIT_PART('${task_name}','^',1) as  task_name1 
from db_bi_monitoring.workflow_alerts
    where email = 'check:YES';