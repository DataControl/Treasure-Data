delete from db_stg_bi_technical.stg_scheduling where dependencies = 'wf_client_telling_Incremental';
insert into db_stg_bi_technical.stg_scheduling select 'wf_db_l3_bi_data_marts_cl' as object, 'wf_client_telling_Incremental' as dependencies, 1 as load_flag;
