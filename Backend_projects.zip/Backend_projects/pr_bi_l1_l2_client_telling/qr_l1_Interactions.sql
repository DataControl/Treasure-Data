delete  from  db_l1_bi_organic.interactions_temp where time>0;

insert into db_l1_bi_organic.interactions_temp
(

createddate                     ,
createdby                       ,
lastmodifieddate                ,
lastmodifiedby                  ,
interaction_id                  ,
identity_unique_identifier      ,
product_id                      ,
interaction_type_refcode        ,
coach_id                        ,
session_id                      ,
appointment_id                  ,
campaign_id                     ,
agent_id                        ,
retailer_id                     ,
event_id                        ,
friend_id                       ,
device_id                       ,
order_id                        ,
case_id                         ,
state_id                        ,
location_id                     ,
country_refcode                 ,
market_refcode                  ,
channel_refcode                 ,
location_type_refcode           ,
reason_refcode                  ,
flavours                        ,
date_time                       ,
device_version                  ,
location_description            ,
question                        ,
answer                          ,
ip_address                      
)

select 

createddate,
createdby,
lastmodifieddate,
lastmodifiedby,
interaction_id                  ,
identity_unique_identifier      ,
product_id                      ,
interaction_type_refcode        ,
coach_id                        ,
session_id                      ,
appointment_id                  ,
campaign_id                     ,
agent_id                        ,
retailer_id                     ,
event_id                        ,
friend_id                       ,
device_id                       ,
order_id                        ,
case_id                         ,
state_id                        ,
location_id                     ,
country_refcode                 ,
market_refcode                  ,
channel_refcode                 ,
location_type_refcode           ,
reason_refcode                  ,
flavours                        ,
date_time                       ,
device_version             ,
location_description            ,
question,
answer,
ip_address

from
(
		select
		
		src.createddate,
		src.createdby,
		src.lastmodifieddate,
		src.lastmodifiedby,
		src.interaction_id                  ,
		src.identity_unique_identifier      ,
		src.product_id                      ,
		src.interaction_type_refcode        ,
		src.coach_id                        ,
		src.session_id                      ,
		src.appointment_id                  ,
		src.campaign_id                     ,
		src.agent_id                        ,
		src.retailer_id                     ,
		src.event_id                        ,
		src.friend_id                       ,
		src.device_id                       ,
		src.order_id                        ,
		src.case_id                         ,
		src.state_id                        ,
		src.location_id                     ,
		src.country_refcode                 ,
		src.market_refcode                  ,
		src.channel_refcode                 ,
		src.location_type_refcode           ,
		src.reason_refcode                  ,
		src.flavours                        ,
		src.date_time                       ,
		src.device_version             ,
		src.location_description            ,
		src.question,
		src.answer,
		src.ip_address              ,
		row_number() over (partition by 
		   src.interaction_id  order by src.td_c360_operation_time desc) as rank
		
		from
		(
			select 
			
				cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as createddate,
				'ClientTelling_Interactions' as createdby,
				cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
				'ClientTelling_Interactions' as lastmodifiedby,
				
				i.interaction_id                  ,
				i.identity_unique_identifier      ,
				i.product_id                      ,
				i.interaction_type_refcode        ,
				i.coach_id                        ,
				i.session_id                      ,
				i.appointment_id                  ,
				i.campaign_id                     ,
				i.agent_id                        ,
				i.retailer_id                     ,
				i.event_id                        ,
				i.friend_id                       ,
				i.device_id                       ,
				i.order_id                        ,
				i.case_id                         ,
				i.state_id                        ,
				i.location_id                     ,
				i.country_refcode                 ,
				i.market_refcode                  ,
				i.channel_refcode                 ,
				i.location_type_refcode           ,
				i.reason_refcode                  ,
				cast(null as varchar) as flavours                        ,
				i.date_time                       ,
				i.device_version             ,
				i.location_description            ,
				cast(null as varchar) as question,
				cast(null as varchar) as answer,
				i.ip_address  ,
				i.td_c360_operation_time as td_c360_operation_time
					
			from db_l0_organic.interactions i
			where cast(substr(cast(i.td_c360_operation_time as VARCHAR),1,10)as BIGINT) >  ( select last_load_ts
												from (
														select last_load_ts, 
															ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
															from db_stg_bi_technical.delta_load_log_dce 
															where layer = 'db_l1_bi_client_telling'
															and entity_name= 'bi_client_telling_load' 
															and operation_mode = 'insert' 
															and completion_flag = 0 order by time desc 
														) 
								where rank = 1 )
		) src
		
) where rank=1;



					
delete from db_l1_bi_organic.interactions where interaction_id in (select interaction_id from  db_l1_bi_organic.interactions_temp);


insert into db_l1_bi_organic.interactions
	(
		record_id						,
		createddate                     ,
		createdby                       ,
		lastmodifieddate                ,
		lastmodifiedby                  ,
		interaction_id                  ,
		identity_unique_identifier      ,
		product_id                      ,
		interaction_type_refcode        ,
		coach_id                        ,
		session_id                      ,
		appointment_id                  ,
		campaign_id                     ,
		agent_id                        ,
		retailer_id                     ,
		event_id                        ,
		friend_id                       ,
		device_id                       ,
		order_id                        ,
		case_id                         ,
		state_id                        ,
		location_id                     ,
		country_refcode                 ,
		market_refcode                  ,
		channel_refcode                 ,
		location_type_refcode           ,
		reason_refcode                  ,
		flavours                        ,
		date_time                       ,
		device_version                  ,
		location_description            ,
		question                        ,
		answer                          ,
		ip_address 
	)
	
	select 
	rec_id.max_id + cast(row_number() over (order by i.time) as bigint) as	record_id, 
	cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as createddate,
	'ClientTelling_Interactions' as createdby,
	cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	'ClientTelling_Interactions' as lastmodifiedby,
	
	i.interaction_id                  ,
	i.identity_unique_identifier      ,
	i.product_id                      ,
	i.interaction_type_refcode        ,
	i.coach_id                        ,
	i.session_id                      ,
	i.appointment_id                  ,
	i.campaign_id                     ,
	i.agent_id                        ,
	i.retailer_id                     ,
	i.event_id                        ,
	i.friend_id                       ,
	i.device_id                       ,
	i.order_id                        ,
	i.case_id                         ,
	i.state_id                        ,
	i.location_id                     ,
	i.country_refcode                 ,
	i.market_refcode                  ,
	i.channel_refcode                 ,
	i.location_type_refcode           ,
	i.reason_refcode                  ,
	i.flavours                       ,
	i.date_time                       ,
	i.device_version             ,
	i.location_description            ,
	i.question                        ,
	i.answer                          ,
	i.ip_address
    from db_l1_bi_organic.interactions_temp i	
         
	left outer join 
          
	(
    select 
	cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as createddate,
	'ClientTelling_Interactions' as createdby,
	cast (TO_UNIXTIME(CAST( CURRENT_TIMESTAMP AS TIMESTAMP)) AS BIGINT) as lastmodifieddate,
	'ClientTelling_Interactions' as lastmodifiedby,
	
	b.interaction_id                  ,
	b.identity_unique_identifier      ,
	b.product_id                      ,
	b.interaction_type_refcode        ,
	b.coach_id                        ,
	b.session_id                      ,
	b.appointment_id                  ,
	b.campaign_id                     ,
	b.agent_id                        ,
	b.retailer_id                     ,
	b.event_id                        ,
	b.friend_id                       ,
	b.device_id                       ,
	b.order_id                        ,
	b.case_id                         ,
	b.state_id                        ,
	b.location_id                     ,
	b.country_refcode                 ,
	b.market_refcode                  ,
	b.channel_refcode                 ,
	b.location_type_refcode           ,
	b.reason_refcode                  ,
	b.flavours                       ,
	b.date_time                       ,
	b.device_version             ,
	b.location_description            ,
	b.question                        ,
	b.answer                          ,
	b.ip_address                      
		   
	from db_l1_bi_organic.interactions i, 
	db_l1_bi_organic.interactions_temp b ,
	(select ROW_NUMBER() over (PARTITION by interaction_id order by lastmodifieddate desc) rank,interaction_id from db_l1_bi_organic.interactions) r
	where
	i.interaction_id 	=	b.interaction_id
	and i.interaction_id = r.interaction_id
	and r.rank=1 
	) b
	on i.interaction_id = b.interaction_id ,										
	(select  COALESCE (cast(max(record_Id) as bigint),0) max_id from db_l1_bi_organic.interactions) rec_id
	where b.interaction_id  is null and i.interaction_id is not null;