delete from db_stg_current_record_dcs_bi.products_dce1 where time > 0;

insert into db_stg_current_record_dcs_bi.products_dce1 
select distinct 
a.created_date,
a.created_by,
a.last_modified_date, 
a.last_modified_by, 
a.product_id_product_code_key, 
a.product_id,
a.market,
a.product_type,
a.product_variant,
a.product_description,
a.products,
a.unit_price, 
a.unit_per_order, 
a.currency,
a.product_code, 
a.source_system, 
a.updated , 
a.last_modified, 
a.time 
from 
(
select 
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') created_date,
cast('dce1.0' as varchar) as  created_by,
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') last_modified_date, 
cast('dce1.0' as varchar) as last_modified_by, 
'DCE_' || o.item_id || substr(o.product_id, 0, 11) as product_id_product_code_key, 
'DCE_' || o.item_id as product_id, 
h.country as market, 
o.c_orderitemtype as product_type, 
o.c_variantcolor as product_variant, 
o.product_name as product_description, 
Null as products, 
cast(o.price as double) as unit_price, 
'1' as unit_per_order, 
h.currency, 
substr(o.product_id, 0, 11) as product_code, 
cast('DCE1.0' as varchar) as source_system,
Null as updated, 
o.last_modified, 
o.time, 
rank() over (partition by o.item_id, o.c_orderitemtype, o.c_variantcolor, o.product_name, o.price, h.country, h.currency order by o.last_modified, o.time desc) r 

from db_pstg_migration.dce_order_item o 
left outer join db_pstg_migration.dce_order_header h on o.order_no = h.order_no 
where   
		o.time > 
		( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ) 
  ) a 
where  
r = 1;