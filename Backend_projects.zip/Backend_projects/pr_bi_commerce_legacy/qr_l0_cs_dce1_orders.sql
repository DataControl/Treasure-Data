delete from db_stg_current_record_dcs_bi.order_dce1 where time > 0;

insert into db_stg_current_record_dcs_bi.order_dce1    
select distinct 
a.created_date,
a.created_by,
a.last_modified_date, 
a.last_modified_by, 
a.order_id, 
a.order_created_date, 
a.order_payment_date, 
a.market, 
a.persona_id,  
a.identity_identifier, 
a.order_channel_legacy,   -----
a.order_channel, 
a.order_type_legacy,     ----
a.order_type,  
a.order_status_legacy,   ----
a.order_status, 
a.order_value_local_currency, 
a.order_currency_legacy,   -----
a.order_currency, 
a.order_reason, 
a.shipping_method, 
a.shipping_status, 
a.shipment_address_city, 
a.shipment_shipping_address_postal_code, 
a.delivery_date_timestamp, 
a.payment_status, 
a.payment_method, 
a.updated, 
a.last_modified, 
a.source_system, 
a.time 

from 
(
select 
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') created_date,
cast('dce1.0' as varchar) as  created_by,
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') last_modified_date, 
cast('dce1.0' as varchar) as last_modified_by, 
o.order_no as order_id, 
o.creation_date as order_created_date, 
0 as order_payment_date, 
o.country as market, 
o.c_spiceid as persona_id,   ----- o.customer_info_customer_id
Null as identity_identifier, 
o.c_channel as order_channel_legacy,
o.c_channel as order_channel, 
o.c_ordertype as order_type_legacy,
o.c_ordertype as order_type,  
o.status as order_status_legacy, 
o.status as order_status, 
cast(o.order_total as double) as order_value_local_currency, 
o.currency as order_currency_legacy, 
o.currency as order_currency, 
o.c_orderreason as order_reason, 
s.shipping_method_name as shipping_method, 
o.shipping_status as shipping_status, 
s.shipping_address_city as shipment_address_city, 
s.shipping_address_postal_code as shipment_shipping_address_postal_code, 
0  as delivery_date_timestamp, 
o.payment_status , 
'N/A' as payment_method, 
'N/A' as updated, 
o.last_modified, 
cast('DCE1.0' as varchar) as source_system, 
o.time, 
rank() over (partition by o.order_no, o.creation_date, o.country, o.c_spiceid, o.c_channel, o.c_ordertype, o.status, o.order_total, o.currency, o.c_orderreason, o.shipping_status, o.payment_status, o.last_modified, s.shipping_method_name, s.shipping_address_city, s.shipping_address_postal_code order by o.last_modified, o.time desc) r 

from db_pstg_migration.dce_order_header o 
left outer join db_pstg_migration.dce_shipment s on o.order_no = s.order_no 
-- left outer join db_stg_parsing_dce.payment_instrument_dw p on o.order_no = p.order_no 
where   
		o.time > 
		( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ) 
  ) a 
where  
r = 1;