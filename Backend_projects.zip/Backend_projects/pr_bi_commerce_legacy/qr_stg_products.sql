delete from db_stg_bi.products_legacy_dcs_dce where time > 0; 

insert into db_stg_bi.products_legacy_dcs_dce ( 
created_date,
created_by,
last_modified_date, 
last_modified_by, 
product_id_product_code_key, 
product_id,
market,
product_type,
product_variant,
product_description,
products,
unit_price, 
unit_per_order, 
currency,
product_code, 
source_system, 
updated , 
last_modified, 
time ) 

--##dce1.0-orders
select distinct  
d.created_date,
d.created_by,
d.last_modified_date, 
d.last_modified_by, 
d.product_id_product_code_key, 
d.product_id,
d.market,
d.product_type,
d.product_variant,
d.product_description,
d.products,
d.unit_price, 
d.unit_per_order, 
d.currency,
d.product_code, 
d.source_system, 
d.updated , 
d.last_modified, 
d.time   

from  db_stg_current_record_dcs_bi.products_dce1 d 
				where time >  ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
			  where rank = 1 )      
union 

--##dcs-orders 
select distinct 
t.created_date,
t.created_by,
t.last_modified_date, 
t.last_modified_by, 
t.product_id_product_code_key, 
t.product_id,
t.market,
t.product_type,
t.product_variant,
t.product_description,
t.products,
t.unit_price, 
t.unit_per_order, 
coalesce(orders_mapping.target_code, t.currency) as currency, 
t.product_code, 
t.source_system, 
t.updated , 
t.last_modified, 
t.time   

from (
select 
o.created_date,
o.created_by,
o.last_modified_date, 
o.last_modified_by, 
o.product_id_product_code_key, 
o.product_id,
o.market,
o.product_type,
o.product_variant,
o.product_description,
o.products,
o.unit_price, 
o.unit_per_order, 
o.currency,
o.product_code, 
o.source_system, 
o.updated , 
o.last_modified, 
o.time 
from db_stg_current_record_dcs_bi.products_dcs o 
				
				where time >  ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
			  where rank = 1 ) 
			) t  
left outer join db_stg_bi_technical.reference_data_mapping orders_mapping 
	on orders_mapping.field_name = 'order_currency' and trim(upper(t.market)) = trim(upper(orders_mapping.legacy_code)) and trim(upper(t.market)) = trim(upper(orders_mapping.ref_data_country)) and (trim(t.created_by)) = (trim(orders_mapping.source));  