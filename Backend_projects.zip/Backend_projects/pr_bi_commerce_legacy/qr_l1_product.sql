delete from db_l1_bi_commerce.products where time >0;

insert into db_l1_bi_commerce.products ( 
record_id,
created_date,
created_by,
last_modified_date, 
last_modified_by, 
product_id_product_code_key, 
product_id,
market,
product_type,
product_variant,
product_description,
products,
unit_price, 
unit_per_order, 
currency,
product_code, 
source_system, 
updated , 
last_modified, 
time 
) 
select  
rec_id.max_id + cast(row_number() over (order by b.time) as bigint) as	record_Id,
a.created_date,
a.created_by,
a.last_modified_date, 
a.last_modified_by, 
a.product_id_product_code_key, 
a.product_id,
a.market,
a.product_type,
a.product_variant,
a.product_description,
a.products,
a.unit_price, 
a.unit_per_order, 
a.currency,
a.product_code, 
a.source_system, 
a.updated , 
a.last_modified, 
a.time 

from db_stg_bi.products_legacy_dcs_dce  a 
 left outer join 
(
select 
d.created_date,
d.created_by,
d.last_modified_date, 
d.last_modified_by, 
d.product_id_product_code_key, 
d.product_id,
d.market,
d.product_type,
d.product_variant,
d.product_description,
d.products,
d.unit_price, 
d.unit_per_order, 
d.currency,
d.product_code, 
d.source_system, 
d.updated , 
d.last_modified, 
d.time 

from  db_l1_bi_commerce.products  c, 
db_stg_bi.products_legacy_dcs_dce  d,
(select ROW_NUMBER() over (PARTITION by product_id, market, product_variant, product_description, products order by time desc) rank, product_id, market, product_variant, product_description, products, time  from db_l1_bi_commerce.products) r 
where 
coalesce(c.created_date,0) = coalesce( d.created_date,0)  and 
coalesce(c.created_by,'na') = coalesce( d.created_by,'na')  and 
coalesce(c.last_modified_date, 0) = coalesce( d.last_modified_date,0)  and 
coalesce(c.last_modified_by,'na') = coalesce( d.last_modified_by,'na')  and 
coalesce(c.product_id_product_code_key,'na') = coalesce( d.product_id_product_code_key,'na')  and 
coalesce(c.product_id,'na') = coalesce( d.product_id,'na')  and 
coalesce(c.market,'na') = coalesce( d.market,'na')  and 
-- coalesce(c.product_type,'na') = coalesce( d.product_type,'na')  and 
coalesce(c.product_variant,'na') = coalesce( d.product_variant,'na')  and 
coalesce(c.product_description,'na') = coalesce( d.product_description,'na')  and 
coalesce(c.products,'na') = coalesce( d.products,'na')  and 
coalesce(c.unit_price, 0.00) = coalesce( d.unit_price, 0.00)  and 
coalesce(c.unit_per_order,'na') = coalesce( d.unit_per_order,'na')  and 
coalesce(c.currency,'na') = coalesce( d.currency,'na')  and 
coalesce(c.product_code,'na') = coalesce( d.product_code,'na')  and 
coalesce(c.source_system,'na') = coalesce( d.source_system,'na')  and 
coalesce(c.updated,'na') = coalesce( d.updated,'na')  and 
coalesce(c.last_modified, 0) = coalesce( d.last_modified, 0)  and 
c.product_id = r.product_id and 
c.time = r.time and 
r.rank=1 ) b 
on a.product_id = b.product_id,  
(select  COALESCE(cast(max(record_id) as bigint),0) max_id from db_l1_bi_commerce.products) rec_id
where b.product_id is null and 
a.time >
  ( select last_load_ts
   from (
 select last_load_ts, 
 ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
 from db_stg_bi_technical.delta_load_log_dce 
 where layer = 'bi_legacy_ecommerce'
 and entity_name= 'ecommerce_legacy' 
 and operation_mode = 'insert' 
 and completion_flag = 0 order by time desc 
	) 
	where rank = 1 );