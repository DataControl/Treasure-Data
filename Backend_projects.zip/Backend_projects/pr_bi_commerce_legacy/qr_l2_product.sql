delete from db_l2_bi.products where time > 0;

insert into db_l2_bi.products ( 
record_id,
created_date,
created_by,
last_modified_date, 
last_modified_by, 
product_id_product_code_key, 
product_id,
market,
product_type,
product_variant,
product_description,
products,
unit_price, 
unit_per_order, 
currency,
product_code, 
updated , 
last_modified, 
time 
) 
select 
d.record_id, 
d.created_date,
d.created_by,
d.last_modified_date, 
d.last_modified_by, 
d.product_id_product_code_key, 
d.product_id,
d.market,
d.product_type,
d.product_variant,
d.product_description,
d.products,
d.unit_price, 
d.unit_per_order, 
d.currency,
d.product_code, 
d.updated , 
d.last_modified, 
d.time 

from  db_l1_bi_commerce.products_legacy_dcs_dce d;