delete from db_stg_current_record_dcs_bi.order_dcs where time > 0;

insert into db_stg_current_record_dcs_bi.order_dcs 
select distinct 
a.created_date,
a.created_by,
a.last_modified_date, 
a.last_modified_by, 
a.order_id, 
a.order_created_date, 
a.order_payment_date, 
a.market, 
a.persona_id,  
a.identity_identifier, 
a.order_channel_legacy,  ----
a.order_channel, 
-- a.order_subchannel, 
a.order_type_legacy,     ----
a.order_type,  
a.status, 
a.order_status_legacy,   ----
a.order_status, 
a.total, 
a.subtotal, 
a.order_value_local_currency, 
a.order_currency_legacy,   -----
a.order_currency, 
a.order_reason, 
a.shipping_method, 
a.shipping_status, 
a.shipment_address_city, ----
a.shipment_shipping_address_postal_code, ---- 
a.delivery_date_timestamp, 
a.payment_status, 
a.payment_method, 
a.updated, 
--  a.discount, 
a.last_modified, 
a.source_system, 
a.time 

from 
( 
select 
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') created_date,
cast('dcs' as varchar) as  created_by,
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') last_modified_date, 
cast('dcs' as varchar) as last_modified_by, 
o.order_id, 
o.created as order_created_date, 
0 as order_payment_date, 
o.country as market, 
o.user_id as persona_id, 
Null as identity_identifier,   ------
o.order_channel as order_channel_legacy,    -----
o.order_channel, 
o.order_type as order_type_legacy, 
o.order_type,  
o.status, 
o.status as order_status_legacy,   ------
o.status as order_status, 
cast(o.total as double) as total, 
cast(o.subtotal as double) as subtotal,  
least(cast(o.total as double), cast(o.subtotal as double)) as order_value_local_currency, 
Null as order_currency_legacy,   ------
Null as order_currency, 
o.order_reason, 
o.shipping as shipping_method, 
Null as shipping_status, 
o.s_zipcode as shipment_address_city, 
o.s_city as shipment_shipping_address_postal_code, 
--- CASE WHEN o.status_description ='Delivered' THEN CAST(TO_UNIXTIME(parse_datetime(o.updatedstatus, 'dd/MM/yyyy HH:mm:ss')) as BIGINT) ELSE 0 END as delivery_date_timestamp, 
Null as delivery_date_timestamp, 
Null as payment_status, 
o.payment as payment_method, 
o.updated, 
0 as last_modified, 
cast('DCS' as varchar) as source_system, 
o.time, 
rank() over (partition by o.order_id, o.created, o.country, o.user_id, o.order_channel, o.order_type, o.status, o.total, o.subtotal, o.order_reason, o.shipping, o.s_zipcode, o.s_city, o.payment  order by o.updated, o.time desc) r 

from db_l0_odatadcs.orders o 
where   
		o.time > 
		( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ) 
  ) a 
where  
r = 1;