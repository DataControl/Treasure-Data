delete from db_stg_current_record_dcs_bi.products_dcs where time > 0;

insert into db_stg_current_record_dcs_bi.products_dcs 
select distinct 
a.created_date,
a.created_by,
a.last_modified_date, 
a.last_modified_by, 
a.product_id_product_code_key, 
a.product_id,
a.market,
a.product_type,
a.product_variant,
a.product_description,
a.products,
a.unit_price, 
a.unit_per_order, 
a.currency,
a.product_code, 
a.source_system, 
a.updated , 
a.last_modified, 
a.time 
from 
(
select 
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') created_date,
cast('dcs' as varchar) as  created_by,
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') last_modified_date, 
cast('dcs' as varchar) as last_modified_by, 
'dcs' || '_' || o.product_id || '_product_code' as product_id_product_code_key, 
'dcs' || '_' || o.product_id as product_id, 
o.country as market, 
Null as product_type, 
Null as product_variant, 
Null as product_description, 
Null as products, 
Null as unit_price, 
Null as unit_per_order, 
'NA' as currency, 
Null as product_code, 
cast('DCS' as varchar) as source_system, 
h.updated, 
0 as last_modified, 
o.time, 
rank() over (partition by o.country, o.product_id order by h.updated, o.time desc) r 

from db_l0_odatadcs.orderitems o 
 left outer join db_l0_odatadcs.orders h on o.order_id = h.order_id  
where   
		o.time > 
		( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ) 
  ) a 
  where  r = 1; 