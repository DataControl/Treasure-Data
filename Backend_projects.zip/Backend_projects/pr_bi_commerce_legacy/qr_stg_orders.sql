delete from db_stg_bi.orders_legacy_dcs_dce where time > 0;

insert into db_stg_bi.orders_legacy_dcs_dce ( 
created_date,
created_by,
last_modified_date,
last_modified_by,
order_id,
order_created_date,
order_payment_date,
market,
persona_id,
identity_identifier, 
order_channel_legacy,   ----
order_channel,
order_type_legacy,      ------
order_type,
order_status_legacy,    ------
order_status,
order_value_local_currency, 
order_currency_legacy,	-------
order_currency,
order_reason,
shipping_method,
shipping_status,
shipment_address_city,
shipment_shipping_address_postal_code,
delivery_date_timestamp,
payment_status,
payment_method,
updated,
last_modified, 
source_system, 
time )

--##dce1.0-orders
select 
src.created_date,
src.created_by,
src.last_modified_date,
src.last_modified_by, 
src.order_id,
src.order_created_date,
src.order_payment_date,
src.market,
src.persona_id,
src.identity_identifier,
src.order_channel_legacy,   -----
src.order_channel,
src.order_type_legacy,		------
src.order_type, 
src.order_status_legacy,    ------
src.order_status,
src.order_value_local_currency, 
src.order_currency_legacy, 	-------
src.order_currency,
src.order_reason,
src.shipping_method,
src.shipping_status,
src.shipment_address_city,
src.shipment_shipping_address_postal_code,
src.delivery_date_timestamp,
src.payment_status,
src.payment_method,
src.updated,
src.last_modified,
src.source_system, 
src.time 

from (
select 
s.created_date,
s.created_by,
s.last_modified_date,
s.last_modified_by, 
s.order_id,
s.order_created_date,
s.order_payment_date,
s.market,
s.persona_id,
id.identity_identifier, 
s.order_channel_legacy, 	-----
s.order_channel,
s.order_type_legacy,    ------
s.order_type,
s.order_status_legacy,   ------
s.order_status,
s.order_value_local_currency, 
s.order_currency_legacy,	--------
s.order_currency,
s.order_reason,
s.shipping_method,
s.shipping_status,
s.shipment_address_city,
s.shipment_shipping_address_postal_code,
s.delivery_date_timestamp,
s.payment_status,
s.payment_method,
s.updated,
s.last_modified,
s.source_system, 
s.time 

from (
select 
d.created_date,
d.created_by,
d.last_modified_date,
d.last_modified_by, 
'DCE_' || d.order_id as order_id, 
d.order_created_date, 
Null as order_payment_date, 
d.market,  
'DCE_' || d.market || '_' || d.persona_id as persona_id,  
'N/A' as identity_identifier,  
d.order_channel_legacy, 	-------
d.order_channel, 
d.order_type_legacy, 		-----------
d.order_type,  
d.order_status_legacy,      --------
d.order_status, 
d.order_value_local_currency, 
d.order_currency_legacy,	--------
d.order_currency, 
d.order_reason, 
d.shipping_method, 
d.shipping_status, 
d.shipment_address_city,
d.shipment_shipping_address_postal_code, 
Null as delivery_date_timestamp, 
d.payment_status,  
d.payment_method, 
d.updated, 
d.last_modified, 
d.source_system, 
d.time   

from  db_stg_current_record_dcs_bi.order_dce1 d 		
				where time >  ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
			  where rank = 1 )  
			) s 
left outer join
			
			(select TRIM(a.persona_identifier) as persona_identifier ,b.identity_identifier,
			a.home_country ,a.deletion_flag from  db_l1_harmonization.person a inner join 
			(
					select persona_identifier, identity_identifier,
					 ROW_NUMBER() over (PARTITION by persona_identifier order by time desc) rank
					from db_l1_harmonization.consolidated_id ) b
			on a.persona_identifier=b.persona_identifier and b.rank=1) id	
			on s.persona_id = id.persona_identifier
			and s.created_by='dce1.0' ) src   
			
union 

--##dcs-orders
select  
src.created_date,
src.created_by,
src.last_modified_date,
src.last_modified_by,
src.order_id,
src.order_created_date,
src.order_payment_date,
src.market,
src.persona_id,
src.identity_identifier,
src.order_channel_legacy, 		-----
coalesce(channel_mapping.target_code, Null) as order_channel,
src.order_type_legacy,			-----------
coalesce(type_mapping.target_code, Null) as order_type,
src.order_status_legacy,        -----------
coalesce(status_mapping.target_code, Null) as order_status, 
src.order_value_local_currency,   -------- 
-- coalesce(src.order_value_local_currency*multiplier.multiplier, 1) as order_value_local_currency, 
src.order_currency_legacy,		-----------
coalesce(currency_mapping.target_code, src.order_currency) as order_currency, 
src.order_reason,
src.shipping_method,
src.shipping_status,
src.shipment_address_city,
src.shipment_shipping_address_postal_code,
src.delivery_date_timestamp,
src.payment_status,
src.payment_method,
src.updated,
src.last_modified,
src.source_system, 
src.time  

from (
select 
t.created_date,
t.created_by,
t.last_modified_date,
t.last_modified_by,
t.order_id, 
t.order_created_date,
t.order_payment_date,
t.market,
t.persona_id,
id.identity_identifier,
t.order_channel_legacy, 	-----
t.order_channel,
t.order_type_legacy,		-----
t.order_type,  
t.order_status_legacy,      ------
t.order_status,
t.order_value_local_currency, 
t.order_currency_legacy,	-------
t.order_currency,
t.order_reason,
t.shipping_method,
t.shipping_status,
t.shipment_address_city,
t.shipment_shipping_address_postal_code,
t.delivery_date_timestamp,
t.payment_status,
t.payment_method,
t.updated,
t.last_modified,
t.source_system, 
t.time  

from (
select 
o.created_date,
o.created_by,
o.last_modified_date,
o.last_modified_by,
'DCS_' || o.market || '_' || o.order_id as order_id, 
o.order_created_date, 
Null as order_payment_date, 
o.market, 
'DCS_' || o.market || '_' || o.persona_id as persona_id, 
---Identity_Identifier, 
o.order_channel_legacy, 	-------
o.order_channel, 
o.order_type_legacy,      ------
o.order_type, 
o.order_status_legacy,    -------
o.order_status, 
o.order_value_local_currency, 
o.order_currency_legacy, 	-------
o.order_currency,  --
o.order_reason,
o.shipping_method,
o.shipping_status,
o.shipment_address_city,
o.shipment_shipping_address_postal_code,
o.delivery_date_timestamp,
o.payment_status,
o.payment_method,
o.updated,
o.last_modified,
o.source_system, 
o.time 
				
				from  db_stg_current_record_dcs_bi.order_dcs o 
				
				where time >  ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
			  where rank = 1 ) 
			) t   
			
left outer join 
			
			(select TRIM(a.persona_identifier) as persona_identifier ,b.identity_identifier,
			a.home_country ,a.deletion_flag from  db_l1_harmonization.person a inner join 
			(
					select persona_identifier, identity_identifier, 
					 ROW_NUMBER() over (PARTITION by persona_identifier order by time desc) rank
					from db_l1_harmonization.consolidated_id ) b
			on a.persona_identifier=b.persona_identifier and b.rank=1) id	
			on t.persona_id = id.persona_identifier
			and t.created_by='dcs' ) src 

left outer join db_stg_bi_technical.reference_data_mapping currency_mapping 
	on currency_mapping.field_name = 'order_currency' and trim(upper(src.market)) = trim(upper(currency_mapping.legacy_code)) and trim(upper(src.market)) = trim(upper(currency_mapping.ref_data_country)) and (trim(src.created_by)) = (trim(currency_mapping.source)) 
	
left outer join db_stg_bi_technical.reference_data_mapping channel_mapping 
	on channel_mapping.field_name = 'order_channel' and trim(upper(src.order_channel)) = trim(upper(channel_mapping.legacy_code)) and  trim(upper(src.market)) = trim(upper(channel_mapping.ref_data_country)) and (trim(src.created_by)) = (trim(channel_mapping.source)) 
	
left outer join db_stg_bi_technical.reference_data_mapping type_mapping 
	on type_mapping.field_name = 'order_type' and trim(upper(src.order_type)) = trim(upper(type_mapping.legacy_code)) and trim(upper(src.market)) = trim(upper(type_mapping.ref_data_country)) and (trim(src.created_by)) = (trim(type_mapping.source)) 
	
left outer join db_stg_bi_technical.reference_data_mapping status_mapping 
	on status_mapping.field_name = 'order_status' and trim(upper(src.order_status)) = trim(upper(status_mapping.legacy_code)) and trim(upper(src.market)) = trim(upper(status_mapping.ref_data_country)) and (trim(src.created_by)) = (trim(status_mapping.source)) 
	
left outer join db_stg_bi_technical.dcs_revenue_multiplier multiplier 
	on trim(upper(src.market)) = trim(upper(multiplier.mk_id)) and (trim(src.order_type)) = (trim(multiplier.order_type)) and (trim(src.order_channel)) = (trim(multiplier.order_channel)) and (trim(src.order_reason)) = (trim(multiplier.order_reason)) and (trim(src.order_status)) = (trim(multiplier.status)) ; 