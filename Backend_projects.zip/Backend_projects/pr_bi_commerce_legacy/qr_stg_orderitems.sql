delete from db_stg_bi.order_items_legacy_dcs_dce where time > 0;

insert into db_stg_bi.order_items_legacy_dcs_dce ( 
created_date,
created_by,
last_modified_date, 
last_modified_by, 
unique_id, 
order_id, 
product_id, 
market, 
quantity, 
updated, 
last_modified, 
source_system, 
time )

--##dce1.0-order_items 
select 
s.created_date,
s.created_by,
s.last_modified_date, 
s.last_modified_by, 
s.unique_id, 
s.order_id, 
s.product_id, 
s.market, 
s.quantity, 
s.updated, 
s.last_modified, 
s.source_system, 
s.time 

from (
select 
d.created_date,
d.created_by,
d.last_modified_date,
d.last_modified_by, 
d.unique_id, 
d.order_id, 
d.product_id, 
d.market, 
d.quantity, 
d.updated, 
d.last_modified, 
d.source_system,  
d.time   

from  db_stg_current_record_dcs_bi.order_items_dce1 d 		
				where time >  ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
			  where rank = 1 )  
			) s 
			
union 

--##dcs-order_items 
select 
t.created_date,
t.created_by,
t.last_modified_date,
t.last_modified_by,
t.unique_id, 
t.order_id, 
t.product_id, 
t.market, 
t.quantity, 
t.updated, 
t.last_modified, 
t.source_system, 
t.time 

from (
select 
o.created_date,
o.created_by,
o.last_modified_date,
o.last_modified_by,
o.unique_id, 
o.order_id, 
o.product_id, 
o.market, 
o.quantity, 
o.updated, 
o.last_modified, 
o.source_system, 
o.time  
				
				from  db_stg_current_record_dcs_bi.order_items_dcs o  
				
				where time >  ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
			  where rank = 1 )  
			) t  ;