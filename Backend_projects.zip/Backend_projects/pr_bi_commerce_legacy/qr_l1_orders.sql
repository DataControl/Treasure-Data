delete from db_l1_bi_commerce.orders where time > 0; 

insert into db_l1_bi_commerce.orders	( 
record_id,
created_date ,
created_by ,
last_modified_date ,
last_modified_by ,
order_id,
order_created_date,
order_payment_date,
market,
persona_id,
identity_identifier, 
order_channel_legacy,  	 ----
order_channel,
order_type_legacy,		-----
order_type, 
order_status_legacy, 	----
order_status,
order_value_local_currency, 
order_currency_legacy,	 -----
order_currency,
order_reason,
shipping_method,
shipping_status,
shipment_address_city,
shipment_shipping_address_postal_code,
delivery_date_timestamp,
payment_status,
payment_method,
updated,
last_modified,
source_system, 
time    
) 
select  
rec_id.max_id + cast(row_number() over (order by b.time) as bigint) as	record_id, 
a.created_date ,
a.created_by ,
a.last_modified_date ,
a.last_modified_by ,
a.order_id,
a.order_created_date,
a.order_payment_date,
a.market,
a.persona_id,
a.identity_identifier, 
a.order_channel_legacy,   ----
a.order_channel,
a.order_type_legacy,	-----
a.order_type, 
a.order_status_legacy, 		------
a.order_status,
cast(a.order_value_local_currency as varchar) as order_value_local_currency, 
a.order_currency_legacy, 	-----
a.order_currency,
a.order_reason,
a.shipping_method,
a.shipping_status,
a.shipment_address_city,
a.shipment_shipping_address_postal_code,
a.delivery_date_timestamp,
a.payment_status,
a.payment_method,
a.updated,
a.last_modified,
a.source_system, 
a.time   

from db_stg_bi.orders_legacy_dcs_dce  a 
 left outer join 
(
select 
d.created_date ,
d.created_by ,
d.last_modified_date ,
d.last_modified_by ,
d.order_id,
d.order_created_date,
d.order_payment_date,
d.market,
d.persona_id,
d.identity_identifier, 
d.order_channel_legacy,   -----
d.order_channel,
d.order_type_legacy,	 -----
d.order_type,
d.order_status_legacy,   -----
d.order_status,
cast(d.order_value_local_currency as varchar) as order_value_local_currency, 
d.order_currency_legacy, 	-----
d.order_currency,
d.order_reason,
d.shipping_method,
d.shipping_status,
d.shipment_address_city,
d.shipment_shipping_address_postal_code,
d.delivery_date_timestamp,
d.payment_status,
d.payment_method,
d.updated,
d.last_modified,
d.source_system, 
d.time 

from  db_l1_bi_commerce.orders  c, 
db_stg_bi.orders_legacy_dcs_dce  d,
(select ROW_NUMBER() over (PARTITION by order_id, persona_id, market, order_type order by time desc) rank, order_id, persona_id, market, order_type, time  from db_l1_bi_commerce.orders) r 
where 
coalesce(c.created_date,0) = coalesce( d.created_date,0)  and 
coalesce(c.created_by,'na') = coalesce( d.created_by,'na')  and 
coalesce(c.last_modified_date, 0) = coalesce( d.last_modified_date,0)  and 
coalesce(c.last_modified_by,'na') = coalesce( d.last_modified_by,'na')  and 
coalesce(c.order_id,'na') = coalesce( d.order_id,'na')  and 
coalesce(c.order_created_date,'na') = coalesce( d.order_created_date,'na')  and 
coalesce(c.order_payment_date, 0) = coalesce( d.order_payment_date, 0)  and 
coalesce(c.market,'na') = coalesce( d.market,'na')  and 
coalesce(c.persona_id,'na') = coalesce( d.persona_id,'na')  and 
coalesce(c.identity_identifier,'na') = coalesce( d.identity_identifier,'na')  and 
coalesce(c.order_channel_legacy,'na') = coalesce( d.order_channel_legacy,'na')  and   		-----
coalesce(c.order_channel,'na') = coalesce( d.order_channel,'na')  and 
coalesce(c.order_type_legacy,'na') = coalesce( d.order_type_legacy,'na')  and 				-----
coalesce(c.order_type,'na') = coalesce( d.order_type,'na')  and 
coalesce(c.order_status_legacy,'na') = coalesce( d.order_status_legacy,'na')  and  			------
coalesce(c.order_status,'na') = coalesce( d.order_status,'na')  and 
coalesce(cast(c.order_value_local_currency as varchar),'na') = coalesce(cast(d.order_value_local_currency as varchar),'na')  and 
coalesce(c.order_currency_legacy,'na') = coalesce( d.order_currency_legacy,'na')  and 		-----
coalesce(c.order_currency,'na') = coalesce( d.order_currency,'na')  and 
coalesce(c.order_reason,'na') = coalesce( d.order_reason,'na')  and 
coalesce(c.shipping_method,'na') = coalesce( d.shipping_method,'na')  and 
coalesce(c.shipping_status,'na') = coalesce( d.shipping_status,'na')  and 
coalesce(c.shipment_address_city,'na') = coalesce( d.shipment_address_city,'na')  and 
coalesce(c.shipment_shipping_address_postal_code,'na') = coalesce( d.shipment_shipping_address_postal_code,'na')  and 
coalesce(c.delivery_date_timestamp, 0) = coalesce( d.delivery_date_timestamp, 0)  and 
coalesce(c.payment_status,'na') = coalesce( d.payment_status,'na')  and 
coalesce(c.payment_method,'na') = coalesce( d.payment_method,'na')  and 
coalesce(c.updated,'na') = coalesce( d.updated,'na')  and 
coalesce(c.last_modified,0) = coalesce( d.last_modified,0)  and  
coalesce(c.source_system, 'na') = coalesce( d.source_system, 'na')  and 
c.order_id = r.order_id and 
c.time = r.time and 
r.rank=1 ) b 
on a.order_id = b.order_id,  
(select  COALESCE(cast(max(record_id) as bigint),0) max_id from db_l1_bi_commerce.orders) rec_id
where b.order_id  is null and 
a.time >
  ( select last_load_ts
   from (
 select last_load_ts, 
 ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
 from db_stg_bi_technical.delta_load_log_dce 
 where layer = 'bi_legacy_ecommerce'
 and entity_name= 'ecommerce_legacy' 
 and operation_mode = 'insert' 
 and completion_flag = 0 order by time desc 
	) 
	where rank = 1 );