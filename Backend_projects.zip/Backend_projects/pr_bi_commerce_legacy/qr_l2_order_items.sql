delete from db_l2_bi.order_items where time > 0;

insert into db_l2_bi.order_items ( 
   record_id,
   created_date ,
   created_by ,
   last_modified_date ,
   last_modified_by ,
   unique_id,
   order_id,
   product_id,
   market, 
   quantity, 
   updated, 
   last_modified, 
   time    
) 
select 
d.record_id, 
d.created_date ,
d.created_by ,
d.last_modified_date ,
d.last_modified_by ,
d.unique_id,
d.order_id,
d.product_id,
d.market, 
d.quantity, 
d.updated, 
d.last_modified, 
d.time 
from db_l1_bi_commerce.order_items_legacy_dcs_dce d; 