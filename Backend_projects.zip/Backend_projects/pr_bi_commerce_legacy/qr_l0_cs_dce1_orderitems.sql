delete from db_stg_current_record_dcs_bi.order_items_dce1 where time > 0;

insert into db_stg_current_record_dcs_bi.order_items_dce1 
select distinct 
a.created_date,
a.created_by,
a.last_modified_date, 
a.last_modified_by, 
a.unique_id, 
a.order_id, 
a.product_id, 
a.market, 
a.quantity, 
a.updated, 
a.last_modified, 
a.source_system, 
a.time 
from 
(
select 
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') created_date,
cast('dce1.0' as varchar) as  created_by,
TD_TIME_PARSE(cast(current_timestamp as varchar), 'UTC') last_modified_date, 
cast('dc1.0' as varchar) as last_modified_by, 
o.item_id || '_' || h.order_no as unique_id,    
'DCE_' || '_' || h.order_no as order_id, 
o.item_id as product_id, 
h.country as market, 
o.quantity, 
Null as updated,  ---- corresponding to dcs
o.last_modified, 
cast('DCE1.0' as varchar) as source_system, 
o.time, 
rank() over (partition by o.item_id, o.quantity, h.order_no, h.country order by o.last_modified, o.time desc) r 

from db_pstg_migration.dce_order_item o 
left outer join db_pstg_migration.dce_order_header h on o.order_no = h.order_no 
where   
		o.time > 
		( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank  from db_stg_bi_technical.delta_load_log_dce  where layer = 'bi_legacy_ecommerce' and entity_name= 'ecommerce_legacy' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ) 
  ) a 
where  
r = 1;