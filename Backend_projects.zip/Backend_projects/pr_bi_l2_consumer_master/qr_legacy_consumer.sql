delete  from  db_stg_bi_technical.consumer_legacy_temp where time > 0;
insert into db_stg_bi_technical.consumer_legacy_temp
(
record_id , 
   created_date ,
   created_by ,
   last_modified_date ,
   last_modified_by ,
   identity_unique_identifier ,
   persona_identifier ,
   identity_identifier ,
   database_opt_in ,
   global_opt_in ,
   gender ,
   home_country , 
   segment, 
   is_deleted, 
   blocked_flag , 
   consumer_type, 
   preferred_language ,
   date_of_birth , 
   registration_godfather_id, 
   lastmodified , 
   smoker_declaration_flag, 
   home_market,  
   identity_creation_date,  
   last_update_date, 
   identity_type, 
   blocking_reason, 
   blocked_by, 
   blocking_date, 
   is_enabled_flag, 
   qure, 
   care_plus, 
   qoach, 
   subscription, 
   email_comunication_opt_in, 
   email_verification_status_code, 
   phone_comunication_opt_in, 
   phone_verification_status_code, 
   identities_provider, 
   identities_provider_id, 
   registration_source_app, 
   registration_country, 
   registration_referal_identifier, 
   registration_date, 
   accepted_privacy_policy, 
   accepted_terms_and_conditions, 
   registered_by_employee,  
   registration_id, 
   referral_code, 
   registration_channel, 
   registration_identity_type, 
   registration_market, 
   registration_source_url, 
   registration_coach_id, 
   registration_agent_id, 
   registration_touchpoint_id, 
   registration_retailer_id, 
   registration_event_id, 
   registration_campaign_id, 
   registration_campaign_activity_id,
   device_linked_flag, 
   has_phone,  
   phone_country_code_number, 
   phone_number_first_digits 
)
select 
   s.record_id , 
   s.created_date ,
   s.created_by ,
   s.last_modified_date ,
   s.last_modified_by ,
   s.identity_unique_identifier ,
   s.persona_identifier ,
   s.identity_identifier ,
   s.database_opt_in ,
   s.global_opt_in ,
   s.gender ,
   s.home_country , 
   s.segment, 
   s.is_deleted, 
   s.blocked_flag , 
   s.consumer_type, 
   s.preferred_language ,
   s.date_of_birth , 
   s.registration_godfather_id, 
   s.lastmodified , 
   s.smoker_declaration_flag, 
   s.home_market,  
   s.identity_creation_date,  
   s.last_update_date, 
   s.identity_type, 
   s.blocking_reason, 
   s.blocked_by, 
   s.blocking_date, 
   s.is_enabled_flag, 
   s.qure, 
   s.care_plus, 
   s.qoach, 
   s.subscription, 
   e.communication_opt_in as email_comunication_opt_in,  
   s.email_verification_status_code, 
   p.communication_opt_in as phone_comunication_opt_in, 
   s.phone_verification_status_code, 
   s.identities_provider, 
   s.identities_provider_id, 
   r.registration_source_app, 
   r.registration_country, 
   r.registration_referal_identifier, 
   r.registration_date as registration_date,
   s.accepted_privacy_policy, 
   s.accepted_terms_and_conditions, 
   s.registered_by_employee,  
   s.registration_id, 
   s.referral_code, 
   s.registration_channel, 
   s.registration_identity_type, 
   r.registration_market,  
   s.registration_source_url, 
   s.registration_coach_id, 
   s.registration_agent_id, 
   s.registration_touchpoint_id, 
   s.registration_retailer_id, 
   s.registration_event_id, 
   s.registration_campaign_id, 
   s.registration_campaign_activity_id,
   cast(case when ddi.status = 'ACTIVE' then TRUE when ddi.status = 'INACTIVE' then FALSE end as varchar) as device_linked_flag, 
	case when p.phone_number is not null then 'Y' when p.phone_number is null then 'N' end as has_phone, 
   case when p.phone_number is not null then p.country_code_number when p.phone_number is null then 'N/A' end as phone_country_code_number,  
	case when p.phone_number is not null then substring(p.phone_number, 1, 3) when p.phone_number is null then 'N/A' end as phone_number_first_digits 

   from (
select
   i.record_id ,
   i.created_date ,
   i.created_by ,
   i.last_modified_date ,
   i.last_modified_by ,
   i.identity_unique_identifier ,
   i.persona_identifier ,
   i.identity_identifier ,
   i.database_opt_in ,
   i.global_opt_in ,
   i.gender ,
   i.home_country , 
   i.segment, 
   i.is_deleted ,
   i.blocked_flag ,
   i.consumer_type ,
   i.preferred_language ,
   i.date_of_birth , 
   'N/A' as registration_godfather_id,   --- 
   i.lastmodified, 					---date---
   'N/A' as smoker_declaration_flag, 	 ---
   i.home_market,  					--------
   i.created_date as identity_creation_date, 			---date---     
   i.lastmodified as last_update_date,    ---date---
   i.consumer_type as identity_type,    ------
   'N/A' as blocking_reason,   		---
   'N/A' as blocked_by,       		---
    cast(0 as bigint) as blocking_date, 			---
   'N/A' as is_enabled_flag,        ---
   'N/A' as qure, 					---
   'N/A' as care_plus, 				---
   'N/A' as qoach, 					---
   'N/A' as subscription, 			---
 ---  e.communication_opt_in as email_comunication_opt_in, 					---
   'N/A' as email_verification_status_code,       	---
 --   p.communication_opt_in as phone_comunication_opt_in, 
   'N/A' as phone_verification_status_code, 		---
   'N/A' as identities_provider, 					---
   'N/A' as identities_provider_id, 				---
 --   r.registration_source_app, 
 --   r.registration_country, 
 --   r.registration_referal_identifier, 
 --   r.registration_date as registration_date, 		-----date----
   'N/A' as accepted_privacy_policy, 				---
   'N/A' as accepted_terms_and_conditions, 			---
   'N/A' as registered_by_employee,  				---
   'N/A' as registration_id, 						---
   'N/A' as referral_code, 							---
   'N/A' as registration_channel, 					---
   'N/A' as registration_identity_type, 			---
--   r.registration_market, 							---
   'N/A' as registration_source_url, 				---				
   'N/A' as registration_coach_id, 					---				
   'N/A' as registration_agent_id, 					---				
   'N/A' as registration_touchpoint_id, 			---
   'N/A' as registration_retailer_id, 				---
   'N/A' as registration_event_id, 					---
   'N/A' as registration_campaign_id, 				---
   'N/A' as registration_campaign_activity_id 		--- 
   ---has_phone,  
---phone_country_code_number, 

  from db_l2_audience.identity i 
  
where time >    ( select last_load_ts
                                      from (
                                            select last_load_ts, 
											       ROW_NUMBER() over (partition by layer, entity_name, operation_mode order by last_load_ts desc) as rank  
												   from db_stg_bi_technical.delta_load_log_dce 
												   where layer = 'db_l2_bi_consumer'
												   and entity_name= 'bi_consumer_load' 
												   and operation_mode = 'insert' 
												   and completion_flag = 0 order by time desc 
											) 
					where rank = 1 )) s  

left outer join 
db_l2_audience.emails e 
on  s.identity_identifier = e.identity_identifier 

left outer join 
db_l2_audience.phones p  
on  s.identity_identifier = p.identity_identifier 

left outer join 
db_l2_audience.registration r  
on  s.identity_identifier = r.identity_identifier  
 
left outer join 
db_l2_audience.devices ddi
on  s.identity_identifier=ddi.identity_identifier ;
					
--added on 24/1/2020 by SDT
	
/* delete from db_l2_bi.consumer where 

identity_unique_identifier 
in (select identity_unique_identifier from  db_stg_bi_technical.consumer_legacy_temp) 
and 
created_by in ('dcs','dce'); */ 