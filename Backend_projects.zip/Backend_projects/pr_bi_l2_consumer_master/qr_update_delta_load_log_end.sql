insert into db_stg_bi_technical.delta_load_log_dce
select layer, operation_mode, entity_name, last_load_ts, number_of_retries,  0 as completion_flag
from db_stg_bi_technical.delta_load_log_dce
where time = (
select max(time) from db_stg_bi_technical.delta_load_log_dce where layer = 'db_l2_bi_consumer' and entity_name= 'bi_consumer_load' and operation_mode = 'insert' and completion_flag = 1
) and layer = 'db_l2_bi_consumer' and entity_name= 'bi_consumer_load' and operation_mode = 'insert' and completion_flag = 1;

delete
from db_stg_bi_technical.delta_load_log_dce
where time = (
select max(time) from db_stg_bi_technical.delta_load_log_dce where layer = 'db_l2_bi_consumer' and entity_name= 'bi_consumer_load' and operation_mode = 'insert' and completion_flag = 1
) and layer = 'db_l2_bi_consumer' and entity_name= 'bi_consumer_load' and operation_mode = 'insert' and completion_flag = 1;