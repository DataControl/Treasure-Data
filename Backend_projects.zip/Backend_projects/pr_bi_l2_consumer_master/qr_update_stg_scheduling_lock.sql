delete from db_stg_bi_technical.stg_scheduling where dependencies = 'wf_l2_bi_consumer';
insert into db_stg_bi_technical.stg_scheduling select 'wf_l0_l1_bi_customer_care' as object, 'wf_l2_bi_consumer' as dependencies, 1 as load_flag;
insert into db_stg_bi_technical.stg_scheduling select 'wf_db_l3_bi_data_marts_cl' as object, 'wf_l2_bi_consumer' as dependencies, 1 as load_flag;