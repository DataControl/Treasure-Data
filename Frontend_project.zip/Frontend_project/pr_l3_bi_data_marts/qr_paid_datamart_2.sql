---------
-- DATA MART PART 2 - Corrupted clicks
---------
  

insert into paid_datamart_new 



SELECT
-- Dimensions
-- Unique key
clickstable.date as date,
clickstable.campaign_id as campaign_id,
clickstable.site_id as site_id, 
clickstable.placement_id as placement_id, 
clickstable.rendering_id as creative_rendering_id, 
clickstable.advertiser_id,

-- Other Dimensions
clickstable.advertiser,
campaigns.campaign as campaign_name,
1 as corrupted_campaign,
CASE WHEN SUBSTR(campaigns.campaign, 3, 1) = '_'
      THEN SUBSTR(campaigns.campaign, 1, 2) 
      ELSE 'Unknown'
END as campaign_country,
clickstable.site as site_name,
clickstable.placement as placement_name,
clickstable.placement_cost_structure as placement_cost_structure,
clickstable.placement_total_booked_units,
clickstable.placement_rate,
corrupted_placement_cost.corrupted_placement_cost,
clickstable.creative_id as creative_id,
clickstable.creative as creative_name,
clickstable.creative_pixel_size as creative_pixel_size,
clickstable.creative_type as creative_type,

-- Measures
0 as total_reach,
0 as total_impressions,
0 as total_eligible_impressions,
0 as total_measurable_impressions,
0 as total_viewable_impressions,
SUM(clickstable.total_clicks) as total_clicks

FROM
(
SELECT
  clicks.date, 
  clicks.campaign_id  as campaign_id,
  clicks.site_id as site_id,
  clicks.placement_id as placement_id,
  clicks.rendering_id as rendering_id,
  clicks.advertiser_id as advertiser_id,
  clicks.advertiser as advertiser,
  clicks.site as site,
  clicks.placement as placement,
  clicks.placement_cost_structure,
  clicks.placement_total_booked_units,
  clicks.placement_rate,
  clicks.creative_id as creative_id,
  clicks.creative as creative,
  clicks.creative_pixel_size as creative_pixel_size,
  clicks.creative_type as creative_type,
    
  SUM(clicks.cnt_rows) as total_clicks
  
  FROM
    (SELECT
    CAST(SUBSTRING(event_time, 1, 10) as VARCHAR) as date,
    campaign_id  as campaign_id,
    site_id as site_id,
    placement_id as placement_id,
    rendering_id as rendering_id,
    CONCAT(CAST(SUBSTRING(event_time, 1, 10) as VARCHAR), campaign_id, site_id, placement_id, rendering_id) as cliks_distinct_key,
    
    advertiser_id,
    advertiser,
    site as site,
    placement as placement,
    placement_cost_structure as placement_cost_structure,
    placement_total_booked_units,
    placement_rate,
    creative_id as creative_id,
    creative as creative,
    creative_pixel_size as creative_pixel_size,
    creative_type as creative_type,
  
    count(*) AS cnt_rows
    
    FROM db_l2_bi.click

    GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17
    ) as clicks
    WHERE clicks.cliks_distinct_key IN
            (
            SELECT clk.clk_distinct_key
            FROM
            (
            SELECT 
            CAST(SUBSTRING(event_time, 1, 10) as VARCHAR) as date,
            c.campaign_id  as campaign_id,
            c.site_id as site_id,
            c.placement_id as placement_id,
            c.rendering_id as rendering_id,
            CONCAT(CAST(SUBSTRING(event_time, 1, 10) as VARCHAR), c.campaign_id, c.site_id, c.placement_id, c.rendering_id) as clk_distinct_key
            FROM db_l2_bi.click as c
            GROUP BY 1,2,3,4,5
            ) as clk
            where clk.clk_distinct_key NOT IN 
                  (SELECT CONCAT(imp.date, imp.campaign_id, imp.site_id, imp.placement_id, imp.creative_rendering_id)
                  FROM
                  (
                  SELECT 
                 distinct  
                  CAST(SUBSTRING(event_time, 1, 10) as VARCHAR) as date,
                  i.campaign_id as campaign_id,
                  i.site_id as site_id, 
                  i.placement_id as placement_id, 
                  i.rendering_id as creative_rendering_id
                  FROM db_l2_bi.impressions as i
                  ) as imp)
            )
GROUP by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16
) as clickstable
LEFT JOIN db_l2_bi.campaigns as campaigns on campaigns.campaign_id = clickstable.campaign_id
LEFT JOIN
(SELECT placement_id, 
MAX(CASE WHEN booked_units_duplicates > 1 OR rate_duplicates > 1
      THEN 1
      ELSE 0
    END) as corrupted_placement_cost
FROM
(
select * from db_stg_bi_technical.placement_cost
)
GROUP BY 1
HAVING MAX(CASE WHEN booked_units_duplicates > 1 OR rate_duplicates > 1
      THEN 1
      ELSE 0
    END) = 1
ORDER by 2 desc
) as corrupted_placement_cost on clickstable.placement_id = corrupted_placement_cost.placement_id

GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20
