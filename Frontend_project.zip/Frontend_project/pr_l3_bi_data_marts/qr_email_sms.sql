select 

distinct 

type,
cast(s.jobid as varchar) as send_id,
cast(s.subscriberkey  as varchar) as subscriber_key,
s.subscriberid as subscriber_id,
cast(cast(FROM_UNIXTIME(s.eventdate)as date) as varchar)  as sendout_date, 
s.ja_emailname as message_name,
(CASE 
        WHEN email_sendlog_dev_errorcode=24 
        THEN 'not delivered'
        ELSE 'delivered'
        END)
         as staus,
			   
d.migrated_identifier as identity_identifier, 
i.global_opt_in as global_opt_in,
i.gender as gender,
i.home_country as home_country,
i.segment as segment,
i.date_of_birth as date_of_birth,
i.database_opt_in as database_opt_in,
i.lastmodified as lastmodified 
from 
(select 
distinct 
type,
jobid,
subscriberkey,
subscriberid,
ja_emailname,
email_sendlog_dev_errorcode,
eventdate

from db_l2_bi.sendouts where type = 'SMS'
) s
left join 
(
select
identity_identifier , 
max(global_opt_in) as global_opt_in ,
max( gender) as gender ,
max( home_country) as home_country ,
max( segment)  as segment,
max( CAST(FROM_UNIXTIME(date_of_birth) as VARCHAR)) as date_of_birth,
max( database_opt_in) as database_opt_in ,
max(lastmodified)  as lastmodified
from db_l2_bi.consumer i
group by 1
)i
on s.subscriberkey  = i.identity_identifier


left join

${td.last_results.var_target_table}  d

on s.subscriberkey  = d.${td.last_results.unique_key}

