drop table if exists  db_l3_bi_data_marts.sms_datamart_new;
