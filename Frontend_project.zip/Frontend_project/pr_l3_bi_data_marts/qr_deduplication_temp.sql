select source_identity_identifier,
consolidated_identifier,
consolidated_source_id

from (

select  source.${td.last_results.source_unique_identifier} as source_identity_identifier,
 id.identity_identifier as consolidated_identifier,
 id.source_id as consolidated_source_id
 from ${td.last_results.var_source_table} source inner join db_l2_organic.consolidated_id id 
 on 
 (source.${td.last_results.source_unique_identifier}=id.identity_identifier )
 and id.source_system='R1' and source.${td.last_results.source_unique_identifier} is not null
 
 union all
 
 
select  source.${td.last_results.source_unique_identifier} as source_identity_identifier,
 id.identity_identifier as consolidated_identifier,
 id.source_id as consolidated_source_id
 from ${td.last_results.var_source_table} source inner join db_l2_organic.consolidated_id id 
 on 
 (source.${td.last_results.source_unique_identifier}=id.source_id)
 and id.source_system='R1' and source.${td.last_results.source_unique_identifier} is not null
 )
 group by 1,2,3