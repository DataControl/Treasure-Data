--drop table if exists  db_stg_bi_technical.cases_latest_help;
create table db_stg_bi_technical.cases_latest_help
as
select 
case_identifier,
max(latest_update_date) as latest_update_date,
CONCAT(case_identifier,'-',max(cast(latest_update_date as varchar))) as key
from 
db_l2_bi.cases_attributes c
group by 1
