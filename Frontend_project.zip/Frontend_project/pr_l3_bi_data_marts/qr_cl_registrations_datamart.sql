--insert into db_l3_bi_data_marts.registrations_datamart
SELECT
CASE WHEN SUBSTR(CAST(from_unixtime(registration_date) as varchar), 1,10)='1970-01-01' 
THEN NULL 
ELSE TD_TIME_FORMAT(cast(substring(cast(registration_date as varchar),1,10) as bigint),'yyyy-MM-dd HH:mm:ss','UTC') 
end as identity_registration_date, 
CASE WHEN SUBSTR(CAST(from_unixtime(identity_creation_date) as varchar), 1,10)='1970-01-01' 
THEN NULL 
ELSE TD_TIME_FORMAT(cast(substring(cast(identity_creation_date as varchar),1,10) as bigint),'yyyy-MM-dd HH:mm:ss','UTC') 
end as identity_creation_date, 
CASE WHEN device_linked_flag = 'true' 
THEN 1  
WHEN device_linked_flag = 'false' 
THEN 0 
ELSE NULL 
END as device_linked_flag,
persona_identifier as persona_identifier,
identity_identifier as identity_identifier,
UPPER(gender) as gender,
cast(date_diff('YEAR',cast(from_unixtime(date_of_birth) as date), CURRENT_DATE) as bigint) as age,
segment,
home_country,
registration_channel,
CASE WHEN global_opt_in = 'true'
THEN 1
WHEN global_opt_in = 'false'
THEN 0
ELSE NULL
END as global_opt_in,
CASE WHEN database_opt_in = 'true'
THEN 1
WHEN database_opt_in = 'false'
THEN 0
ELSE NULL
END as database_opt_in ,
CASE WHEN email_comunication_opt_in = 'true'
THEN 1
WHEN email_comunication_opt_in = 'false'
THEN 0
ELSE NULL
END as email_comunication_opt_in,
cast(date_diff('DAY',cast(from_unixtime(registration_date) as date), CURRENT_DATE) as bigint) as days_from_registration,
CASE WHEN created_by = 'dcs'
Then 'DCS'
WHEN created_by = 'dce'
THEN 'DCE1.0'
WHEN created_by = 'gigya'
THEN 'DCE2.0'
ELSE NULL
END AS source_system,
registration_country,
registration_referal_identifier,
care_plus,
registration_campaign_id,
registration_campaign_activity_id,
registration_coach_id, 
registration_agent_id,
registration_retailer_id,
registration_source_app,
registration_event_id,
registration_touchpoint_id,
identity_type	identity_type,
consumer_type, 
registration_godfather_id, 
has_phone,  
phone_country_code_number, 
phone_number_first_digits   
FROM db_l2_bi.consumer;
/*where SUBSTR(CAST(from_unixtime(registration_date) as varchar), 1,10)
> (select max(identity_registration_date) from db_l3_bi_data_marts.registrations_datamart)
--identity_registration_date is not null and rank=1*/