---------
-- DATA MART PART 1 - Correct clicks
---------
SELECT
-- Dimensions
-- Unique key
i.date,
i.campaign_id as campaign_id,
i.site_id as site_id, 
i.placement_id as placement_id, 
i.rendering_id as creative_rendering_id, 
i.advertiser_id,

-- Other Dimensions
i.advertiser,
campaigns.campaign as campaign_name,
0 as corrupted_campaign,
CASE WHEN SUBSTR(campaigns.campaign, 3, 1) = '_'
      THEN SUBSTR(campaigns.campaign, 1, 2) 
      ELSE 'Unknown'
END as campaign_country,
i.site as site_name,
i.placement as placement_name,
i.placement_cost_structure,
i.placement_total_booked_units,
i.placement_rate,
corrupted_placement_cost.corrupted_placement_cost,
i.creative_id as creative_id,
i.creative as creative_name,
i.creative_pixel_size as creative_pixel_size,
i.creative_type as creative_type,

-- Measures
SUM(i.total_reach) as total_reach,
SUM(i.total_impressions) as total_impressions,
SUM(i.total_eligible_impressions) as total_eligible_impressions,
SUM(i.total_measurable_impressions) as total_measurable_impressions,
SUM(i.total_viewable_impressions) as total_viewable_impressions,
SUM(clicks.cnt_rows) as total_clicks

FROM
(  
select * from db_stg_bi_technical.impression_agr
) as i
LEFT JOIN db_l2_bi.campaigns as campaigns on campaigns.campaign_id = i.campaign_id
LEFT JOIN
(SELECT placement_id, 
MAX(CASE WHEN booked_units_duplicates > 1 OR rate_duplicates > 1
      THEN 1
      ELSE 0
    END) as corrupted_placement_cost
FROM
(
select * from db_stg_bi_technical.placement_cost
)
GROUP BY 1
HAVING MAX(CASE WHEN booked_units_duplicates > 1 OR rate_duplicates > 1
      THEN 1
      ELSE 0
    END) = 1
ORDER by 2 desc
) as corrupted_placement_cost on i.placement_id = corrupted_placement_cost.placement_id
LEFT JOIN
-- add info about clicks
( SELECT
      CAST(SUBSTRING(event_time, 1, 10) as VARCHAR) as date,
      campaign_id  as campaign_id,
      site_id as site_id,
      placement_id as placement_id,
      rendering_id as rendering_id,
      count(*) AS cnt_rows
  FROM db_l2_bi.click
  GROUP BY 1,2,3,4,5
  ) as clicks on i.date = clicks.date
              and i.campaign_id = clicks.campaign_id
              and i.site_id = clicks.site_id
              and i.placement_id = clicks.placement_id
              and i.rendering_id = clicks.rendering_id

GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20