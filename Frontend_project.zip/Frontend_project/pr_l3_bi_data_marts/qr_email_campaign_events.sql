select batch_id, job_id, identity_identifier,
count(distinct CASE 
        WHEN type='CLICKS'
        THEN interaction_id
        ELSE null
        END)
         as total_email_clicks,
count(distinct CASE
        WHEN type='OPENS'
        THEN interaction_id
        ELSE null
        END) as total_email_open,
count(distinct CASE
        WHEN type='BOUNCES'
        THEN interaction_id
        ELSE null
        END) as total_email_bounces
from db_l2_bi.campaign_events
group by 1,2,3