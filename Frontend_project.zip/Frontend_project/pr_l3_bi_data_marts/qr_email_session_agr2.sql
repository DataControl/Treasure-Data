drop table if exists db_stg_bi_technical.session_agr2;
create table db_stg_bi_technical.session_agr2
as
select 
 subscriber_id,
send_id,
-- Measures
sum(total_sessions) as total_sessions,
sum(total_web_bounces) as total_web_bounces,
sum(total_transactions) as total_transactions,
sum(total_revenue) as total_revenue,
sum(total_session_duration) as total_session_duration,
sum(total_pageviews) as total_pageviews,
sum(total_visitors) as total_visitors
-- joins
from db_stg_bi_technical.session_agr
group by 1,2