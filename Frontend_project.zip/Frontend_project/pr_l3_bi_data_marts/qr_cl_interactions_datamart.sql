select 
interaction_id ,
identity_unique_identifier as identity_identifier,
--channel,
channel_refcode as channel_refcode,
interaction_type_refcode as interaction_type,
TD_TIME_FORMAT(cast(substring(cast(date_time as varchar),1,10) as bigint),'yyyy-MM-dd HH:mm:ss','UTC') as interaction_date_time,
appointment_id ,
coach_id ,
product_id ,
device_id ,
-- no such column in preprod, only device_version!!!
device_version as device_version,
order_id ,
retailer_id ,
case_id,
market_refcode,
country_refcode,
--country
Location_id,
location_type_refcode,
Location_description

from db_l2_bi.interactions