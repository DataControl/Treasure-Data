select 
s.journey_id,
s.journey_name,
s.email_sendlog_dev_errorcode,
s.ja_emailname,
s.sj_emailname,
s.batch_id,
s.send_id,
s.subscriber_key,
s.sendout_date,
s.email_scope,
s.description,
s.messagename,
s.subject,
s.preview_url,
s.email_domain,
s.total_email_sent,
s.total_email_sent-case when c.total_email_bounces is null then 0 else c.total_email_bounces end as total_email_delivered,
c.total_email_clicks,
c.total_email_open,
c.total_email_bounces,
(cast(se.total_revenue as double)/1000000) as total_revenue,
se.total_sessions,
se.total_web_bounces,
se.total_transactions,
se.total_visitors,
se.total_session_duration,
se.total_pageviews,
d.migrated_identifier as identity_identifier, 
i.global_opt_in as global_opt_in,
i.gender as gender,
i.home_country as home_country,
i.segment as segment,
i.date_of_birth as date_of_birth,
i.database_opt_in as database_opt_in,
i.lastmodified as lastmodified

  from 
  db_stg_bi_technical.sendouts_agr s
  left join 
  db_stg_bi_technical.campaign_events_agr c
  on
  s.batch_id= c.batch_id and
  s.send_id=c.job_id and
  s.subscriber_key=c.identity_identifier
  left join db_stg_bi_technical.session_agr se
  on  s.subscriber_key = (se.subscriber_id ) and cast(s.send_id as VARCHAR)  = (se.send_id)
 left join 
(
select
identity_identifier , 
max(global_opt_in) as global_opt_in ,
max( gender) as gender ,
max( home_country) as home_country ,
max( segment)  as segment,
max( CAST(FROM_UNIXTIME(date_of_birth) as VARCHAR)) as date_of_birth,
max( database_opt_in) as database_opt_in ,
max(lastmodified)  as lastmodified
 from db_l2_bi.consumer i
 group by 1
)i
on s.subscriber_key = i.identity_identifier

left join

${td.last_results.var_target_table}  d

on s.subscriber_key  = d.${td.last_results.unique_key}