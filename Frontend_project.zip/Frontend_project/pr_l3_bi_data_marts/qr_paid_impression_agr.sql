insert into db_stg_bi_technical.impression_agr
 SELECT CAST(SUBSTRING(event_time, 1, 10) as VARCHAR) as date,
        campaign_id,
        site_id,
        placement_id,
        rendering_id,
        advertiser_id,

        advertiser,
        site,
        placement,
        placement_cost_structure,
        placement_total_booked_units,
        placement_rate,
        creative_id,
        creative,
        creative_pixel_size,
        creative_type,

        COUNT(DISTINCT user_id) as total_reach, 
        COUNT(DISTINCT impression_id) as total_impressions,
        COUNT(DISTINCT(CASE WHEN active_view_eligible_impressions = 1
                            THEN impression_id
                            ELSE NULL
                        END)) as total_eligible_impressions,
        COUNT(DISTINCT(CASE WHEN active_view_measurable_impressions = 1
                            THEN impression_id
                            ELSE NULL
                        END)) as total_measurable_impressions,
        COUNT(DISTINCT(CASE WHEN active_view_viewable_impressions = 1
                            THEN impression_id
                            ELSE NULL
                        END)) as total_viewable_impressions
  FROM db_l2_bi.impressions
  where

cast(CAST(SUBSTRING(event_time, 1, 10) as VARCHAR) as date)   > (select max(cast(date as date)) from db_stg_bi_technical.impression_agr)
  GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16
  