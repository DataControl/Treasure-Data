select  a.${td.last_results.unique_key} as ${td.last_results.unique_key},
MAX(
CASE 
when COALESCE(b.consolidated_identifier,'na')<>'na' and COALESCE(b.consumer_identifier,'na') <> 'na'
 then b.consolidated_identifier
 when COALESCE(b.consolidated_identifier,'na') <>'na' and COALESCE(b.consumer_identifier,'na') ='na' then b.consolidated_source_id 
 
 when COALESCE(b.consolidated_identifier,'na')='na' and COALESCE(b.consumer_identifier,'na') ='na'
then a.${td.last_results.source_unique_identifier}
end) as migrated_identifier
from 
${td.last_results.var_source_table}  a left outer join ( select  
 id.source_identity_identifier,
 id.consolidated_identifier,
 id.consolidated_source_id,
 c.identity_identifier as consumer_identifier
 from ${td.last_results.var_target_temp_table} id 
 
 left outer join db_l2_bi.consumer c
on (id.consolidated_identifier =c.identity_identifier)
group by 1,2,3,4) b
on 
COALESCE(a.${td.last_results.source_unique_identifier},'na') =b.source_identity_identifier
GROUP BY 1;