select
s.journey_id,
s.journey_name,
cast(s.jobid as varchar) as send_id,
cast(s.subscriberkey  as varchar) as subscriber_key,
s.subscriberid as subscriber_id,
s.batchid,
s.type,
cast(cast(FROM_UNIXTIME(s.eventdate)as date) as varchar)  as sendout_date, 
s.email_sendlog_dev_errorcode,
s.ja_emailname,
s.sj_emailname,
s.messagename,
s.email_scope,
s.description,
c.total_email_clicks,
c.total_email_open,
c.total_email_bounces,
d.migrated_identifier as identity_identifier, 
i.global_opt_in as global_opt_in,
i.gender as gender,
i.home_country as home_country,
i.segment as segment,
i.date_of_birth as date_of_birth,
i.database_opt_in as database_opt_in,
i.lastmodified as lastmodified
from  db_l2_bi.sendouts s
left join 
  db_stg_bi_technical.campaign_events_agr c
  on
  s.batchid= c.batch_id and
  s.jobid=c.job_id and
  s.subscriberkey=c.identity_identifier
left join 
(
select
identity_identifier , 
max(global_opt_in) as global_opt_in ,
max( gender) as gender ,
max( home_country) as home_country ,
max( segment)  as segment,
max( CAST(FROM_UNIXTIME(date_of_birth) as VARCHAR)) as date_of_birth,
max( database_opt_in) as database_opt_in ,
max(lastmodified)  as lastmodified
 from db_l2_bi.consumer i
 group by 1
)i
on s.subscriberkey = i.identity_identifier


left join

${td.last_results.var_target_table}  d

on s.subscriberkey  = d.${td.last_results.unique_key}