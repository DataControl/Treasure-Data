delete from db_stg_bi.cases_mapping where time > 0;
 
insert into db_stg_bi.cases_mapping
		 (  record_id,
			createddate		,
			createdby		,
			lastmodifieddate		,
			lastmodifiedby		,
			mapping_identifier,
			correlation_id,
			legacy_id,
			organic_id
			)

select cast(row_number() over (order by time) as bigint)  record_id,
			createddate		,
			createdby		,
			lastmodifieddate		,
			lastmodifiedby		,
			mapping_identifier,
			correlation_id,
			 legacy_id2 as legacy_id   ,
			organic_id
			from 
			(select concat('DCE_',COALESCE(ccr_homecountry__c,'XX'),'_',ID) AS legacy_id1, concat('DCE_',COALESCE(ccr_homecountry__c,'XX'),'_',casenumber) AS legacy_id2 FROM 
(select distinct id,ccr_homecountry__c,casenumber from db_l0_sfdc."case" )) a,
(	select distinct 
			td_time_parse(cast(current_timestamp as varchar), 'utc') as createddate		,
			'dce2' as createdby		,
			td_time_parse(cast(current_timestamp as varchar), 'utc') as lastmodifieddate		,
			'dce2' as lastmodifiedby		,
			concat(split_part(transaction_id__c,'_',5),'_',
			split_part(transaction_id__c,'_',6 ),'_',
			split_part(transaction_id__c,'_',7 ),'_',casenumber) as mapping_identifier,
			transaction_id__c as correlation_id,
			concat(split_part(transaction_id__c,'_',5),'_',	split_part(transaction_id__c,'_',6 ),'_',
			split_part(transaction_id__c,'_',7 )) as legacy_id,
			casenumber as organic_id,
			time
			from  db_l0_organic.cases_parsed where lower(transaction_id__c) like 'mig%' and lower(COALESCE(transaction_id__c,'na')) not like '%closed-cases%' ) b 


where a.legacy_id1=b.legacy_id;