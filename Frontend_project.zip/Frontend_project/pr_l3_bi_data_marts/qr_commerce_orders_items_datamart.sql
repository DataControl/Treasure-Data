SELECT 
o.order_id as order_id,
oi.product_id_dcs as product_id_dcs,
oi.product_variant as product_variant,
oi.unique_id as unique_id,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(order_created_date)),'yyyy-MM-dd HH:mm:ss','UTC') as order_created_date,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(order_payment_date)),'yyyy-MM-dd HH:mm:ss','UTC') as order_payment_date,
o.country as market,
c.persona_identifier as persona_identifier,
o.identity_identifier as identity_identifier,
c.gender as gender,
CAST(FROM_UNIXTIME(c.date_of_birth) as VARCHAR) as date_of_birth,
c.segment as segment,
c.global_opt_in as global_opt_in,
c.database_opt_in as database_opt_in,
o.order_channel as order_channel,
o.order_type as order_type,
o.order_type_description as order_type_description,
o.order_status as order_status,
o.shipping_method as shipping_method,
o.shipping_method_description as shipping_method_description,
o.shipping_status as shipping_status,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(shipping_date)),'yyyy-MM-dd HH:mm:ss','UTC') as shipping_date,
o.payment_status as payment_status,
o.payment_method as payment_method,
SPLIT(product_variant, '.')[1] as product_code,
CAST(NULL as varchar) as product_type,
CAST(NULL as varchar) as product_description,
CAST(NULL as varchar) as product_brand,
CAST(NULL as varchar) as unit_price,
o.order_currency as order_currency,
oi.net as order_item_price,
oi.order_item_quantity as no_products,
o.promotional_code as promotional_code,
o.promotional_description as promotional_description,
o.order_reason as order_reason,
o.order_reason_description as order_reason_description,
o.order_placed_by as order_placed_by,
oi.order_item_quantity, 
oi.device_codentify, 
oi.quantity_unit ,
oi.net,
oi.net_original ,
oi.net_per_unit ,
oi.net_per_unit_original ,
oi.gross,
oi.gross_original ,
oi.gross_per_unit ,
oi.gross_per_unit_original ,
oi.vat_rate ,
oi.vat_value ,
oi.original_item_vat_value ,
oi.vat_per_unit ,
oi.original_vat_per_unit ,
oi.sellable_product_code ,
oi.apportioned_header_discount ,
oi.apportioned_header_discount_net ,
oi.ean,
oi.item_discount_gross ,
oi.item_discount_descr ,
oi.item_discount_code ,
oi.item_discount_no ,
oi.item_discount_net ,
oi.item_discount_type ,
o.created_by as source_system
 
FROM
(SELECT * FROM db_l2_bi.commerce_orders
--WHERE SUBSTR(order_created_date, 1, 10) != '01/01/1970'
) as o
LEFT JOIN db_l2_bi.commerce_orders_items as oi 
on (UPPER(oi.created_by)||'_'||
--UPPER(oi.country)||
'_'||oi.order_id) = (UPPER(o.created_by)||'_'||
--UPPER(o.country)||
'_'||o.order_id)
--LEFT JOIN db_l2_bi.products as p on oi.product_id = p.product_id
LEFT JOIN db_l2_bi.consumer as c on o.identity_identifier = c.identity_identifier  WHERE CONCAT(o.order_id,(updated_time)) in
(select  key from db_stg_bi_technical.commerce_orders_latest)