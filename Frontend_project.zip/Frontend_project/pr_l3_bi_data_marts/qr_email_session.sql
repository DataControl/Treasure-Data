select 
s.session_id as session_id,
s.date as contact_date,
sa.fullvisitorid as visitor_id,
sa.journeyid,
'Campaign Name' as campaign_name,
sa.activityid,
sa.sendoutjobid,
sa.subscriberid,

-- Persona & all available atributes
d.migrated_identifier as identity_identifier , 
c.gender ,
c.home_country ,
c.segment ,
c.database_opt_in ,
c.global_opt_in ,
-- Measures
(s.total_bounces) as total_web_bounces,
(s.total_transactions) as total_transactions,
(s.total_transactionrevenue) as total_revenue,
(s.total_timeonsite) as total_session_duration,
(s.total_pageviews) as total_pageviews

-- joins
from db_l2_bi.session s
left join db_l2_bi.session_attributes sa
on s.session_id = sa.session_id
and s.record_id = sa.record_id
left join db_l2_bi.consumer c
on sa.subscriberid = c.identity_identifier

left join

${td.last_results.var_target_table}  d

on s.session_id  = d.${td.last_results.unique_key}