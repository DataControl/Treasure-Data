drop table if exists  db_l3_bi_data_marts.cases_datamart_new;
alter table cases_datamart_backup rename to cases_datamart