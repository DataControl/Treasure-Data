delete from db_stg_bi_technical.sendouts_agr
where
cast(sendout_date as date) >
DATE_ADD('day', -3, (select max(cast(sendout_date as date)) from  db_stg_bi_technical.sendouts_agr));
delete from db_l3_bi_data_marts.sendouts
where
cast(sendout_date as date) >
DATE_ADD('day', -3, (select max(cast(sendout_date as date)) from  db_l3_bi_data_marts.sendouts));