select 
s.subscriberid as subscriber_id,
s.sendoutjobid as send_id,
-- Measures
max(contact_date) as contact_date,
count(s.session_id) as total_sessions,
sum(s.total_web_bounces) as total_web_bounces,
sum(s.total_transactions) as total_transactions,
sum(s.total_revenue) as total_revenue,
sum(s.total_session_duration) as total_session_duration,
sum(s.total_pageviews) as total_pageviews,
count(DISTINCT(s.visitor_id)) as total_visitors
-- joins
from db_l3_bi_data_marts.session s
GROUP BY 1,2
