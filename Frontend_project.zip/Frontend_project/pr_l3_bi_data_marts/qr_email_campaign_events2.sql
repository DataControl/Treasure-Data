drop table if exists db_stg_bi_technical.campaign_events_agr2;
create table db_stg_bi_technical.campaign_events_agr2
as
select batch_id, job_id, identity_identifier,
sum(total_email_clicks) as total_email_clicks,
sum(total_email_open) as total_email_open,
sum(total_email_bounces) as total_email_bounces
from db_stg_bi_technical.campaign_events_agr
group by 1,2,3
