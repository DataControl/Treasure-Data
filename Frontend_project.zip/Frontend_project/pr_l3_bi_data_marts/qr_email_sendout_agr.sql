select
s.batchid as batch_id,
s.jobid as send_id,
s.journey_id,
s.journey_name,
s.email_sendlog_dev_errorcode,
s.ja_emailname,
s.sj_emailname,
s.email_scope,
s.description,
s.messagename,
s.subject,
s.preview_url,
s.email_domain,
cast(s.subscriberkey  as varchar) as subscriber_key,
cast(cast(FROM_UNIXTIME(max(s.eventdate))as date) as varchar)  as sendout_date,  
count(*) as total_email_sent,
sum( (CASE 
        WHEN email_sendlog_dev_errorcode=24 
        THEN 0
        ELSE 1
        END))
         as total_email_delivered
         from 
         db_l2_bi.sendouts s
where type = 'EMAIL'  and jobid is not null
group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14