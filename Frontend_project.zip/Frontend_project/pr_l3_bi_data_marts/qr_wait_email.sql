select count(*) from db_bi_monitoring.workflow_success where workflow_name='wf_sfmc_l1_master_email' and project_name= 'proj_sfmc_src_bi' and
session_date=cast(current_date as varchar)