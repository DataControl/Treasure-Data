select 'db_l2_bi.sendouts' as var_source_table,'db_stg_bi.deduplication_sms' as var_target_table,'subscriberkey' as  unique_key,
'subscriberkey' as source_unique_identifier