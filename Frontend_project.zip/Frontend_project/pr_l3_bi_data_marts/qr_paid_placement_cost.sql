SELECT placement_id, DATE, 
COUNT(DISTINCT placement_total_booked_units) as booked_units_duplicates, COUNT(DISTINCT placement_rate) as rate_duplicates
FROM db_l0_gcm_bi.placement_cost
GROUP BY 1, 2
ORDER BY 4 desc