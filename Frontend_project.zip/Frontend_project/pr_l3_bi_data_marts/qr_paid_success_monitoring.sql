insert into db_bi_monitoring.workflow_success select 'wf_db_l3_bi_data_marts_paid'  as workflow_name, 'pr_l3_bi_data_marts' as project_name, '${session_uuid}' as session_uuid, '${session_id}'

    as   session_id, '${session_time}' as session_time, '${session_date}' as session_date;