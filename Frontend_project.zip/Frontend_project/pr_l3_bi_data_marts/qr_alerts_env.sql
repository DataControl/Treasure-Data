select 
    SUBSTR(email,5,3) as env
from db_bi_monitoring.workflow_alerts
    where email like 'env%'