select 
COALESCE(e.organic_id, c.case_identifier) as case_identifier,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(create_date)),'yyyy-MM-dd HH:mm:ss','UTC') as create_date,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(closing_date)),'yyyy-MM-dd HH:mm:ss','UTC') as closing_date,
case_country,
case_record_type,
case_type,
subject_code,
subject_description,
device_issue_flag,
resolution_code,
case_source,
escalation_flag,
status,
case_channel,
time_to_resolution,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(first_response_time)),'yyyy-MM-dd HH:mm:ss','UTC') as first_response_time,
agent_id,
device_codetify,
device_product_generation,
device_product_description,
device_warranty_due_date_eligibility,
return_status,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(delivery_date)),'yyyy-MM-dd HH:mm:ss','UTC') as delivery_date,
l1_result,
l1_subject_description,
closed_on_creation,
time_to_resolution_hours,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(latest_update_date)),'yyyy-MM-dd HH:mm:ss','UTC') as latest_update_date,
createdby,
persona_identifier,
home_country as home_country_cases,
anonymous_case_indicator,
appointment_id,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(case_handling_start_time)),'yyyy-MM-dd HH:mm:ss','UTC') as case_handling_start_time,
case_handling_time,
consumable_complaint_reason,
incoming_system,
interaction_id,
isclosed,
isclosed_on_create,
isescalated,
order_id,
origin,
owner_id,
product_family,
product_line,
source_id,
--COALESCE(d.migrated_identifier,c.identity_identifier) identity_identifier,
d.migrated_identifier as identity_identifier,
i.global_opt_in ,
i.gender ,
i.home_country_consumer ,
i.segment,
i.date_of_birth,
i.database_opt_in ,
i.lastmodified
from 
db_l2_bi.cases_attributes c
left join 
(
select
identity_identifier , 
max(global_opt_in) as global_opt_in ,
max( gender) as gender ,
max( home_country) as home_country_consumer ,
max( segment)  as segment,
max( CAST(FROM_UNIXTIME(date_of_birth) as VARCHAR)) as date_of_birth,
max( database_opt_in) as database_opt_in ,
max(lastmodified)  as lastmodified
 from db_l2_bi.consumer i
 group by 1
)i
on c.identity_identifier  = i.identity_identifier
left join

${td.last_results.var_target_table}  d

on c.case_identifier  = d.${td.last_results.unique_key}

left join
(
select distinct a.case_identifier ,
case when a.source_type='DCE' THEN CONCAT('DCE_',a.country,'_',b.organic_id)
when a.source_type='DCS' THEN CONCAT('DCS_',a.country,'_',b.organic_id,'_',split_part(a.case_identifier,'_',4) )
--when a.source_type='DCE20' THEN CONCAT('DCE20_',b.organic_id)
END AS organic_id
from (select 
split_part(case_identifier,'_',3) as casenumber ,
split_part(case_identifier,'_',2)  as country,
split_part(case_identifier,'_',1) as source_type,
case_identifier
from db_l2_bi.cases_attributes ) a ,
(SELECT legacy_id, split_part(legacy_id,'_',1) as source_type,split_part(legacy_id,'_',2) as country,split_part(legacy_id,'_',3) as casenumber,organic_id FROM db_l3_bi_data_marts.cases_mapping) b
where a.source_type=b.source_type and a.casenumber=b.casenumber and COALESCE(a.country,'XX')=COALESCE(b.country,'XX')) e

on c.case_identifier  = e.case_identifier