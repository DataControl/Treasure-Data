select
a.appointment_number,
a.identity_identifier,
a.account_id,
a.status,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(a.scheduled_start)),'yyyy-MM-dd HH:mm:ss','UTC') as scheduled_start,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(a.scheduled_end)),'yyyy-MM-dd HH:mm:ss','UTC') as scheduled_end,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(a.actual_start_time)),'yyyy-MM-dd HH:mm:ss','UTC') as actual_start_time,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(a.actual_start_time)),'yyyy-MM-dd HH:mm:ss','UTC') as actual_end_time,
a.actual_duration,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(a.arrival_window_start_time)),'yyyy-MM-dd HH:mm:ss','UTC') as arrival_window_start_time,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(a.arrival_window_end_time)),'yyyy-MM-dd HH:mm:ss','UTC') as arrival_window_end_time,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(a.createddate)),'yyyy-MM-dd HH:mm:ss','UTC') as createddate,
a.currency_iso_code,
a.description,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(a.due_date)),'yyyy-MM-dd HH:mm:ss','UTC') as due_date,
a.duration,
a.duration_type,
a.duration_in_minutes,
TD_TIME_FORMAT(TD_TIME_PARSE(trim(a.earliest_start_time)),'yyyy-MM-dd HH:mm:ss','UTC') as earliest_start_time,
a.latitude,
a.longitude,
a.postalcode,
a.city ,
a.service_territory_id,
a.state,
a.country,
a.owner_id,
a.parent_record_id,
a.parent_record_status_category,
a.parent_record_type,
a.service_note,
a.status_category,
a.subject,
a.work_type_id,
TD_TIME_FORMAT(TD_TIME_PARSE(trim( 
case when a.actual_start_time is null then (a.scheduled_start)
else (a.actual_start_time) end)),'yyyy-MM-dd HH:mm:ss','UTC') as start_time,
max(case when interaction_type_refcode = 'GUIDED_TRIAL' then 1 else 0 end) as flag_guided_trial,
max(case when interaction_type_refcode = 'LENDING' then 1 else 0 end) as flag_lending,
max(case when interaction_type_refcode in ('SOS', 	'ENDLESS_AISLE', 	'DEVICE_REPL', 	'MANUAL_REPL', 	'VERIFY_RETURN', 	'BLIND_RETURN', 	'CLICK_COLLECT' ) then 1 else 0 end) as flag_transaction,
max(case when interaction_type_refcode in ('CONV_CHECK', 	'IMM_EDUC', 	'CLEANING', 	'LOST', 	'CARE_PLUS_UNENROLL', 	'QOACH_ENROLL', 	'QOACH_UNENROLL', 	'DEVICE_LINK', 	'DEVICE_UNLINK') then 1 else 0 end) as flag_inlife,
max(case when interaction_type_refcode = 'SOS' then 1 else 0 end) as flag_Sales_on_Spot,
max(case when interaction_type_refcode = 'ENDLESS_AISLE' then 1 else 0 end )as flag_Endless_Aisle,
max(case when interaction_type_refcode = 'DEVICE_REPL' then 1 else 0 end) as flag_Device_Replacement,
max(case when interaction_type_refcode = 'MANUAL_REPL' then 1 else 0 end) as flag_Manual_Replacement,
max(case when interaction_type_refcode = 'VERIFY_RETURN' then 1 else 0 end) as flag_Verify_Return,
max(case when interaction_type_refcode = 'BLIND_RETURN' then 1 else 0 end) as flag_Blind_Return,
max(case when interaction_type_refcode = 'CONV_CHECK' then 1 else 0 end) as flag_Conversion_check,
max(case when interaction_type_refcode = 'CLICK_COLLECT' then 1 else 0 end) as flag_Click_and_Collect,
max(case when interaction_type_refcode = 'IMM_EDUC' then 1 else 0 end) as flag_Immersive_Education,
max(case when interaction_type_refcode = 'CLEANING' then 1 else 0 end) as flag_Cleaning_service,
max(case when interaction_type_refcode = 'LOST' then 1 else 0 end )as flag_Customer_lost,
max(case when interaction_type_refcode = 'CARE_PLUS_UNENROLL' then 1 else 0 end) as flag_Care_unenrollment,
max(case when interaction_type_refcode = 'QOACH_ENROLL' then 1 else 0 end) as flag_Qoach_Enrollement,
max(case when interaction_type_refcode = 'QOACH_UNENROLL' then 1 else 0 end) as flag_Qoach_Unenrollement,
max(case when interaction_type_refcode = 'DEVICE_LINK' then 1 else 0 end )as flag_Device_link,
max(case when interaction_type_refcode = 'DEVICE_UNLINK' then 1 else 0 end )as flag_Device_unlink,
max(case when interaction_type_refcode = 'APP_CHECK_IN' then 1 else 0 end )as flag_Appointment_checkedin,
max(case when interaction_type_refcode = 'ACCESSORIES_REPL' then 1 else 0 end) as flag_Accessories_replacement
    
from
(SELECT * FROM
db_l2_bi.appointments
WHERE appointment_identifier IN
(SELECT CONCAT(appointment_number,'-',max_lastmodifieddate) as key FROM
(
SELECT appointment_number, MAX(lastmodifieddate) as max_lastmodifieddate FROM db_l2_bi.appointments
GROUP BY 1))) a
left join
(select appointment_id,
interaction_type_refcode
from db_l2_bi.interactions) b
on a.appointment_number = b.appointment_id

group by 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33, 34, 35
order by appointment_number