
insert into db_l3_bi_data_marts.cases_mapping
		 (  record_id,
			createddate		,
			createdby		,
			lastmodifieddate		,
			lastmodifiedby		,
			mapping_identifier,
			correlation_id,
			legacy_id,
			organic_id
			)
			select 
		  a.record_id,
			a.createddate		,
			a.createdby		,
			a.lastmodifieddate		,
			a.lastmodifiedby		,
			a.mapping_identifier,
			a.correlation_id,
			a.legacy_id,
			a.organic_id
		  from 
		     db_stg_bi.cases_mapping a , db_l3_bi_data_marts.cases_mapping b
		     where a.legacy_id<>b.legacy_id and a.legacy_id is not null and b.legacy_id is not null