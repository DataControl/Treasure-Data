delete from db_stg_bi_technical.impression_agr
where
cast(date as date) >
DATE_ADD('day', -3, (select max(cast(date as date)) from impression_agr))