select 
order_id, max(updated_time), CONCAT(order_id,max(updated_time)) as key
from
db_l2_bi.commerce_orders
group by 1
order by 1