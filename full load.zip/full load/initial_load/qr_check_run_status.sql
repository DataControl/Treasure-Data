select cast(TD_TIME_FORMAT(TD_TIME_ADD(last_load_ts, '5d'),'yyyyMMdd') as bigint) as start_date,
cast(TD_TIME_FORMAT(b.end_date_initial,'yyyyMMdd') as bigint)  as  end_date
from ( select last_load_ts from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank from db_stg_bi_technical.delta_load_log_dce  where layer ='db_l0_gcm_bi' and entity_name= 'paid_gcm' and operation_mode = 'insert' and completion_flag=0 )
          where rank = 1 ) 
        ,
                  ( select last_load_ts as end_date_initial from (select last_load_ts, row_number() over (partition by layer, entity_name, operation_mode order by last_load_ts desc, time desc) as rank
  from db_stg_bi_technical.delta_load_log_dce  where layer = 'paid_gcm_intial'  and entity_name= 'paid_intial' and operation_mode = 'insert' and completion_flag=0 ) 
          where rank = 1 ) b
