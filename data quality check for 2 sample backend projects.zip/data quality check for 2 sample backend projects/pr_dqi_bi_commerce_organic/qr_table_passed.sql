insert into db_bi_monitoring.dqi_bi_monitoring
select 
cast (CURRENT_TIMESTAMP as varchar) as start_date,
cast (CURRENT_TIMESTAMP as varchar) as end_date,
'${td.last_results.test_type}' as test_type,
CASE WHEN ${td.last_results.test_flag} THEN 1 ELSE 0 END as test_passed,
'${td.last_results.test_value}' as test_value,
${td.last_results.record_count} as record_count,
'commerce organic' as area,
'${var_table_name}' as "resource"
