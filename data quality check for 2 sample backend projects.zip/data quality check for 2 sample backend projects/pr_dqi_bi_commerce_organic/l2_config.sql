--TEST CONFIGURATION FOR L2
select 'db_l2_bi.commerce_orders' as table_name  union all 
select 'db_l2_bi.commerce_orders_items' as table_name ;
