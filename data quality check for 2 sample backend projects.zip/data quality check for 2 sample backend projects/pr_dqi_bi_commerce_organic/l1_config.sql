--TEST CONFIGURATION FOR L1
select  'db_l1_bi_organic.orders'       as table_name, 'db_l0_organic.orders_parsed'    as table_for_completeness_check       union all
select  'db_l1_bi_organic.order_items'   as table_name,  'db_l0_organic.orders_item_parsed'  as table_for_completeness_check    union all
select  'db_l1_bi_organic.orders_discounts'   as table_name,  'db_l0_organic.orders_discount_parsed'  as table_for_completeness_check  union all
select  'db_l1_bi_organic.orders_item_discounts'   as table_name,  'db_l0_organic.orders_item_discount_parsed'  as table_for_completeness_check  ;