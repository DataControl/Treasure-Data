--TEST CONFIGURATION FOR L0
select 'db_l0_organic.orders_parsed'      as table_name union all
select 'db_l0_organic.orders_item_parsed'      as table_name union all
select 'db_l0_organic.orders_discount_parsed'     as table_name union all
select 'db_l0_organic.orders_item_discount_parsed' as table_name;