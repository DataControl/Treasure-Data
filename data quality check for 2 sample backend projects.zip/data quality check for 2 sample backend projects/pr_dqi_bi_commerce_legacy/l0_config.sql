--TEST CONFIGURATION FOR L0

select 'db_pstg_migration.dce_order_header' as  table_name union all  select 'db_l0_odatadcs.orders' as table_name  union all 
select 'db_pstg_migration.dce_order_item'  as table_name union all select 'db_l0_odatadcs.orderitems'  as table_name ; 
;
