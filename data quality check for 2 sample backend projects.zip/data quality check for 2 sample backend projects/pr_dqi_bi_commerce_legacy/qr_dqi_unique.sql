
select round(cast ( a.unique_count as double ) / cast(a.all_count as double), 4) as test_value,
      case when a.unique_count = a.all_count then true else false end as test_flag,
      'uniqueness' as test_type,
      a.all_count as record_count
from
(
  select 
    count(*) as all_count,
    (select count(*) from (select distinct ${td.last_results.list_fields_dqi}  from ${var_table_name})) as unique_count
  from ${var_table_name}
) a;