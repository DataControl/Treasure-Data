select 
    count(*) as result
from information_schema.tables
    where concat(table_schema,'.',table_name) =  'db_l1_bi_commerce.orders';