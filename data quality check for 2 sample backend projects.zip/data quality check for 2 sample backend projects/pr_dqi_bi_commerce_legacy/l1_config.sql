--TEST CONFIGURATION FOR L1

select  'db_l1_bi_commerce.orders'  as table_name union all select 'db_l1_bi_commerce.order_items' as table_name union all 
select  'db_l1_bi_commerce.products'   as table_name ;