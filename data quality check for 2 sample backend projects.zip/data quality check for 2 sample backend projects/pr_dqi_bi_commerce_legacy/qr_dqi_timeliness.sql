
select 
'timeliness' as test_type,
a.test_flag,
case when a.test_flag then 'passed' else 'not_passed' end as test_value
from
(select 
	case
		when exists (
		select 
			1 
		from db_bi_monitoring.workflow_success ws
		where session_date = cast(CURRENT_DATE as varchar) 
		  and ws.workflow_name = '${var_loading_wf_name}'
		) then true
		else false
	end as test_flag) a; 