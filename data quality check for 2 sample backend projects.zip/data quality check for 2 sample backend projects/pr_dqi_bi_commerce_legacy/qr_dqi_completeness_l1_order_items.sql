select 
  d.test_value as test_value,
  case when d.test_value = 0 then true else false end as test_flag,
  'db_l1_bi_commerce.order_items' as table_name,
  'completeness' as test_type,
  d.record_count as record_count
  from
  (
    select
    c.test_value as test_value,
    c.record_count as record_count
    from
    (
      select round(1 - (cast(a.cnt as double) / cast(b.cnt as double )), 4) as test_value,
      a.cnt as record_count
      from 
 (select count(*) as cnt from db_l1_bi_commerce.order_items) as  a, 
  (select count(*) as cnt from 
        (select 1 from db_pstg_migration.dce_order_item g union all select 1 from db_l0_odatadcs.orderitems) ) as b
    ) c 
  ) d ;