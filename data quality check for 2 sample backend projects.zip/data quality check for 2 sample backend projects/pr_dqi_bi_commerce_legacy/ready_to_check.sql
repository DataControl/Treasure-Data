select 
    count(*) as result
from information_schema.tables
    where concat(table_schema, '.', table_name) = '${var_table_name}'
 