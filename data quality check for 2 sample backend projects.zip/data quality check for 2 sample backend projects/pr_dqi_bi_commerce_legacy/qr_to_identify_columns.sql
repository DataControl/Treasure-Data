select
 list_fields_dqi as list_fields_dqi
from (
select 
array_join(array_agg(column_name), ', ') as list_fields_dqi
from information_schema.columns 
where concat(table_schema,'.',table_name) =  replace('${var_table_name}','"')
      and  column_name not in ( 'record_id','time')
group by table_name
);