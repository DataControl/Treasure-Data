--TEST CONFIGURATION FOR L3

select 'db_l3_bi_data_marts.commerce_orders_datamart' as table_name union all
select 'db_l3_bi_data_marts.commerce_orders_items_datamart' as table_name;
