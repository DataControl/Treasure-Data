select 
  d.test_value as test_value,
  case when d.test_value = 0 then true else false end as test_flag,
  'completeness' as test_type,
  d.record_count as record_count
from 
  (
    select
    c.test_value as test_value,
    c.record_count
    from
    (
      select round(1 - (cast(a.cnt as double) / cast(b.cnt as double )), 4) as test_value,
      a.cnt as record_count
      from 
 (select count(*) as cnt from ${var_table_name}) as  a,
  (select count(*) as cnt from ${var_table_to_compare}) as b
    ) c 
  ) d;